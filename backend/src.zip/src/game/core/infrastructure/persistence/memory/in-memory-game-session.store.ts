import { Inject, Injectable, Optional } from '@nestjs/common';
import { randomUUID } from 'node:crypto';
import {
  DEFAULT_GAME_SNAPSHOT_POLICY,
  GAME_SNAPSHOT_POLICY,
  type GameEventStore,
  type GameSnapshotPolicy,
} from '../../../application/ports/game-event-store.port';
import type {
  GameStateCommit,
  GameStateCommitResult,
  GameStateStore,
} from '../../../application/ports/game-state-store.port';
import type {
  GameEvent,
  GameSnapshot,
  GameTimeline,
} from '../../../application/models/game-event.model';
import type { GameState } from '../../../application/models/game-state.model';
import {
  appendGameTimelineCommit,
  assertGameStateSize,
  createGameTimeline,
  replayTimeline,
} from '../../../application/services/game-timeline';

@Injectable()
export class InMemoryGameSessionStore
  implements GameStateStore, GameEventStore
{
  private readonly states = new Map<string, GameState>();
  private readonly timelines = new Map<string, GameTimeline>();
  private readonly snapshotPolicy: Readonly<GameSnapshotPolicy>;
  private static readonly MAX_SESSIONS = 10_000;

  constructor(
    @Optional()
    @Inject(GAME_SNAPSHOT_POLICY)
    policy?: GameSnapshotPolicy,
  ) {
    this.snapshotPolicy = {
      ...DEFAULT_GAME_SNAPSHOT_POLICY,
      ...policy,
    };
  }

  async load(roomId: number, gameType: string): Promise<GameState | null> {
    const state = this.states.get(this.key(roomId, gameType));
    return state ? structuredClone(state) : null;
  }

  async restore(
    roomId: number,
    gameType: string,
    state: GameState,
  ): Promise<GameState> {
    const key = this.key(roomId, gameType);
    assertGameStateSize(state, this.snapshotPolicy.maxStateBytes);
    const restored = structuredClone(state);
    restored.metadata = { ...restored.metadata, restoreId: randomUUID() };
    assertGameStateSize(restored, this.snapshotPolicy.maxStateBytes);
    if (
      !this.states.has(key) &&
      this.states.size >= InMemoryGameSessionStore.MAX_SESSIONS
    ) {
      throw new Error('In-memory game session capacity exceeded');
    }
    this.states.set(key, restored);
    this.timelines.set(key, createGameTimeline(restored));
    return structuredClone(restored);
  }

  async compareAndSet(commit: GameStateCommit): Promise<GameStateCommitResult> {
    assertGameStateSize(commit.next, this.snapshotPolicy.maxStateBytes);
    const key = this.key(commit.roomId, commit.gameType);
    const current = this.states.get(key);
    const currentVersion = current?.version ?? 0;
    if (
      !current ||
      currentVersion !== commit.expectedVersion ||
      (commit.expectedRestoreId !== undefined &&
        (current.metadata?.restoreId ?? null) !== commit.expectedRestoreId)
    ) {
      return {
        committed: false,
        version: currentVersion,
        state: structuredClone(current ?? commit.next),
      };
    }

    const next = structuredClone(commit.next);
    if (current.metadata?.restoreId)
      next.metadata = {
        ...next.metadata,
        restoreId: current.metadata.restoreId,
      };
    const committedVersion = commit.expectedVersion + 1;
    next.version = committedVersion;
    const timeline = appendGameTimelineCommit({
      timeline: this.timelineForCommit(key, current),
      previous: current,
      next,
      pendingEvents: commit.pendingEvents,
      occurredAtMs: commit.occurredAtMs,
      snapshotPolicy: this.snapshotPolicy,
    });
    this.states.set(key, next);
    this.timelines.set(key, timeline);
    return {
      committed: true,
      version: committedVersion,
      state: structuredClone(next),
    };
  }

  async clear(roomId: number, gameType: string): Promise<void> {
    const key = this.key(roomId, gameType);
    this.states.delete(key);
    this.timelines.delete(key);
  }

  async clearIfVersion(
    roomId: number,
    gameType: string,
    expectedVersion: number,
    expectedRestoreId?: string | null,
  ): Promise<void> {
    const key = this.key(roomId, gameType);
    const current = this.states.get(key);
    if (
      current?.version === expectedVersion &&
      (expectedRestoreId === undefined ||
        (current.metadata?.restoreId ?? null) === expectedRestoreId)
    ) {
      this.states.delete(key);
      this.timelines.delete(key);
    }
  }

  async clearRoom(roomId: number): Promise<void> {
    const prefix = `${roomId}:`;
    for (const key of this.states.keys()) {
      if (!key.startsWith(prefix)) continue;
      this.states.delete(key);
      this.timelines.delete(key);
    }
  }

  async listEvents(
    roomId: number,
    gameType: string,
    afterSequence = 0,
    limit = 500,
  ): Promise<GameEvent[]> {
    return structuredClone(
      (this.timelines.get(this.key(roomId, gameType))?.events ?? [])
        .filter((event) => event.seq > afterSequence)
        .slice(0, Math.max(1, Math.min(1_000, Math.trunc(limit)))),
    );
  }

  async latestSnapshot(
    roomId: number,
    gameType: string,
  ): Promise<GameSnapshot | null> {
    const timeline = this.timelines.get(this.key(roomId, gameType));
    return timeline ? structuredClone(timeline.snapshots.at(-1) ?? null) : null;
  }

  async replay(
    roomId: number,
    gameType: string,
    untilSequence?: number,
  ): Promise<GameState | null> {
    const timeline = this.timelines.get(this.key(roomId, gameType));
    return timeline
      ? replayTimeline(structuredClone(timeline), untilSequence)
      : null;
  }

  private key(roomId: number, gameType: string): string {
    if (!Number.isSafeInteger(roomId) || roomId <= 0 || gameType.length > 128) {
      throw new Error('Invalid in-memory game session key');
    }
    return `${roomId}:${gameType}`;
  }

  private timelineForCommit(key: string, state: GameState): GameTimeline {
    const existing = this.timelines.get(key);
    if (existing) return structuredClone(existing);
    return createGameTimeline(state);
  }
}
