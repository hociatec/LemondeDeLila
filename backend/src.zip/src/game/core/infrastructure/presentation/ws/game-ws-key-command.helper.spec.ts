import {
  normalizeGameKey,
  resolveGameLifecycleOperation,
  resolvePresentedGameKey,
} from './game-ws-key-command.helper';

describe('game websocket key commands', () => {
  const presented = {
    actions: [
      { type: 'draw', payload: { deck: 'main' } },
      { type: 'roll', payload: {} },
      { type: 'hidden_action', payload: { secret: true }, disabled: true },
    ],
    extras: {
      shortcuts: [
        { key: 'pressed SPACE', type: 'action', actionType: 'draw' },
        { key: 'SPACE', type: 'action', actionType: 'roll' },
        { key: 'ENTER', type: 'action', actionType: 'draw' },
        { key: 'H', type: 'action', actionType: 'hidden_action' },
        { key: 'C', type: 'interface', id: 'discard' },
      ],
      ui: {
        panels: {
          discard: { message: 'Carte au-dessus : 4.' },
        },
      },
    },
  };

  it('normalizes the same key vocabulary as the clients', () => {
    expect(normalizeGameKey(' pressed return ')).toBe('ENTER');
    expect(normalizeGameKey('backspace')).toBe('BACK');
  });

  it('resolves only an action exposed to the authenticated viewer', () => {
    expect(resolvePresentedGameKey(presented, 'space')).toEqual({
      kind: 'action',
      action: { type: 'draw', payload: { deck: 'main' } },
    });
    expect(resolvePresentedGameKey(presented, 'H')).toEqual({ kind: 'none' });
  });

  it('returns server-presented interface feedback', () => {
    expect(resolvePresentedGameKey(presented, 'C')).toEqual({
      kind: 'interface',
      panelId: 'discard',
      message: 'Carte au-dessus : 4.',
    });
  });

  it('never resolves Enter or a dice roll bound to Space', () => {
    expect(resolvePresentedGameKey(presented, 'ENTER')).toEqual({
      kind: 'none',
    });
    expect(
      resolvePresentedGameKey(
        {
          actions: [{ type: 'roll', payload: {} }],
          system: {
            shortcuts: [{ key: 'SPACE', type: 'action', actionType: 'roll' }],
          },
        },
        'SPACE',
      ),
    ).toEqual({ kind: 'none' });
  });

  it('never treats repeated Enter as a lifecycle command during a game', () => {
    expect(resolveGameLifecycleOperation('ENTER', 'started')).toBeNull();
    expect(resolveGameLifecycleOperation('ENTER', 'playing')).toBeNull();
    expect(resolveGameLifecycleOperation('ENTER', 'finished')).toBe('reset');
    expect(resolveGameLifecycleOperation('X', 'started')).toBe('reset');
    expect(resolveGameLifecycleOperation('X', 'playing')).toBe('reset');
    expect(resolveGameLifecycleOperation('X', 'setup')).toBeNull();
  });

  it('reads shortcuts from the current V2 system contract', () => {
    expect(
      resolvePresentedGameKey(
        {
          actions: [{ type: 'draw', payload: {} }],
          system: {
            shortcuts: [{ key: 'SPACE', type: 'action', actionType: 'draw' }],
          },
        },
        'SPACE',
      ),
    ).toEqual({ kind: 'action', action: { type: 'draw', payload: {} } });
  });
});
