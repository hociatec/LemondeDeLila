type GenericEventMessageInput = {
  type: string;
  data: Record<string, unknown>;
  actorId: number | null;
  players: ReadonlyMap<number, string>;
  viewerPlayerId: number | null;
};

export function genericGameEventMessage(
  input: GenericEventMessageInput,
): string {
  const player = (value: unknown): string => {
    const id = numberValue(value);
    if (id == null) return '';
    return id === input.viewerPlayerId
      ? 'Vous'
      : (input.players.get(id) ?? `Joueur ${id}`);
  };
  const value = (key: string): string => scalarText(input.data[key]);
  const actor = player(input.actorId);
  return (
    cardAndTurnMessage(input, player, actor, value) ||
    boardAndPlayerMessage(input, player, value) ||
    activityMessage(input, player, value)
  );
}

function cardAndTurnMessage(
  input: GenericEventMessageInput,
  player: (value: unknown) => string,
  actor: string,
  value: (key: string) => string,
): string {
  const { type, data, players } = input;
  if (type === 'turn.started') {
    const id = numberValue(data.playerId);
    const name = id == null ? '' : (players.get(id) ?? `Joueur ${id}`);
    return name ? `C'est au tour de ${name}.` : '';
  }
  if (type === 'dice.rolled' && actor) {
    const multipleDice = Array.isArray(data.values) && data.values.length > 1;
    const roll = multipleDice ? 'les dés' : 'le dé';
    const verb = actor === 'Vous' ? 'lancez' : 'lance';
    const resultVerb = actor === 'Vous' ? 'obtenez' : 'obtient';
    return value('total')
      ? `${actor} ${verb} ${roll} et ${resultVerb} ${value('total')}.`
      : `${actor} ${verb} ${roll}.`;
  }
  if (type === 'card.drawn' && actor)
    return `${actor} ${actor === 'Vous' ? 'piochez' : 'pioche'} une carte.`;
  if (type === 'card.received') {
    const name = player(data.playerId);
    return name ? `${name} reçoit une carte.` : '';
  }
  if (type === 'card.played' && actor)
    return `${actor} joue ${scalarText(data.card) || 'une carte'}.`;
  if (type === 'card.transferred') {
    const from = player(data.fromPlayerId);
    const to = player(data.toPlayerId);
    return from && to ? `${from} donne une carte à ${to}.` : '';
  }
  if (type === 'cards.exchanged' || type === 'cards.hands-swapped') {
    const left = player(data.leftPlayerId);
    const right = player(data.rightPlayerId);
    return left && right ? `${left} et ${right} échangent leurs cartes.` : '';
  }
  return '';
}

function boardAndPlayerMessage(
  input: GenericEventMessageInput,
  player: (value: unknown) => string,
  value: (key: string) => string,
): string {
  const { type, data } = input;
  if (type.endsWith('.mark.placed')) {
    const name = player(data.playerId);
    const x = numberValue(data.x);
    const y = numberValue(data.y);
    if (
      !name ||
      x == null ||
      y == null ||
      !Number.isSafeInteger(x) ||
      !Number.isSafeInteger(y) ||
      x < 0 ||
      y < 0
    )
      return '';
    let column = '';
    for (let n = x + 1; n > 0; n = Math.floor((n - 1) / 26))
      column = String.fromCharCode(65 + ((n - 1) % 26)) + column;
    return `${name} ${name === 'Vous' ? 'placez votre' : 'place son'} pion en ${column}${y + 1}.`;
  }
  if (type === 'resource.changed') {
    // Corridor publishes its initial wall stock to the resources panel. It is
    // setup data, not a game event that belongs in the spoken history.
    if (value('resource') === 'board-path-walls.walls') return '';
    const name = player(data.playerId);
    const resource = humanLabel(value('resource'));
    return name && resource && value('value')
      ? `${name} : ${resource} vaut ${value('value')}.`
      : '';
  }
  if (type === 'resource.transferred') {
    const from = player(data.from);
    const to = player(data.to);
    const resource = humanLabel(value('resource'));
    return from && to && resource && value('amount')
      ? `${from} transfère ${value('amount')} ${resource} à ${to}.`
      : '';
  }
  if (type === 'pawn.moved') return '';
  if (type === 'pawn.landed') return pawnLandedMessage(data, player, value);
  if (type === 'pawn.assigned') {
    const name = player(data.playerId);
    const pawn = value('pawnLabel') || humanLabel(value('pawnId'));
    if (!name || !pawn) return '';
    return name === 'Vous'
      ? `Vous avez choisi « ${pawn} ».`
      : `${name} a choisi « ${pawn} ».`;
  }
  if (type === 'player.eliminated') {
    const name = player(data.playerId);
    return name ? `${name} est éliminé.` : '';
  }
  if (type === 'player.skipped') {
    const name = player(data.playerId);
    return name
      ? name === 'Vous'
        ? 'Vous passez votre tour.'
        : `${name} passe son tour.`
      : '';
  }
  if (type === 'round.player-left') {
    const name = player(data.playerId);
    return name
      ? `${name} ${name === 'Vous' ? 'sortez' : 'sort'} de la manche.`
      : '';
  }
  return '';
}

function tileLabel(value: string): string {
  return humanLabel(value.replace(/^case\s+\d+\s*(?:[—–:-]\s*)?/iu, '').trim());
}

function activityMessage(
  input: GenericEventMessageInput,
  player: (value: unknown) => string,
  value: (key: string) => string,
): string {
  const { type, data } = input;
  if (type === 'match.started') return 'La partie démarre, bon jeu !';
  if (type === 'round.started' && value('number')) {
    const starter = player(data.starterPlayerId);
    return starter
      ? `La manche ${value('number')} commence. C'est au tour de ${starter}.`
      : `La manche ${value('number')} commence.`;
  }
  if (type === 'round.ended') return 'La manche est terminée.';
  if (type === 'game.finished') return 'La partie est terminée.';
  // Quiz state is presented directly under the question by the gameplay UI.
  // Do not duplicate that information in the common table history.
  if (type === 'quiz.asked' || type === 'quiz.revealed') return '';
  if (type === 'submissions.revealed') return 'Les soumissions sont révélées.';
  if (type === 'submission.received') {
    const name = player(data.playerId);
    return name
      ? `${name} ${name === 'Vous' ? 'avez soumis votre' : 'a soumis sa'} réponse.`
      : '';
  }
  if (type === 'judge.started' || type === 'judge.changed') {
    const name = player(data.playerId);
    return name ? `${name} devient juge.` : '';
  }
  if (type === 'inventory.item-added' || type === 'inventory.item-removed')
    return inventoryMessage(type, data, player, value);
  if (type === 'panier.shopping-list.announced') {
    const name = player(data.playerId);
    const items = Array.isArray(data.items)
      ? data.items.map((item) => humanLabel(scalarText(item))).filter(Boolean)
      : [];
    if (!name) return '';
    return name === 'Vous'
      ? `Votre liste de courses : ${items.join(', ')}.`
      : `Liste de courses de ${name} : ${items.join(', ')}.`;
  }
  if (type === 'economy.item-bought' || type === 'economy.item-sold')
    return economyMessage(type, data, player, value);
  return '';
}

function inventoryMessage(
  type: string,
  data: Record<string, unknown>,
  player: (value: unknown) => string,
  value: (key: string) => string,
): string {
  const name = player(data.playerId);
  const item = humanLabel(value('itemId'));
  const verb =
    type === 'inventory.item-added'
      ? name === 'Vous'
        ? 'recevez'
        : 'reçoit'
      : name === 'Vous'
        ? 'perdez'
        : 'perd';
  return name && item && value('count')
    ? `${name} ${verb} ${value('count')} ${item}.`
    : '';
}

function economyMessage(
  type: string,
  data: Record<string, unknown>,
  player: (value: unknown) => string,
  value: (key: string) => string,
): string {
  const name = player(data.playerId);
  const item = humanLabel(value('itemId'));
  const verb =
    type === 'economy.item-bought'
      ? name === 'Vous'
        ? 'achetez'
        : 'achète'
      : name === 'Vous'
        ? 'vendez'
        : 'vend';
  return name && item ? `${name} ${verb} ${item}.` : '';
}

function numberValue(value: unknown): number | null {
  const number = typeof value === 'number' ? value : Number.NaN;
  return Number.isFinite(number) ? number : null;
}

function scalarText(value: unknown): string {
  if (typeof value === 'string') return value.trim();
  if (typeof value === 'number' || typeof value === 'boolean')
    return String(value);
  return '';
}

function humanLabel(value: string): string {
  const normalized = value
    .replace(/[-_.]+/g, ' ')
    .trim()
    .toLowerCase();
  return normalized
    ? normalized.charAt(0).toUpperCase() + normalized.slice(1)
    : '';
}

function pawnLandedMessage(
  data: Record<string, unknown>,
  player: (value: unknown) => string,
  value: (key: string) => string,
): string {
  const name = player(data.playerId);
  const internalPosition = numberValue(data.position);
  if (!name || internalPosition == null) return '';
  const verb = name === 'Vous' ? 'arrivez' : 'arrive';
  const label = tileLabel(value('tileLabel'));
  const description = value('tileDescription');
  const descriptionText = /^(?:Description|Effet)\s*:/iu.test(description)
    ? description
    : description
      ? `Description : ${description}`
      : '';
  return [
    `${name} ${verb} sur la case ${internalPosition + 1}${label ? ` : ${label}` : ''}.`,
    descriptionText,
  ]
    .filter(Boolean)
    .join(' ');
}
