import type { GameRuntime } from '../../../../application/ports/game-runtime.port';
import type { GameState } from '../../../../application/models/game-state.model';
import { GameWsStatePresenter } from './game-ws-state.presenter';
import { GameVisibilityService } from '../../../../application/services/game-visibility.service';

describe('GameWsStatePresenter', () => {
  const createPresenter = () =>
    new GameWsStatePresenter(new GameVisibilityService());

  it('publishes only shortcuts whose actions are visible to the viewer', () => {
    const state = {
      status: 'started',
      phase: 'turn',
      turnIndex: 1,
      players: [{ id: 1, username: 'A' }],
      turn: { currentPlayerId: 1, direction: 1 },
      metadata: { roomRunId: 7 },
    } as unknown as GameState;
    const handler = {
      exposeStateForUser: () => ({
        ...state,
        actions: [{ type: 'play', label: 'Jouer', payload: { card: 3 } }],
        kits: { score: { leaderboard: [] } },
        gameContract: {
          stateVersion: 2,
          rulesVersion: '3',
          contentVersion: 'c',
        },
      }),
      getShortcuts: () => [
        { key: 'P', type: 'action', actionType: 'play' },
        { key: 'Q', type: 'action', actionType: 'quit' },
        { key: 'S', type: 'interface', id: 'score', label: 'Scores' },
      ],
    } as unknown as GameRuntime;

    const payload = createPresenter().present({
      state,
      handler,
      roomId: 2,
      gameType: 'example',
      version: 1,
      viewerPlayerId: 1,
    });
    const system = payload.system as {
      shortcuts: Array<{ key: string; label?: string }>;
    };
    expect(system.shortcuts.map((shortcut) => shortcut.key)).toEqual([
      'P',
      'S',
    ]);
    expect(system.shortcuts.map((shortcut) => shortcut.label)).toEqual([
      'Jouer',
      'Scores',
    ]);
    expect(payload.runId).toBe(7);
    expect(payload.gameContract).toEqual({
      stateVersion: 2,
      rulesVersion: '3',
      contentVersion: 'c',
    });
    expect(payload.viewerPlayerId).toBe(1);
    expect(payload.state).toBeUndefined();
  });

  it('lets the game hide its score panel once the match is finished', () => {
    const state = {
      status: 'finished',
      players: [{ id: 1, username: 'Lila' }],
      metadata: {},
    } as unknown as GameState;
    const handler = {
      exposeStateForUser: () => ({
        system: { match: { status: 'finished' } },
        kits: {
          score: {
            byPlayer: { '1': 0 },
            leaderboard: [{ playerId: 1, score: 0, rank: 1 }],
          },
        },
        actions: [],
      }),
      getShortcuts: () => [
        { key: 'S', type: 'interface', id: 'score', label: 'Jetons' },
      ],
      getDescriptor: () => ({
        presentation: {
          score: {
            label: 'Jetons',
            unit: { singular: 'jeton', plural: 'jetons' },
            visibility: 'active-match',
          },
        },
      }),
    } as unknown as GameRuntime;

    const payload = createPresenter().present({
      state,
      handler,
      roomId: 6,
      gameType: 'lama',
      version: 9,
      viewerPlayerId: 1,
    });

    expect((payload.kits as any).score).toBeNull();
    expect((payload.system as any).shortcuts).toEqual([]);
  });

  it('reserves S for the generic score panel in every scored game', () => {
    const state = {
      status: 'playing',
      players: [{ id: 1, username: 'Lila' }],
      metadata: {},
    } as unknown as GameState;
    const handler = {
      exposeStateForUser: () => ({
        system: { match: { status: 'playing' } },
        kits: {
          score: {
            byPlayer: { '1': 0 },
            leaderboard: [{ playerId: 1, score: 0, rank: 1 }],
          },
        },
        actions: [{ type: 'sell', label: 'Vendre', payload: {} }],
      }),
      getShortcuts: () => [
        { key: 'S', type: 'action', actionType: 'sell', label: 'Vendre' },
      ],
      getDescriptor: () => ({
        presentation: {
          score: { visibility: 'active-match' },
        },
      }),
    } as unknown as GameRuntime;

    const payload = createPresenter().present({
      state,
      handler,
      roomId: 6,
      gameType: 'example',
      version: 1,
      viewerPlayerId: 1,
    });

    expect((payload.system as any).shortcuts).toEqual([
      { key: 'S', type: 'interface', id: 'score', label: 'Scores' },
    ]);
  });

  it('lets a scored game reserve S for a declared interface panel', () => {
    const state = {
      status: 'playing',
      players: [{ id: 1, username: 'Lila' }],
      metadata: {},
    } as unknown as GameState;
    const handler = {
      exposeStateForUser: () => ({
        system: { match: { status: 'playing' } },
        kits: {
          score: {
            byPlayer: { '1': 0 },
            leaderboard: [{ playerId: 1, score: 0, rank: 1 }],
          },
        },
        actions: [],
      }),
      getShortcuts: () => [
        {
          key: 'S',
          type: 'interface',
          id: 'inventory:shopping-baskets',
          label: 'Panier',
        },
      ],
      getDescriptor: () => ({ presentation: {} }),
    } as unknown as GameRuntime;

    const payload = createPresenter().present({
      state,
      handler,
      roomId: 6,
      gameType: 'panier-express',
      version: 1,
      viewerPlayerId: 1,
    });

    expect((payload.system as any).shortcuts).toEqual([
      {
        key: 'S',
        type: 'interface',
        id: 'inventory:shopping-baskets',
        label: 'Panier',
      },
    ]);
  });

  it('publishes ready-to-render event messages for LAMA', () => {
    const state = {
      status: 'playing',
      phase: 'turn',
      turn: { currentPlayerId: 1, direction: 1 },
      players: [{ id: 1, username: 'Lila' }],
      metadata: {},
    } as unknown as GameState;
    const exposed = {
      ...state,
      actions: [],
      system: {
        match: { status: 'playing' },
        players: { all: [{ id: 1, username: 'Lila' }] },
        events: {
          recent: [
            {
              id: '2:2',
              type: 'score.changed',
              data: {
                playerId: 1,
                previous: 12,
                value: 2,
                delta: -10,
              },
            },
          ],
          latestByType: {
            'game.message': {
              id: '2:0',
              type: 'game.message',
              actorId: 1,
              occurredAtMs: 10,
              data: {
                key: 'game.card.played',
                params: {
                  playerId: 1,
                  cardId: 'LAMA',
                  cardLabel: 'LAMA',
                },
              },
            },
            'score.changed': {
              id: '2:1',
              type: 'score.changed',
              data: { playerId: 1, value: 12 },
            },
          },
        },
      },
      kits: {
        score: {
          byPlayer: { '1': 12 },
          leaderboard: [{ playerId: 1, score: 12, rank: 1 }],
        },
      },
    };
    const handler = {
      exposeStateForUser: () => exposed,
      getShortcuts: () => [],
      getDescriptor: () => ({
        presentation: {
          score: {
            label: 'Jetons',
            unit: { singular: 'jeton', plural: 'jetons' },
            changeNarration: 'delta-and-total',
          },
        },
      }),
    } as unknown as GameRuntime;

    const payload = createPresenter().present({
      state,
      handler,
      roomId: 6,
      gameType: 'lama',
      version: 2,
      viewerPlayerId: 1,
    });
    const system = payload.system as {
      events: {
        latestByType: Record<string, { data: { message?: string } }>;
      };
    };
    expect(system.events.latestByType['game.message']?.data.message).toBe(
      'Vous jouez LAMA.',
    );
    expect(system.events.latestByType['score.changed']?.data.message).toBe(
      'Vous avez maintenant 12 jetons.',
    );
    expect((payload.kits as any).score).toMatchObject({
      label: 'Jetons',
      unit: { singular: 'jeton', plural: 'jetons' },
    });
    expect((payload.system as any).events.recent[0].data.message).toBe(
      'Vous rendez 10 jetons et en avez maintenant 2.',
    );
  });

  it('announces a pawn choice to its author and to every other player', () => {
    const state = {
      status: 'playing',
      players: [
        { id: 1, username: 'Hacene' },
        { id: 2, username: 'Mina' },
      ],
      metadata: {},
    } as unknown as GameState;
    const exposed = {
      system: {
        match: { status: 'playing' },
        players: { all: state.players },
        events: {
          recent: [
            {
              id: '4:0',
              type: 'pawn.assigned',
              actorId: 1,
              data: {
                playerId: 1,
                pawnId: 'capitaine-cacahuete',
                pawnLabel: 'Capitaine Cacahuète',
              },
            },
          ],
          latestByType: {},
        },
      },
      kits: {},
      actions: [],
    };
    const handler = {
      exposeStateForUser: () => exposed,
      getShortcuts: () => [],
    } as unknown as GameRuntime;
    const presentFor = (viewerPlayerId: number) =>
      (
        createPresenter().present({
          state,
          handler,
          roomId: 8,
          gameType: 'a-fond-les-ballons',
          version: 4,
          viewerPlayerId,
        }).system as any
      ).events.recent[0].data.message;

    expect(presentFor(1)).toBe('Vous avez choisi « Capitaine Cacahuète ».');
    expect(presentFor(2)).toBe('Hacene a choisi « Capitaine Cacahuète ».');
  });

  it('announces who must choose a pawn without calling it a turn', () => {
    const players = [
      { id: 1, username: 'Hacene' },
      { id: 2, username: 'Mina' },
    ];
    const event = {
      id: '4:1',
      type: 'game.message',
      data: {
        key: 'game.pawn.selection-requested',
        params: { playerId: 1 },
      },
    };
    const handler = {
      exposeStateForUser: () => ({
        system: {
          match: { status: 'playing' },
          players: { all: players },
          events: { recent: [event], latestByType: { 'game.message': event } },
        },
        kits: {},
        actions: [],
      }),
      getShortcuts: () => [],
    } as unknown as GameRuntime;
    const presentFor = (viewerPlayerId: number) =>
      (
        createPresenter().present({
          state: {
            status: 'playing',
            players,
            metadata: {},
          } as unknown as GameState,
          handler,
          roomId: 8,
          gameType: 'a-fond-les-ballons',
          version: 4,
          viewerPlayerId,
        }).system as any
      ).events.recent[0].data.message;

    expect(presentFor(1)).toBe('Vous devez choisir votre pion.');
    expect(presentFor(2)).toBe('Hacene doit choisir son pion.');
  });

  it('announces the drawn card value only to the player who drew it', () => {
    const state = {
      status: 'started',
      turn: { currentPlayerId: 1 },
      players: [{ id: 1, username: 'Lila' }],
      metadata: {},
    } as unknown as GameState;
    const handler = {
      exposeStateForUser: () => ({
        system: {
          match: { status: 'started' },
          players: {
            all: [
              { id: 1, username: 'Lila' },
              { id: 2, username: 'Mina' },
            ],
          },
          events: {
            latestByType: {
              'card.received': {
                id: '3:1',
                type: 'card.received',
                actorId: 1,
                data: { playerId: 1, card: 'LAMA' },
              },
              'game.message': {
                id: '3:0',
                type: 'game.message',
                data: {
                  key: 'game.card.drawn',
                  params: { playerId: 1, deckId: 'lama' },
                },
              },
              'turn.started': {
                id: '3:2',
                type: 'turn.started',
                data: { playerId: 2 },
              },
            },
          },
        },
        actions: [],
      }),
      getShortcuts: () => [],
    } as unknown as GameRuntime;
    const payload = createPresenter().present({
      state,
      handler,
      roomId: 6,
      gameType: 'lama',
      version: 3,
      viewerPlayerId: 1,
    });
    expect(
      ((payload.system as any).events.latestByType['game.message'] as any).data
        .message,
    ).toBe('Vous piochez LAMA.');
    expect(
      ((payload.system as any).events.latestByType['card.received'] as any).data
        .message,
    ).toBeUndefined();
    expect(
      ((payload.system as any).events.latestByType['turn.started'] as any).data
        .message,
    ).toBe("C'est au tour de Mina.");

    const opponentPayload = createPresenter().present({
      state,
      handler: {
        ...handler,
        exposeStateForUser: () => ({
          system: {
            match: { status: 'started' },
            players: {
              all: [
                { id: 1, username: 'Lila' },
                { id: 2, username: 'Mina' },
              ],
            },
            events: {
              latestByType: {
                'card.received': {
                  id: '3:1',
                  type: 'card.received',
                  actorId: 1,
                  data: { playerId: 1 },
                },
                'game.message': {
                  id: '3:0',
                  type: 'game.message',
                  data: {
                    key: 'game.card.drawn',
                    params: { playerId: 1, deckId: 'lama' },
                  },
                },
                'turn.started': {
                  id: '3:2',
                  type: 'turn.started',
                  data: { playerId: 2 },
                },
              },
            },
          },
          actions: [],
        }),
      } as unknown as GameRuntime,
      roomId: 6,
      gameType: 'lama',
      version: 3,
      viewerPlayerId: 2,
    });
    expect(
      (
        (opponentPayload.system as any).events.latestByType[
          'game.message'
        ] as any
      ).data.message,
    ).toBe('Lila pioche une carte.');
  });

  it('announces a revealed card and its effect', () => {
    const state = {
      status: 'started',
      players: [
        { id: 1, username: 'Lila' },
        { id: 2, username: 'Mina' },
      ],
    } as unknown as GameState;
    const handler = {
      exposeStateForUser: () => ({
        system: {
          match: { status: 'started' },
          players: { all: state.players },
          events: {
            latestByType: {
              'game.message': {
                id: '4:0',
                type: 'game.message',
                data: {
                  key: 'game.card.drawn',
                  params: {
                    playerId: 1,
                    revealed: true,
                    cardLabel: 'Coup de chance',
                    effectDescription: 'Avancez de 2 cases',
                  },
                },
              },
            },
          },
        },
        actions: [],
      }),
      getShortcuts: () => [],
    } as unknown as GameRuntime;

    const payload = createPresenter().present({
      state,
      handler,
      roomId: 6,
      gameType: 'panier-express',
      version: 4,
      viewerPlayerId: 1,
    });

    expect(
      ((payload.system as any).events.latestByType['game.message'] as any).data
        .message,
    ).toBe('Vous piochez « Coup de chance ». Effet : Avancez de 2 cases.');
  });

  it('does not repeat an effect already written on a revealed card', () => {
    const state = {
      status: 'started',
      players: [{ id: 1, username: 'Lila' }],
    } as unknown as GameState;
    const handler = {
      exposeStateForUser: () => ({
        system: {
          match: { status: 'started' },
          players: { all: state.players },
          events: {
            latestByType: {
              'game.message': {
                id: '5:0',
                type: 'game.message',
                data: {
                  key: 'game.card.drawn',
                  params: {
                    playerId: 1,
                    revealed: true,
                    cardLabel:
                      "Le sol colle à vos chaussures. Au prochain tour, vous n'avancerez que d'une seule case.",
                    effectDescription:
                      "Au prochain tour, vous n'avancerez que d'une seule case.",
                  },
                },
              },
            },
          },
        },
        actions: [],
      }),
      getShortcuts: () => [],
    } as unknown as GameRuntime;

    const payload = createPresenter().present({
      state,
      handler,
      roomId: 6,
      gameType: 'frousse-party',
      version: 5,
      viewerPlayerId: 1,
    });

    expect(
      ((payload.system as any).events.latestByType['game.message'] as any).data
        .message,
    ).toBe(
      "Vous piochez « Le sol colle à vos chaussures. Au prochain tour, vous n'avancerez que d'une seule case. ».",
    );
  });

  it('narrates chained landings and draws once each', () => {
    const events = [
      {
        id: '12:0',
        sequence: 0,
        type: 'pawn.landed',
        data: { playerId: 1, position: 5 },
      },
      {
        id: '12:1',
        sequence: 1,
        type: 'pawn.landed',
        data: { playerId: 1, position: 5, tileLabel: 'Animal rigolo' },
      },
      {
        id: '12:2',
        sequence: 2,
        type: 'card.drawn',
        data: { playerId: 1, deckId: 'animal' },
      },
      {
        id: '12:3',
        sequence: 3,
        type: 'game.message',
        data: {
          key: 'game.card.drawn',
          params: {
            playerId: 1,
            revealed: true,
            cardLabel: 'Rencontre animale 1',
            effectDescription: 'Avancez de 2 cases',
          },
        },
      },
      {
        id: '12:4',
        sequence: 4,
        type: 'pawn.landed',
        data: { playerId: 1, position: 7 },
      },
      {
        id: '12:5',
        sequence: 5,
        type: 'pawn.landed',
        data: { playerId: 1, position: 7, tileLabel: 'Sentier 8' },
      },
      {
        id: '12:6',
        sequence: 6,
        type: 'turn.started',
        data: { playerId: 2 },
      },
    ];
    const players = [
      { id: 1, username: 'Lila' },
      { id: 2, username: 'Mina' },
    ];
    const handler = {
      exposeStateForUser: () => ({
        system: {
          match: { status: 'started' },
          players: { all: players },
          events: {
            recent: events,
            latestByType: Object.fromEntries(
              events.map((event) => [event.type, event]),
            ),
          },
        },
        actions: [],
      }),
      getShortcuts: () => [],
    } as unknown as GameRuntime;

    const payload = createPresenter().present({
      state: { status: 'started', players } as unknown as GameState,
      handler,
      roomId: 6,
      gameType: 'aventure-sauvage',
      version: 12,
      viewerPlayerId: 1,
    });
    const messages = (payload.system as any).events.recent
      .map((event: any) => event.data.message)
      .filter(Boolean);

    expect(messages).toEqual([
      'Vous arrivez sur la case 6 : Animal rigolo.',
      'Vous piochez « Rencontre animale 1 ». Effet : Avancez de 2 cases.',
      'Vous arrivez sur la case 8 : Sentier 8.',
      "C'est au tour de Mina.",
    ]);
  });

  it('announces a player leaving a round through the standard event', () => {
    const state = {
      status: 'started',
      players: [
        { id: 1, username: 'Lila' },
        { id: 2, username: 'Mina' },
      ],
    } as unknown as GameState;
    const handler = {
      exposeStateForUser: () => ({
        system: {
          match: { status: 'started' },
          players: { all: state.players },
          events: {
            latestByType: {
              'match.started': {
                id: '9:0',
                type: 'match.started',
                data: {},
              },
              'round.player-left': {
                id: '9:1',
                type: 'round.player-left',
                data: { playerId: 2 },
              },
            },
          },
        },
        actions: [],
      }),
      getShortcuts: () => [],
    } as unknown as GameRuntime;

    const payload = createPresenter().present({
      state,
      handler,
      roomId: 6,
      gameType: 'example',
      version: 9,
      viewerPlayerId: 1,
    });

    expect(
      (payload.system as any).events.latestByType['round.player-left'].data
        .message,
    ).toBe('Mina sort de la manche.');
    expect(
      (payload.system as any).events.latestByType['match.started'].data.message,
    ).toBe('La partie démarre, bon jeu !');
  });

  it.each([
    ['game.player.passed', 'Vous passez votre tour.', false],
    [
      'game.card.drawn',
      'Vous piochez une carte. Son effet est appliqué automatiquement.',
      true,
    ],
  ])(
    'announces the next player in the same utterance after %s',
    (messageKey, actionMessage, automatic) => {
      const events = [
        {
          id: '10:0',
          type: 'game.message',
          data: {
            key: messageKey,
            params: { playerId: 1, ...(automatic ? { automatic: true } : {}) },
          },
        },
        {
          id: '10:1',
          type: 'turn.started',
          data: { playerId: 2 },
        },
      ];
      const handler = {
        exposeStateForUser: () => ({
          system: {
            match: { status: 'started' },
            players: {
              all: [
                { id: 1, username: 'Lila' },
                { id: 2, username: 'Mina' },
              ],
            },
            events: {
              recent: events,
              latestByType: {
                'game.message': events[0],
                'turn.started': events[1],
              },
            },
          },
          actions: [],
        }),
        getShortcuts: () => [],
      } as unknown as GameRuntime;

      const payload = createPresenter().present({
        state: {
          status: 'started',
          players: [
            { id: 1, username: 'Lila' },
            { id: 2, username: 'Mina' },
          ],
        } as unknown as GameState,
        handler,
        roomId: 6,
        gameType: 'example',
        version: 10,
        viewerPlayerId: 1,
      });
      const messages = (payload.system as any).events.recent
        .map((event: any) => event.data.message)
        .filter(Boolean);

      expect(messages).toEqual([`${actionMessage}\nC'est au tour de Mina.`]);
    },
  );

  it('does not repeat two consecutive announcements for the same turn', () => {
    const events = [
      {
        id: '10:0',
        type: 'turn.started',
        data: { playerId: 1, turnNumber: 1 },
      },
      {
        id: '10:intermediate',
        type: 'pawn.assigned',
        data: {
          playerId: 1,
          pawnId: 'capitaine-cacahuete',
          pawnLabel: 'Capitaine Cacahuète',
        },
      },
      {
        id: '10:1',
        type: 'turn.started',
        data: { playerId: 1, turnNumber: 1 },
      },
    ];
    const handler = {
      exposeStateForUser: () => ({
        system: {
          match: { status: 'started' },
          players: { all: [{ id: 1, username: 'Hacene' }] },
          events: {
            recent: events,
            latestByType: { 'turn.started': events[1] },
          },
        },
        actions: [],
      }),
      getShortcuts: () => [],
    } as unknown as GameRuntime;

    const payload = createPresenter().present({
      state: {
        status: 'started',
        players: [{ id: 1, username: 'Hacene' }],
      } as unknown as GameState,
      handler,
      roomId: 6,
      gameType: 'panier-express',
      version: 10,
      viewerPlayerId: 1,
    });
    const messages = (payload.system as any).events.recent
      .map((event: any) => event.data.message)
      .filter(Boolean);

    expect(messages).toEqual([
      'Vous avez choisi « Capitaine Cacahuète ».',
      "C'est au tour de Hacene.",
    ]);
  });

  it('explains manual draws and movement bonuses to players and spectators', () => {
    const events = [
      {
        id: '11:0',
        type: 'game.message',
        data: {
          key: 'game.card.draw-required',
          params: { playerId: 1 },
        },
      },
      {
        id: '11:1',
        type: 'game.message',
        data: {
          key: 'game.pawn.bonus-advance',
          params: { playerId: 1, spaces: 2 },
        },
      },
      {
        id: '11:2',
        type: 'game.message',
        data: {
          key: 'game.card.draw-required',
          params: { playerId: 2 },
        },
      },
      {
        id: '11:3',
        type: 'game.message',
        data: {
          key: 'game.pawn.bonus-advance',
          params: { playerId: 2, spaces: 2 },
        },
      },
      {
        id: '11:4',
        type: 'game.message',
        data: {
          key: 'game.positions.swapped',
          params: { actorId: 2, targetId: 1 },
        },
      },
    ];
    const handler = {
      exposeStateForUser: () => ({
        system: {
          match: { status: 'started' },
          players: {
            all: [
              { id: 1, username: 'Lila' },
              { id: 2, username: 'Mina' },
            ],
          },
          events: {
            recent: events,
            latestByType: { 'game.message': events.at(-1) },
          },
        },
        actions: [],
      }),
      getShortcuts: () => [],
    } as unknown as GameRuntime;

    const payload = createPresenter().present({
      state: {
        status: 'started',
        players: [
          { id: 1, username: 'Lila' },
          { id: 2, username: 'Mina' },
        ],
      } as unknown as GameState,
      handler,
      roomId: 6,
      gameType: 'example',
      version: 11,
      viewerPlayerId: 1,
    });
    const messages = (payload.system as any).events.recent.map(
      (event: any) => event.data.message,
    );

    expect(messages).toEqual([
      'Vous devez piocher une carte. Appuyez sur Espace.',
      'Bonus : vous avancez de 2 cases.',
      'Mina doit piocher une carte.',
      'Bonus : Mina avance de 2 cases.',
      'Mina échange sa place avec vous.',
    ]);
  });

  it('presents a LAMA round start as one player-facing narrative', () => {
    const state = {
      status: 'started',
      turn: { currentPlayerId: 1 },
      players: [{ id: 1, username: 'hacene' }],
      metadata: {},
    } as unknown as GameState;
    const handler = {
      exposeStateForUser: () => ({
        system: {
          match: { status: 'started' },
          players: { all: [{ id: 1, username: 'hacene' }] },
          events: {
            recent: [
              {
                id: '4:4',
                type: 'game.message',
                occurredAtMs: 14,
                sequence: 4,
                data: {
                  key: 'game.round.started',
                  params: {
                    round: 1,
                    firstCardId: 'LAMA',
                    starterPlayerId: 1,
                  },
                },
              },
            ],
            latestByType: {
              'game.message': {
                id: '4:4',
                type: 'game.message',
                occurredAtMs: 14,
                data: {
                  key: 'game.round.started',
                  params: {
                    round: 1,
                    firstCardId: 'LAMA',
                    starterPlayerId: 1,
                  },
                },
              },
              'turn.started': {
                id: '4:3',
                type: 'turn.started',
                occurredAtMs: 13,
                data: { playerId: 1 },
              },
              'card.drawn': {
                id: '4:2',
                type: 'card.drawn',
                actorId: 1,
                occurredAtMs: 12,
                data: { deckId: 'lama' },
              },
              'round.started': {
                id: '4:0',
                type: 'round.started',
                occurredAtMs: 10,
                data: { number: 1 },
              },
            },
          },
        },
        kits: {
          cards: {
            hands: {
              'cards-discard-penalty-hands': {
                byPlayer: { '1': [1, 2, 'LAMA'] },
              },
            },
          },
        },
        actions: [],
      }),
      getShortcuts: () => [],
    } as unknown as GameRuntime;
    const payload = createPresenter().present({
      state,
      handler,
      roomId: 6,
      gameType: 'lama',
      version: 4,
      viewerPlayerId: 1,
    });
    const events = (payload.system as any).events.latestByType;
    expect(events['game.message'].data.message).toBe(
      "La partie démarre.\nTout le monde reçoit son paquet de cartes.\nC'est au tour de hacene.",
    );
    expect((payload.system as any).events.recent[0].data.message).toBe(
      events['game.message'].data.message,
    );
    expect(events['card.drawn']?.data.message).toBeUndefined();
    expect(events['turn.started'].data.message).toBeUndefined();
    expect(events['round.started'].data.message).toBeUndefined();
  });

  it('presents a LAMA round transition in its emission order', () => {
    const recent = [
      {
        id: '8:0',
        type: 'round.ended',
        occurredAtMs: 20,
        sequence: 0,
        data: { number: 1 },
      },
      {
        id: '8:1',
        type: 'score.changed',
        occurredAtMs: 20,
        sequence: 1,
        data: {
          playerId: 1,
          previous: 0,
          value: 3,
          delta: 3,
        },
      },
      {
        id: '8:2',
        type: 'score.changed',
        occurredAtMs: 20,
        sequence: 2,
        data: {
          playerId: 2,
          previous: 0,
          value: 5,
          delta: 5,
        },
      },
      {
        id: '8:3',
        type: 'game.message',
        occurredAtMs: 20,
        sequence: 3,
        data: {
          key: 'game.round.started',
          params: { round: 2, starterPlayerId: 2 },
        },
      },
    ];
    const handler = {
      exposeStateForUser: () => ({
        system: {
          match: { status: 'started' },
          players: {
            all: [
              { id: 1, username: 'Lila' },
              { id: 2, username: 'Mina' },
            ],
          },
          events: {
            recent,
            latestByType: {
              'round.ended': recent[0],
              'score.changed': recent[2],
              'game.message': recent[3],
            },
          },
        },
        kits: {
          cards: {
            hands: {
              'cards-discard-penalty-hands': {
                byPlayer: { '1': [2, 3, 'LAMA'] },
              },
            },
          },
        },
        actions: [],
      }),
      getShortcuts: () => [],
      getDescriptor: () => ({
        presentation: {
          score: {
            label: 'Jetons',
            unit: { singular: 'jeton', plural: 'jetons' },
            changeNarration: 'delta-and-total',
          },
        },
      }),
    } as unknown as GameRuntime;
    const payload = createPresenter().present({
      state: {
        status: 'started',
        players: [
          { id: 1, username: 'Lila' },
          { id: 2, username: 'Mina' },
        ],
      } as unknown as GameState,
      handler,
      roomId: 6,
      gameType: 'lama',
      version: 8,
      viewerPlayerId: 1,
    });
    const messages = (payload.system as any).events.recent
      .map((event: any) => event.data.message)
      .filter(Boolean);
    expect(messages).toEqual([
      'La manche est terminée.',
      'Vous recevez 3 jetons et en avez maintenant 3.',
      'Mina reçoit 5 jetons et en a maintenant 5.',
      "La manche 2 commence.\nTout le monde reçoit son paquet de cartes.\nC'est au tour de Mina.",
    ]);
  });

  it('publishes a server-driven configuration prompt without rewriting', () => {
    const prompt = {
      type: 'config_prompt',
      label: 'Configuration',
      data: {
        actionType: 'configure',
        fields: [{ key: 'score', label: 'Score', kind: 'number' }],
      },
    };
    const state = {
      status: 'started',
      phase: 'setup',
      turnIndex: 0,
      players: [],
      turn: { currentPlayerId: null, direction: 1 },
      metadata: {},
      pending: prompt,
      actions: [{ type: 'configure', payload: {} }],
    } as unknown as GameState;
    const handler = {
      exposeStateForUser: () => state,
      getShortcuts: () => [],
    } as unknown as GameRuntime;

    const payload = createPresenter().present({
      state,
      handler,
      roomId: 3,
      gameType: 'example',
      version: 1,
    });
    expect(payload.pending).toEqual(prompt);
  });

  it('preserves an explicit server mapping between pending choices and actions', () => {
    const mappedAction = { type: 'pick_beta', payload: { value: 2 } };
    const state = {
      status: 'started',
      phase: 'turn',
      turnIndex: 1,
      players: [{ id: 1, username: 'A' }],
      turn: { currentPlayerId: 1, direction: 1 },
      metadata: {},
      actions: [{ type: 'unrelated_action', payload: {} }, mappedAction],
      pending: {
        type: 'pick_one',
        playerId: 1,
        choices: ['Beta'],
        data: { choiceActionsByIndex: [mappedAction] },
      },
    } as unknown as GameState;
    const handler = {
      exposeStateForUser: () => state,
      getShortcuts: () => [],
    } as unknown as GameRuntime;

    const payload = createPresenter().present({
      state,
      handler,
      roomId: 5,
      gameType: 'opaque-game',
      version: 2,
      viewerPlayerId: 1,
    });
    expect((payload.pending as any).data.choiceActionsByIndex).toEqual([
      mappedAction,
    ]);
  });

  it('publishes the generic dice contract', () => {
    const state = {
      status: 'started',
      phase: 'turn',
      turn: { currentPlayerId: null, direction: 1, turnNumber: 3 },
      system: { turn: { number: 3 } },
      players: [],
      actions: [{ type: 'roll', payload: {} }],
      kits: { dice: { total: 5 } },
    } as unknown as GameState;
    const handler = {
      exposeStateForUser: () => state,
      getShortcuts: () => [],
    } as unknown as GameRuntime;

    const payload = createPresenter().present({
      state,
      handler,
      roomId: 4,
      gameType: 'dice-game',
      version: 8,
    });
    expect((payload.kits as any).dice).toEqual(
      expect.objectContaining({ total: 5, rollActionIndex: 0 }),
    );
    expect(payload.state).toBeUndefined();
  });
});
