import { GameTaskDispatchService } from './game-task-dispatch.service';
import { GameAutomationPlannerService } from './game-automation-planner.service';
import type { GameRuntime } from '../ports/game-runtime.port';
import type { GameState } from '../models/game-state.model';
import type {
  GameScheduledTask,
  GameTaskProcessor,
} from '../ports/game-task-scheduler.port';
import { GameRealtimeAutomationService } from './game-realtime-automation.service';

describe('GameRealtimeAutomationService', () => {
  it('refuses automation after room reset even before session reconciliation', async () => {
    const test = harness();
    test.service.schedule({
      roomId: 12,
      gameType: 'example',
      handler: test.runtime,
      state: test.current,
    });
    await Promise.resolve();
    const task = test.scheduled[0];
    if (!task) throw new Error('Missing task');
    test.rooms.isCurrent.mockResolvedValue(false);
    await test.processor()(task);
    expect(test.executor.execute).not.toHaveBeenCalled();
    expect(test.engine.compareAndSetInternalState).not.toHaveBeenCalled();
    test.rooms.isCurrent.mockRejectedValueOnce(
      new Error('database unavailable'),
    );
    await expect(test.processor()(task)).rejects.toThrow(
      'database unavailable',
    );
    expect(test.executor.execute).not.toHaveBeenCalled();
  });
  it.each(['deleted', 'finished'])(
    'discards a %s session task even when its old runtime is no longer installed',
    async (status) => {
      const test = harness();
      test.service.schedule({
        roomId: 12,
        gameType: 'example',
        handler: test.runtime,
        state: test.current,
      });
      await Promise.resolve();
      const task = test.scheduled[0];
      if (!task) throw new Error('Missing task');
      test.engine.exportInternalState.mockResolvedValue(
        status === 'deleted' ? null : state({ status: 'finished' }),
      );
      test.registry.getHandler.mockReturnValue(undefined);
      await expect(test.processor()(task)).resolves.toBeUndefined();
      expect(test.executor.execute).not.toHaveBeenCalled();
      expect(test.engine.compareAndSetInternalState).not.toHaveBeenCalled();
      expect(test.registry.getHandler).not.toHaveBeenCalled();
    },
  );
  it('invalidates a pre-restoration delivery with identical run, generation and versions', async () => {
    const test = harness(state({ metadata: { restoreId: 'new-restore' } }));
    test.service.schedule({
      roomId: 12,
      gameType: 'example',
      handler: test.runtime,
      state: test.current,
    });
    await Promise.resolve();
    const task = test.scheduled[0]!;
    await test.processor()({ ...task, restoreId: 'old-restore' });
    await test.processor()({ ...task, restoreId: undefined });
    expect(test.executor.execute).not.toHaveBeenCalled();
    await test.processor()(task);
    expect(test.engine.compareAndSetInternalState).toHaveBeenCalledWith(
      12,
      'example',
      4,
      expect.any(Object),
      'new-restore',
    );
  });
  it.each(['schemaVersion', 'contentVersion', 'rulesVersion'] as const)(
    'invalidates deliveries after a %s change even with identical run/generation/signature',
    async (field) => {
      const originalIdentity = {
        schemaVersion: 1,
        contentVersion: 'content-1',
        rulesVersion: 'rules-1',
      };
      const test = harness(
        state({ engine: originalIdentity, metadata: { roomRunId: 4 } }),
      );
      test.service.schedule({
        roomId: 12,
        gameType: 'example',
        handler: test.runtime,
        state: test.current,
      });
      await Promise.resolve();
      const original = structuredClone(test.scheduled[0]!);
      const changed = {
        ...originalIdentity,
        [field]: field === 'schemaVersion' ? 2 : 'version-2',
      };
      test.engine.exportInternalState.mockResolvedValue(
        state({ engine: changed, metadata: { roomRunId: 4 } }),
      );
      await test.processor()(original);
      await Promise.resolve();
      expect(test.executor.execute).not.toHaveBeenCalled();
      expect(test.engine.compareAndSetInternalState).not.toHaveBeenCalled();
      expect(test.scheduled.at(-1)?.stateIdentity).toEqual(changed);
      await test.processor()({ ...original, stateIdentity: undefined });
      expect(test.executor.execute).not.toHaveBeenCalled();
    },
  );

  it('rejects malformed deliveries before acquiring a room lock or reading state', async () => {
    const test = harness();
    await expect(
      test.processor()({ roomId: -1 } as GameScheduledTask),
    ).rejects.toThrow('Invalid game scheduled task');
    expect(test.queue.run).not.toHaveBeenCalled();
    expect(test.engine.exportInternalState).not.toHaveBeenCalled();
  });

  const state = (overrides: Record<string, unknown> = {}) =>
    ({
      status: 'started',
      version: 4,
      players: [{ id: 1, username: 'Alice', isBot: false }],
      turn: { currentPlayerId: 1, direction: 1, turnNumber: 2 },
      metadata: {},
      ...overrides,
    }) as unknown as GameState;

  const handler = (executeAtMs = Date.now() - 1, actionType = 'resume') =>
    ({
      gameType: 'example',
      getAutomaticActions: () => ({
        key: 'pause:2',
        executeAtMs,
        actions: [{ type: actionType, payload: {} }],
      }),
    }) as unknown as GameRuntime;

  function harness(
    current = state(),
    runtime = handler(),
    suggestedActions: Array<{ type: string; payload: object }> = [],
  ) {
    let processor: GameTaskProcessor | undefined;
    const scheduled: GameScheduledTask[] = [];
    const scheduler = {
      registerProcessor: jest.fn((value: GameTaskProcessor) => {
        processor = value;
      }),
      schedule: jest.fn(async (task: GameScheduledTask) => {
        scheduled.push(task);
      }),
      cancel: jest.fn(async (): Promise<void> => undefined),
      cancelRoom: jest.fn(async (): Promise<void> => undefined),
    };
    const next = state({ version: 4, metadata: { resumed: true } });
    const engine = {
      exportInternalState: jest.fn().mockResolvedValue(current),
      compareAndSetInternalState: jest.fn().mockResolvedValue({
        committed: true,
        version: 5,
        state: { ...next, version: 5 },
      }),
    };
    const executor = { execute: jest.fn().mockReturnValue(next) };
    const queue = {
      run: jest.fn((_roomId: number, command: () => Promise<void>) =>
        command(),
      ),
    };
    const registry = {
      getHandler: jest.fn((): GameRuntime | undefined => runtime),
    };
    const rooms = { isCurrent: jest.fn(async () => true) };
    const service = new GameRealtimeAutomationService(
      engine as never,
      new GameAutomationPlannerService(
        {
          suggestForHandler: jest.fn().mockReturnValue(suggestedActions),
        } as never,
        {
          getBotTurnDelayMs: () => 25,
          getBotStartDelayMs: () => 25,
          getBotDrawDelayMs: () => 25,
        } as never,
      ),
      new GameTaskDispatchService(scheduler),
      executor as never,
      queue as never,
      rooms,
      undefined,
      registry as never,
    );
    service.onModuleInit();
    return {
      service,
      rooms,
      registry,
      scheduler,
      scheduled,
      engine,
      executor,
      queue,
      processor: () => processor!,
      runtime,
      current,
    };
  }

  it('persists a stable task identity and absolute deadline in the scheduler', async () => {
    const dueAtMs = Date.now() + 1_000;
    const test = harness(state(), handler(dueAtMs));
    test.service.schedule({
      roomId: 12,
      gameType: 'example',
      handler: test.runtime,
      state: test.current,
    });
    await Promise.resolve();
    expect(test.scheduled).toEqual([
      expect.objectContaining({
        key: 'game-realtime:12:example',
        roomId: 12,
        gameType: 'example',
        generation: 4,
        dueAtMs,
      }),
    ]);
  });

  it('executes a due task through the command executor and an atomic CAS', async () => {
    const test = harness();
    const committed = jest.fn();
    test.service.setStateCommittedHandler(committed);
    test.service.schedule({
      roomId: 12,
      gameType: 'example',
      handler: test.runtime,
      state: test.current,
    });
    await Promise.resolve();
    await test.processor()(test.scheduled[0]!);

    expect(test.queue.run).toHaveBeenCalledWith(12, expect.any(Function));

    expect(test.executor.execute).toHaveBeenCalledWith(
      expect.objectContaining({
        handler: test.runtime,
        state: test.current,
        roomId: 12,
        actions: [
          expect.objectContaining({
            type: 'resume',
            meta: expect.objectContaining({ commandId: expect.any(String) }),
          }),
        ],
      }),
    );
    expect(test.engine.compareAndSetInternalState).toHaveBeenCalledWith(
      12,
      'example',
      4,
      expect.any(Object),
      null,
    );
    expect(committed).toHaveBeenCalledWith(
      expect.objectContaining({
        roomId: 12,
        gameType: 'example',
        handler: test.runtime,
        version: 5,
      }),
    );
  });

  it('does not commit or reschedule an already applied automatic command', async () => {
    const current = state();
    const test = harness(current);
    test.executor.execute.mockReturnValue(structuredClone(current));
    test.service.schedule({
      roomId: 12,
      gameType: 'example',
      handler: test.runtime,
      state: current,
    });
    await Promise.resolve();

    await test.processor()(test.scheduled[0]!);

    expect(test.engine.compareAndSetInternalState).not.toHaveBeenCalled();
    expect(test.scheduler.schedule).toHaveBeenCalledTimes(1);
  });

  it('executes a bot task when its persisted deadline is due', async () => {
    const botState = state({
      players: [{ id: -7, username: 'Bot LAMA', isBot: true }],
      turn: { currentPlayerId: -7, direction: 1, turnNumber: 3 },
      engine: { round: { number: 2 } },
    });
    const runtime = {
      gameType: 'lama',
      getAutomaticActions: () => null,
    } as unknown as GameRuntime;
    const test = harness(botState, runtime, [{ type: 'draw', payload: {} }]);
    test.service.schedule({
      roomId: 12,
      gameType: 'lama',
      handler: runtime,
      state: botState,
    });
    await Promise.resolve();
    const task = test.scheduled[0]!;
    expect(task.signature).toBe('bot:-7:play:round:2:turn:3');
    task.dueAtMs = Date.now() - 1;

    await test.processor()(task);

    expect(test.executor.execute).toHaveBeenCalledWith(
      expect.objectContaining({
        actorId: null,
        actions: [
          expect.objectContaining({
            type: 'draw',
            meta: expect.objectContaining({
              actorId: -7,
              commandId: expect.stringMatching(/^automatic:[a-f0-9]{64}$/),
            }),
          }),
        ],
      }),
    );
  });

  it('uses a fresh command identity for consecutive bot actions in the same turn', async () => {
    const runtime = {
      gameType: 'a-fond-les-ballons',
      getAutomaticActions: () => null,
    } as unknown as GameRuntime;
    const botTurn = (version: number) =>
      state({
        version,
        players: [{ id: -7, username: 'Pumbaa', isBot: true }],
        turn: { currentPlayerId: -7, direction: 1, turnNumber: 3 },
        engine: { round: { number: 2 } },
      });
    const test = harness(botTurn(4), runtime, [
      { type: 'draw_card', payload: {} },
    ]);
    test.engine.exportInternalState
      .mockResolvedValueOnce(botTurn(4))
      .mockResolvedValueOnce(botTurn(5));
    const baseTask = {
      key: 'game-realtime:12:a-fond-les-ballons',
      roomId: 12,
      gameType: 'a-fond-les-ballons',
      signature: 'bot:-7:play:round:2:turn:3',
      dueAtMs: Date.now() - 1,
    };

    await test.processor()({ ...baseTask, generation: 4 });
    await test.processor()({ ...baseTask, generation: 5 });

    const commandIds = test.executor.execute.mock.calls.map(
      ([input]) => input.actions[0].meta.commandId,
    );
    expect(commandIds).toEqual([
      expect.stringMatching(/^automatic:[a-f0-9]{64}$/),
      expect.stringMatching(/^automatic:[a-f0-9]{64}$/),
    ]);
    expect(commandIds[0]).not.toBe(commandIds[1]);
  });

  it('lets an unresolved bot answer a collective choice during a human turn', async () => {
    const collectiveChoice = state({
      players: [
        { id: 1, username: 'Alice', isBot: false },
        { id: -7, username: 'Bot Ballons', isBot: true },
      ],
      turn: { currentPlayerId: 1, direction: 1, turnNumber: 2 },
      pending: {
        type: 'choice',
        playerIds: [1, -7],
        resolvedPlayerIds: [],
        data: {
          choiceId: 'race-chained-tile-cards.pawn',
          options: ['blue', 'red'],
        },
      },
    });
    const runtime = {
      gameType: 'a-fond-les-ballons',
      getAutomaticActions: () => null,
    } as unknown as GameRuntime;
    const test = harness(collectiveChoice, runtime, [
      { type: 'choice.resolve', payload: { value: 'red' } },
    ]);

    test.service.schedule({
      roomId: 12,
      gameType: 'a-fond-les-ballons',
      handler: runtime,
      state: collectiveChoice,
    });
    await Promise.resolve();

    expect(test.scheduled[0]).toEqual(
      expect.objectContaining({
        signature: 'bot:-7:choice:race-chained-tile-cards.pawn:round:0:turn:2',
      }),
    );
    const task = test.scheduled[0]!;
    task.dueAtMs = Date.now() - 1;
    await test.processor()(task);
    expect(test.executor.execute).toHaveBeenCalledWith(
      expect.objectContaining({
        actions: [
          expect.objectContaining({
            type: 'choice.resolve',
            meta: expect.objectContaining({ actorId: -7 }),
          }),
        ],
      }),
    );
  });

  it('does not let a late human-turn cancellation erase the next bot task', async () => {
    let releaseCancellation: (() => void) | undefined;
    const cancellation = new Promise<void>((resolve) => {
      releaseCancellation = resolve;
    });
    const runtime = {
      gameType: 'a-fond-les-ballons',
      getAutomaticActions: () => null,
    } as unknown as GameRuntime;
    const test = harness(state(), runtime, [
      { type: 'choice.resolve', payload: { value: 'red' } },
    ]);
    test.scheduler.cancel.mockImplementation(async () => cancellation);

    test.service.schedule({
      roomId: 12,
      gameType: 'a-fond-les-ballons',
      handler: runtime,
      state: state(),
    });
    await Promise.resolve();
    expect(test.scheduler.cancel).toHaveBeenCalledTimes(1);

    const botChoice = state({
      version: 5,
      players: [
        { id: 1, username: 'Alice', isBot: false },
        { id: -7, username: 'Bot Ballons', isBot: true },
      ],
      turn: { currentPlayerId: -7, direction: 1, turnNumber: 2 },
      pending: {
        type: 'choice',
        playerId: -7,
        data: {
          choiceId: 'race-chained-tile-cards.pawn',
          options: ['blue', 'red'],
        },
      },
    });
    test.service.schedule({
      roomId: 12,
      gameType: 'a-fond-les-ballons',
      handler: runtime,
      state: botChoice,
    });
    await Promise.resolve();
    expect(test.scheduler.schedule).not.toHaveBeenCalled();

    releaseCancellation?.();
    await new Promise<void>((resolve) => setImmediate(resolve));
    expect(test.scheduler.schedule).toHaveBeenCalledWith(
      expect.objectContaining({
        generation: 5,
        signature: 'bot:-7:choice:race-chained-tile-cards.pawn:round:0:turn:2',
      }),
    );
  });

  it('gives the same bot turn a distinct identity in the next round', async () => {
    const runtime = {
      gameType: 'lama',
      getAutomaticActions: () => null,
    } as unknown as GameRuntime;
    const test = harness(undefined, runtime, [{ type: 'draw', payload: {} }]);
    const botTurn = (round: number) =>
      state({
        players: [{ id: -7, username: 'Bot LAMA', isBot: true }],
        turn: { currentPlayerId: -7, direction: 1, turnNumber: 3 },
        engine: { round: { number: round } },
      });

    test.service.schedule({
      roomId: 12,
      gameType: 'lama',
      handler: runtime,
      state: botTurn(1),
    });
    test.service.schedule({
      roomId: 12,
      gameType: 'lama',
      handler: runtime,
      state: botTurn(2),
    });
    await new Promise<void>((resolve) => setImmediate(resolve));

    expect(test.scheduled.map((task) => task.signature)).toEqual([
      'bot:-7:play:round:1:turn:3',
      'bot:-7:play:round:2:turn:3',
    ]);
  });

  it('makes a stale delivery harmless and replaces it from persisted state', async () => {
    const current = state({ version: 5 });
    const test = harness(current);
    await test.processor()({
      key: 'game-realtime:3:example',
      roomId: 3,
      gameType: 'example',
      signature: 'automatic:pause:2:round:0:turn:2',
      generation: 4,
      dueAtMs: Date.now() - 10,
    });
    await Promise.resolve();
    expect(test.executor.execute).not.toHaveBeenCalled();
    expect(test.scheduled.at(-1)).toEqual(
      expect.objectContaining({ generation: 5 }),
    );
  });

  it('allows a fresh service instance to process a task created before restart', async () => {
    const first = harness();
    first.service.schedule({
      roomId: 8,
      gameType: 'example',
      handler: first.runtime,
      state: first.current,
    });
    await Promise.resolve();
    const durableTask = structuredClone(first.scheduled[0]!);

    const restarted = harness(first.current, first.runtime);
    await restarted.processor()(durableTask);
    expect(restarted.engine.compareAndSetInternalState).toHaveBeenCalledTimes(
      1,
    );
  });

  it('commits only one transition when two workers deliver the same task', async () => {
    const test = harness();
    let committed = false;
    test.engine.compareAndSetInternalState.mockImplementation(
      async (_roomId, _gameType, _version, nextState) => {
        if (committed) {
          return { committed: false, version: 5, state: nextState };
        }
        committed = true;
        return { committed: true, version: 5, state: nextState };
      },
    );
    const task: GameScheduledTask = {
      key: 'game-realtime:9:example',
      roomId: 9,
      gameType: 'example',
      signature: 'automatic:pause:2:round:0:turn:2',
      generation: 4,
      dueAtMs: Date.now() - 1,
    };

    const results = await Promise.allSettled([
      test.processor()(task),
      test.processor()(task),
    ]);
    expect(
      results.filter((result) => result.status === 'fulfilled'),
    ).toHaveLength(1);
    expect(
      results.filter((result) => result.status === 'rejected'),
    ).toHaveLength(1);
  });

  it('processes tasks from different rooms independently', async () => {
    const test = harness();
    await Promise.all([
      test.processor()({
        key: 'game-realtime:20:example',
        roomId: 20,
        gameType: 'example',
        signature: 'automatic:pause:2:round:0:turn:2',
        generation: 4,
        dueAtMs: Date.now() - 1,
      }),
      test.processor()({
        key: 'game-realtime:21:example',
        roomId: 21,
        gameType: 'example',
        signature: 'automatic:pause:2:round:0:turn:2',
        generation: 4,
        dueAtMs: Date.now() - 1,
      }),
    ]);
    expect(test.engine.compareAndSetInternalState).toHaveBeenCalledTimes(2);
  });

  it('rejects old-run and unversioned legacy deliveries with matching generation and signature', async () => {
    const test = harness(state({ metadata: { roomRunId: 2 } }));
    test.service.schedule({
      roomId: 12,
      gameType: 'example',
      handler: test.runtime,
      state: test.current,
    });
    await Promise.resolve();
    const task = test.scheduled[0]!;
    expect(task.roomRunId).toBe(2);
    await test.processor()({ ...task, roomRunId: 1 });
    await test.processor()({ ...task, roomRunId: undefined });
    expect(test.executor.execute).not.toHaveBeenCalled();
    await test.processor()(task);
    expect(test.executor.execute).toHaveBeenCalledTimes(1);
  });

  it('does not commit twice when delivery retries after the post-commit publisher failed', async () => {
    const test = harness();
    test.service.setStateCommittedHandler(() => {
      throw new Error('publisher unavailable');
    });
    test.engine.compareAndSetInternalState.mockImplementation(
      async (_room, _game, _version, next) => {
        const persisted = { ...next, version: 5 };
        test.engine.exportInternalState.mockResolvedValue(persisted);
        return { committed: true, version: 5, state: persisted };
      },
    );
    test.service.schedule({
      roomId: 12,
      gameType: 'example',
      handler: test.runtime,
      state: test.current,
    });
    await Promise.resolve();
    const task = test.scheduled[0]!;
    await expect(test.processor()(task)).rejects.toThrow(
      'publisher unavailable',
    );
    await test.processor()(task);
    expect(test.engine.compareAndSetInternalState).toHaveBeenCalledTimes(1);
    expect(test.executor.execute).toHaveBeenCalledTimes(1);
    await Promise.resolve();
    expect(test.scheduled.at(-1)?.generation).toBe(5);
  });

  it('cancels all durable jobs for a room without a process-local timer map', async () => {
    const test = harness();
    test.service.clearRoom(42);
    await Promise.resolve();
    expect(test.scheduler.cancelRoom).toHaveBeenCalledWith(42);
  });
});
