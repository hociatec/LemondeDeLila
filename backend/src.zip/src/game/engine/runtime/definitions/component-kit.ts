import type { PlayerState } from '../../../core/application/models/game-state.model';
import { GameConfigurationError } from '../contracts/game-domain.errors';
import type { GameContext } from './game-author-context';
import type {
  CardSetsDefinition,
  CardZoneDefinition,
  CardValue,
  DeckDefinition,
  HandsDefinition,
} from '../cards/cards-kit';
import type { DiceDefinition } from '../kits/dice-kit';
import type { GridDefinition } from '../kits/grid-kit';
import type { InventoryDefinition } from '../kits/inventory-kit';
import type { MarketDefinition } from '../kits/economy-kit';
import type { OwnershipDefinition } from '../kits/ownership-kit';
import type { TrackDefinition } from '../kits/movement-kit';
import type { QuizDefinition } from '../kits/quiz-kit';
import type { PawnSetDefinition } from '../kits/pawn-kit';
import type { CollectionViewDefinition } from '../projection/collection-view';
import type { ResourceDefinition } from '../contracts/resource-definition';

type GameComponent =
  | ResourceDefinition
  | DeckDefinition<CardValue>
  | HandsDefinition
  | CardSetsDefinition
  | CardZoneDefinition
  | InventoryDefinition
  | MarketDefinition
  | OwnershipDefinition
  | DiceDefinition
  | GridDefinition
  | TrackDefinition
  | PawnSetDefinition
  | QuizDefinition
  | CollectionViewDefinition;

export type GameComponentScope = 'match' | 'round';

export type GameComponentDefinition = GameComponent & {
  readonly scope?: GameComponentScope;
  /** Component key deliberately replaced from a pattern. */
  readonly overrides?: string;
};

export function overrideComponent<TComponent extends GameComponentDefinition>(
  component: TComponent,
): TComponent {
  return Object.freeze({
    ...component,
    overrides: `${component.component}:${component.id}`,
  }) as TComponent;
}

export function roundScoped<TComponent extends GameComponent>(
  component: TComponent,
): TComponent & { readonly scope: 'round' } {
  const scoped: TComponent & { readonly scope: 'round' } = {
    ...component,
    scope: 'round',
  };
  Object.freeze(scoped);
  return scoped;
}

export function matchScoped<TComponent extends GameComponent>(
  component: TComponent,
): TComponent & { readonly scope: 'match' } {
  const scoped: TComponent & { readonly scope: 'match' } = {
    ...component,
    scope: 'match',
  };
  Object.freeze(scoped);
  return scoped;
}

export type PerPlayerInitialValue = number | Readonly<Record<string, number>>;

export type GameInitialization = {
  /** Explicit keys intentionally replacing pattern initialization. */
  overrides?: readonly string[];
  firstPlayer?: 'first' | 'random' | number;
  startRound?: boolean;
  scores?: PerPlayerInitialValue;
  resources?: Readonly<Record<string, PerPlayerInitialValue>>;
  counters?: Readonly<Record<string, number>>;
  tracks?: Readonly<Record<string, PerPlayerInitialValue>>;
  pawns?: readonly {
    setId: string;
    assignment?: 'round-robin' | 'grouped' | 'random';
  }[];
  deals?: readonly {
    deckId: string;
    handId: string;
    count: number;
    fallbackDeckId?: string;
  }[];
  gridPlacements?: readonly {
    boardId: string;
    positions: readonly { x: number; y: number }[];
    emptyOverlays?: readonly string[];
  }[];
};

export function overrideInitialization(
  overrides: readonly string[],
  initialization: Omit<GameInitialization, 'overrides'>,
): GameInitialization {
  return Object.freeze({
    ...initialization,
    overrides: Object.freeze([...overrides]),
  });
}

export function installGameComponents<TState extends object>(
  components: readonly GameComponentDefinition[],
  players: readonly PlayerState[],
  context: GameContext<TState>,
): void {
  for (const component of components) {
    if (component.component === 'resource.pool')
      context.resources.initialize(
        component,
        players.map((player) => player.id),
      );
    else if (component.component === 'cards.deck')
      context.cards.createDeck(component);
    else if (component.component === 'cards.hands') {
      context.cards.createHands(
        component,
        players.map((player) => player.id),
      );
    } else if (component.component === 'cards.sets') {
      context.cards.createSets(
        component,
        players.map((player) => player.id),
      );
    } else if (component.component === 'cards.zone') {
      context.cards.createZone(component);
    } else if (component.component === 'inventory.set') {
      context.inventory.create(
        component,
        players.map((player) => player.id),
      );
    } else if (component.component === 'economy.market') {
      context.economy.create(component);
    } else if (component.component === 'ownership.registry') {
      context.ownership.create(component);
    } else if (component.component === 'movement.track') {
      context.movement.createTrack(component);
    } else if (component.component === 'pawn.set') {
      context.pawns.create(component);
    } else if (component.component === 'dice.set')
      context.dice.create(component);
    else if (component.component === 'grid.board')
      context.grid.create(component);
    else if (component.component === 'quiz.bank')
      context.quiz.create(component);
  }
}

/** Clears and reinstalls every component owned by the requested lifecycle. */
export function resetGameComponents<TState extends object>(
  scope: GameComponentScope,
  components: readonly GameComponentDefinition[],
  players: readonly PlayerState[],
  context: GameContext<TState>,
): void {
  const scoped = components.filter(
    (component) => (component.scope ?? 'match') === scope,
  );
  for (const component of scoped) {
    if (component.component === 'cards.deck')
      context.cards.removeDeck(component.id);
    else if (component.component === 'cards.hands')
      context.cards.resetHands(component.id);
    else if (component.component === 'cards.sets')
      context.cards.resetSets(component.id);
    else if (component.component === 'cards.zone')
      context.cards.resetZone(component.id);
    else if (component.component === 'inventory.set')
      context.inventory.reset(component.id);
    else if (component.component === 'economy.market')
      context.economy.reset(component.id);
    else if (component.component === 'ownership.registry')
      context.ownership.reset(component.id);
    else if (component.component === 'movement.track')
      context.movement.resetTrack(component.id);
    else if (component.component === 'pawn.set')
      context.pawns.reset(component.id);
    else if (component.component === 'dice.set')
      context.dice.reset(component.id);
    else if (component.component === 'grid.board')
      context.grid.reset(component.id);
    else if (component.component === 'quiz.bank')
      context.quiz.reset(component.id);
  }
  installGameComponents(scoped, players, context);
  if (scoped.length > 0) {
    context.events.emit('components.reset', {
      scope,
      componentIds: scoped.map((component) => component.id),
    });
  }
}

export function initializeGameComponents<TState extends object>(
  initialization: GameInitialization | undefined,
  players: readonly PlayerState[],
  context: GameContext<TState>,
): void {
  if (!initialization) return;
  assertInitializationCapacity(initialization, players, context);
  for (const player of players) {
    if (initialization.scores != null) {
      context.score.set(
        player.id,
        initialValue(initialization.scores, player.id),
      );
    }
    for (const [resource, values] of Object.entries(
      initialization.resources ?? {},
    )) {
      context.resources.set(
        player.id,
        resource,
        initialValue(values, player.id),
      );
    }
    for (const [trackId, values] of Object.entries(
      initialization.tracks ?? {},
    )) {
      context.movement.moveTo(
        trackId,
        player.id,
        initialValue(values, player.id),
      );
    }
  }
  for (const [counter, value] of Object.entries(
    initialization.counters ?? {},
  )) {
    context.counters.set(counter, value);
  }
  for (const pawnSetup of initialization.pawns ?? []) {
    const available = context.pawns.available(pawnSetup.setId);
    const ordered =
      pawnSetup.assignment === 'random'
        ? context.random.shuffle(available)
        : available;
    const perPlayer = context.pawns.perPlayer(pawnSetup.setId);
    for (let slot = 0; slot < perPlayer; slot += 1) {
      for (const [index, player] of players.entries()) {
        const pawn =
          pawnSetup.assignment === 'grouped'
            ? ordered[index * perPlayer + slot]
            : ordered[slot * players.length + index];
        if (pawn) context.pawns.assign(pawnSetup.setId, player.id, pawn.id);
      }
    }
  }
  for (const deal of initialization.deals ?? []) {
    for (const player of players) {
      for (let index = 0; index < deal.count; index += 1) {
        const card =
          context.cards.draw<CardValue>(deal.deckId) ??
          (deal.fallbackDeckId
            ? context.cards.draw<CardValue>(deal.fallbackDeckId)
            : null);
        if (card != null) context.cards.give(deal.handId, player.id, card);
      }
    }
  }
  for (const placement of initialization.gridPlacements ?? []) {
    for (const [index, player] of players.entries()) {
      const position = placement.positions[index];
      if (position) context.grid.set(placement.boardId, position, player.id);
    }
    for (const overlayId of placement.emptyOverlays ?? [])
      context.grid.setOverlays(placement.boardId, overlayId, []);
  }
  initializeFirstPlayer(initialization, players, context);
}

function initializeFirstPlayer<TState extends object>(
  initialization: GameInitialization,
  players: readonly PlayerState[],
  context: GameContext<TState>,
): void {
  const firstPlayer =
    typeof initialization.firstPlayer === 'number'
      ? context.players.get(initialization.firstPlayer)
      : initialization.firstPlayer === 'random'
        ? context.random.pick(players)
        : players[0];
  if (!firstPlayer) return;
  if (initialization.startRound === false)
    context.turn.to(firstPlayer.id, { announce: false });
  else context.turn.to(firstPlayer.id);
  if (initialization.startRound ?? true) context.round.start(firstPlayer.id);
}

function initialValue(values: PerPlayerInitialValue, playerId: number): number {
  return typeof values === 'number' ? values : (values[String(playerId)] ?? 0);
}

function assertInitializationCapacity<TState extends object>(
  initialization: GameInitialization,
  players: readonly PlayerState[],
  context: GameContext<TState>,
): void {
  if (
    typeof initialization.firstPlayer === 'number' &&
    !players.some((player) => player.id === initialization.firstPlayer)
  )
    throw new GameConfigurationError('Premier joueur absent de la partie');
  for (const setup of initialization.pawns ?? []) {
    const required = players.length * context.pawns.perPlayer(setup.setId);
    if (context.pawns.available(setup.setId).length < required)
      throw new GameConfigurationError(
        `Pions insuffisants pour la distribution: ${setup.setId}`,
      );
  }
  for (const placement of initialization.gridPlacements ?? []) {
    if (placement.positions.length < players.length)
      throw new GameConfigurationError(
        `Positions de grille insuffisantes: ${placement.boardId}`,
      );
  }
}
