import type { PendingState } from '../../../core/application/models/game-state.model';
import { gameDeadline } from '../automation/game-deadline';
import {
  GameConfigurationError,
  GameStateViolationError,
} from '../../../core/domain/errors/game-domain.errors';

export type ChoiceTimeout<TValue> = {
  afterMs: number;
  strategy?: 'first' | 'last' | 'random' | 'default' | 'pass';
  value?: TValue;
};

export type ChoiceOptions<TValue, TResult = TValue> = {
  id: string;
  player: number;
  options: readonly TValue[];
  timeout?: ChoiceTimeout<TResult>;
  label?: (value: TValue) => string;
  data?: Readonly<object>;
};

export class GameChoiceController {
  private resolvedData: Record<string, unknown> | null = null;

  constructor(
    private readonly getPending: () => PendingState | null | undefined,
    private readonly setPending: (pending: PendingState | null) => void,
    private readonly nowMs: () => number,
  ) {}

  one<TValue>(options: ChoiceOptions<TValue>): void {
    this.create('one', options, 1, 1);
  }

  many<TValue>(
    options: ChoiceOptions<TValue, readonly TValue[]> & {
      min?: number;
      max?: number;
    },
  ): void {
    this.create(
      'many',
      options,
      options.min ?? 0,
      options.max ?? options.options.length,
    );
  }

  player(options: ChoiceOptions<number>): void {
    this.create('player', options, 1, 1);
  }

  card(options: ChoiceOptions<string>): void {
    this.create('card', options, 1, 1);
  }

  pawn(options: ChoiceOptions<string>): void {
    this.create('pawn', options, 1, 1);
  }

  number(
    options: Omit<ChoiceOptions<number>, 'options'> & {
      min: number;
      max: number;
      step?: number;
    },
  ): void {
    const step = options.step ?? 1;
    if (
      !Number.isSafeInteger(options.min) ||
      !Number.isSafeInteger(options.max) ||
      !Number.isSafeInteger(options.max - options.min) ||
      !Number.isSafeInteger(step) ||
      step < 1
    ) {
      throw new GameConfigurationError('Bornes de choix numérique invalides');
    }
    const count = Math.floor((options.max - options.min) / step) + 1;
    if (!Number.isSafeInteger(count) || count < 1 || count > 1_000) {
      throw new GameConfigurationError(
        'Intervalle de choix numérique invalide',
      );
    }
    this.create(
      'number',
      {
        ...options,
        options: Array.from(
          { length: count },
          (_entry, index) => options.min + index * step,
        ),
      },
      1,
      1,
    );
  }

  ordering<TValue>(options: ChoiceOptions<TValue, readonly TValue[]>): void {
    this.create(
      'ordering',
      options,
      options.options.length,
      options.options.length,
    );
  }

  vote(options: ChoiceOptions<number>): void {
    this.create('vote', options, 1, 1);
  }

  players(
    options: ChoiceOptions<number, readonly number[]> & {
      min: number;
      max: number;
    },
  ): void {
    this.create('players', options, options.min, options.max);
  }

  confirm(options: Omit<ChoiceOptions<boolean>, 'options'>): void {
    this.create('confirm', { ...options, options: [true, false] }, 1, 1);
  }

  forPlayers<TValue>(
    options: Omit<ChoiceOptions<TValue>, 'player'> & {
      players: readonly number[];
      kind?: 'one' | 'pawn';
    },
  ): void {
    const { kind = 'one', players, ...choice } = options;
    const playerIds = [...new Set(players)];
    if (playerIds.length === 0) {
      throw new GameConfigurationError(
        'Un choix collectif requiert des joueurs',
      );
    }
    this.create(kind, { ...choice, player: playerIds[0] }, 1, 1, {
      playerIds,
    });
  }

  sequence<TValue>(options: {
    id: string;
    players: readonly number[];
    options: readonly TValue[] | ((playerId: number) => readonly TValue[]);
    timeout?: ChoiceTimeout<TValue>;
    label?: (value: TValue) => string;
    data?: Readonly<object>;
  }): void {
    const playerIds = [...new Set(options.players)];
    for (const [index, playerId] of playerIds.entries()) {
      const values =
        typeof options.options === 'function'
          ? options.options(playerId)
          : options.options;
      this.create(
        'one',
        {
          id: options.id,
          player: playerId,
          options: values,
          timeout: options.timeout,
          label: options.label,
          data: options.data,
        },
        1,
        1,
        { enqueue: index > 0 },
      );
    }
  }

  current(): PendingState | null {
    return this.getPending() ?? null;
  }

  replaceOptions<TValue>(
    options: readonly TValue[],
    label?: (value: TValue) => string,
  ): void {
    const pending = this.current();
    if (!pending) {
      throw new GameStateViolationError('Aucun choix à actualiser');
    }
    pending.choices = options.map((value) => label?.(value) ?? String(value));
    pending.data = {
      ...structuredClone(pending.data ?? {}),
      options: structuredClone([...options]),
    };
    this.setPending(pending);
  }

  continuation<TData extends object>(): TData | null {
    const data = this.resolvedData ?? this.current()?.data;
    if (!data) return null;
    const continuation = data.continuationData;
    return structuredClone(
      continuation != null && typeof continuation === 'object'
        ? continuation
        : data,
    ) as TData;
  }

  consumeContinuation<TData extends object>(): TData | null {
    const data = this.continuation<TData>();
    this.resolvedData = null;
    return data;
  }

  clear(): void {
    this.promoteQueue();
  }

  resolvePlayer(playerId: number): void {
    const pending = this.current();
    this.resolvedData = structuredClone(pending?.data ?? {});
    if (!pending?.playerIds?.length) {
      this.promoteQueue();
      return;
    }
    pending.resolvedPlayerIds = [
      ...new Set([...(pending.resolvedPlayerIds ?? []), playerId]),
    ];
    if (
      pending.playerIds.every((participantId) =>
        pending.resolvedPlayerIds?.includes(participantId),
      )
    ) {
      this.promoteQueue();
    } else {
      this.setPending(pending);
    }
  }

  private create<TValue>(
    kind:
      | 'one'
      | 'many'
      | 'player'
      | 'players'
      | 'card'
      | 'pawn'
      | 'number'
      | 'ordering'
      | 'vote'
      | 'confirm',
    options: ChoiceOptions<TValue, unknown>,
    min: number,
    max: number,
    mode: { enqueue?: boolean; playerIds?: number[] } = {},
  ): void {
    if (this.current() && !mode.enqueue) {
      throw new GameStateViolationError('Un choix est déjà en attente');
    }
    const values = [...options.options];
    if (
      !Number.isSafeInteger(min) ||
      !Number.isSafeInteger(max) ||
      min < 0 ||
      max < min ||
      max > values.length
    ) {
      throw new GameConfigurationError('Nombre de choix invalide');
    }
    const pending: PendingState = {
      schemaVersion: 1,
      type: `engine.choice.${kind}`,
      label: kind === 'pawn' ? 'Choisissez votre pion.' : 'Choix requis',
      playerId: options.player,
      ...(mode.playerIds
        ? { playerIds: [...mode.playerIds], resolvedPlayerIds: [] }
        : {}),
      blocking: true,
      choices: values.map((value) => options.label?.(value) ?? String(value)),
      data: {
        continuationData: structuredClone(options.data ?? {}),
        kind,
        choiceId: options.id,
        options: values,
        min,
        max,
        timeoutStrategy: options.timeout?.strategy ?? 'first',
        ...(options.timeout?.value === undefined
          ? {}
          : { timeoutValue: options.timeout.value }),
        deadlineMs:
          options.timeout == null
            ? null
            : gameDeadline(this.nowMs(), options.timeout.afterMs),
      },
    };
    if (!this.current()) {
      this.setPending(pending);
      return;
    }
    const current = this.current();
    if (!current) return;
    current.queue = [...(current.queue ?? []), pending];
    this.setPending(current);
  }

  private promoteQueue(): void {
    const current = this.current();
    const [next, ...queue] = current?.queue ?? [];
    this.setPending(next ? { ...next, queue } : null);
  }
}
