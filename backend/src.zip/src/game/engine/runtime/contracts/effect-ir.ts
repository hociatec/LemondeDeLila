import type { NumericExpression } from './numeric-expression';
import type { CardLocation } from './card-location';
import type { InsufficientResourcePolicy } from './resource-payment';
/** Neutral effect instructions: no author callbacks, builders or executors. */
import type { StatusScope } from '../kits/player-values-contracts';

export type EffectTarget =
  | { kind: 'self' }
  | { kind: 'current-player' }
  | {
      kind: 'matching-players';
      condition: EffectCondition;
      participants?: 'active' | 'all';
    }
  | { kind: 'player'; playerId: number }
  | { kind: 'next'; order?: 'seating' | 'turn' }
  | { kind: 'previous'; order?: 'seating' | 'turn' }
  | { kind: 'random-player' }
  | { kind: 'leader'; ties: 'all' | 'lowest-id' | 'random' }
  | { kind: 'last'; ties: 'all' | 'lowest-id' | 'random' }
  | { kind: 'all-players' }
  | { kind: 'all-opponents' }
  | { kind: 'random-opponent' }
  | {
      kind: 'chosen-opponent';
      choiceId?: string;
      optional?: boolean;
      chooserPlayerId?: number;
    }
  | {
      kind: 'chosen-player';
      playerIds: readonly number[];
      choiceId?: string;
      optional?: boolean;
      chooserPlayerId?: number;
    };

export type EffectComparison = 'eq' | 'ne' | 'lt' | 'lte' | 'gt' | 'gte';

export type EffectCondition =
  | { kind: 'phase-is'; phase: string }
  | {
      kind: 'compare-values';
      left: NumericExpression;
      right: NumericExpression;
      compare: EffectComparison;
      target?: EffectTarget;
    }
  | {
      kind: 'score';
      compare: EffectComparison;
      amount: number;
      target?: EffectTarget;
    }
  | {
      kind: 'resource';
      resource: string;
      compare: EffectComparison;
      amount: number;
      target?: EffectTarget;
    }
  | {
      kind: 'inventory-count';
      inventoryId: string;
      itemId?: string;
      compare: EffectComparison;
      amount: number;
      target?: EffectTarget;
    }
  | {
      kind: 'owns-asset';
      registryId: string;
      assetId: string;
      target?: EffectTarget;
    }
  | {
      kind: 'has-resource';
      resource: string;
      amount: number;
      target?: EffectTarget;
    }
  | { kind: 'has-status'; status: string; target?: EffectTarget }
  | {
      kind: 'track-position';
      trackId: string;
      position?: number;
      min?: number;
      max?: number;
      target?: EffectTarget;
    }
  | { kind: 'has-card'; handId: string; cardId?: string; target?: EffectTarget }
  | { kind: 'not'; condition: EffectCondition }
  | { kind: 'all'; conditions: readonly EffectCondition[] }
  | { kind: 'any'; conditions: readonly EffectCondition[] };

export type EffectChoiceAvailability =
  | {
      kind: 'cards';
      handId: string;
      owner: EffectTarget;
    }
  | {
      kind: 'resources';
      owner: EffectTarget;
      amount?: number;
    };

export type GameEffectInstruction =
  | {
      kind: 'move-card';
      source: CardLocation;
      destination: CardLocation;
      cardId: string | number;
    }
  | {
      kind: 'conditional';
      condition: EffectCondition;
      then: readonly GameEffectInstruction[];
      else?: readonly GameEffectInstruction[];
    }
  | {
      kind: 'reaction';
      choiceId?: string;
      reactor: EffectTarget;
      options: readonly string[];
      availability?: EffectChoiceAvailability;
      reactions: Readonly<Record<string, readonly GameEffectInstruction[]>>;
      fallback?: readonly GameEffectInstruction[];
    }
  | {
      kind: 'choose-player';
      choiceId?: string;
      candidates?: 'opponents' | 'active-players';
    }
  | {
      kind: 'move';
      trackId: string;
      spaces: number;
      target?: EffectTarget;
    }
  | {
      kind: 'move-to';
      trackId: string;
      position: number;
      target?: EffectTarget;
    }
  | {
      kind: 'draw-cards';
      deckId: string;
      handId: string;
      count: number;
      recycle?: boolean;
      target?: EffectTarget;
    }
  | {
      kind: 'discard-random';
      deckId: string;
      handId: string;
      count: number;
      target?: EffectTarget;
    }
  | {
      kind: 'discard-random-inventory';
      inventoryId: string;
      count: number;
      target?: EffectTarget;
    }
  | {
      kind: 'gain-resource';
      resource: string;
      amount: NumericExpression;
      target?: EffectTarget;
    }
  | {
      kind: 'lose-resource';
      resource: string;
      amount: NumericExpression;
      allowPartial?: boolean;
      insufficient?: InsufficientResourcePolicy;
      target?: EffectTarget;
    }
  | {
      kind: 'exchange-resources';
      left: EffectTarget;
      right: EffectTarget;
      leftOffer: { resource: string; amount: number };
      rightOffer: { resource: string; amount: number };
    }
  | {
      kind: 'transfer-resource';
      resource: string;
      amount: NumericExpression;
      from: EffectTarget;
      to: EffectTarget;
    }
  | {
      kind: 'give-card';
      handId: string;
      cardId: string;
      from: EffectTarget;
      to: EffectTarget;
    }
  | {
      kind: 'steal-card';
      handId: string;
      count?: number;
      from: EffectTarget;
      to?: EffectTarget;
    }
  | {
      kind: 'exchange-random-cards';
      handId: string;
      left: EffectTarget;
      right: EffectTarget;
    }
  | {
      kind: 'swap-hands';
      handId: string;
      left: EffectTarget;
      right: EffectTarget;
    }
  | {
      kind: 'steal-random-inventory';
      inventoryId: string;
      count?: number;
      from: EffectTarget;
      to?: EffectTarget;
    }
  | {
      kind: 'swap-inventories';
      inventoryId: string;
      left: EffectTarget;
      right: EffectTarget;
    }
  | {
      kind: 'exchange-random-inventory';
      inventoryId: string;
      left: EffectTarget;
      right: EffectTarget;
    }
  | {
      kind: 'gain-score';
      amount: NumericExpression;
      target?: EffectTarget;
    }
  | { kind: 'skip-turn'; count?: number; target?: EffectTarget }
  | { kind: 'extra-turn'; count?: number }
  | {
      kind: 'add-status';
      status: string;
      turns?: number;
      scope?: StatusScope;
      stack?: boolean;
      stacks?: number;
      stacking?: 'replace' | 'add';
      source?: { playerId?: number; effectId?: string };
      categories?: readonly string[];
      data?: Record<string, unknown>;
      target?: EffectTarget;
    }
  | { kind: 'remove-status'; status: string; target?: EffectTarget }
  | { kind: 'roll-dice'; diceId?: string }
  | { kind: 'reverse-turn-order' }
  | {
      kind: 'swap-positions';
      trackId: string;
      left: EffectTarget;
      right: EffectTarget;
    }
  | { kind: 'complete-turn' }
  | { kind: 'start-round' }
  | { kind: 'end-round' }
  | { kind: 'eliminate-player'; target?: EffectTarget }
  | {
      kind: 'custom';
      effectId: string;
      /** Opaque persisted payload; parsed by the resolver selected by effectId. */
      data?: unknown;
      target?: EffectTarget;
    };

export type EffectEngineState = {
  /** Schema version of persisted effect continuations. */
  schemaVersion: number;
  queue: GameEffectInstruction[];
  actorPlayerId: number | null;
  chosenPlayerId: number | null;
  awaitingChoiceId: string | null;
  awaitingReaction: {
    choiceId: string;
    reactions: Record<string, GameEffectInstruction[]>;
    fallback: GameEffectInstruction[];
  } | null;
  awaitingPlayerChoice: {
    choiceId: string;
    optional: boolean;
  } | null;
  playerChoiceResolved: boolean;
  resolvedPlayerChoiceId: string | null;
  completeTurnWhenDrained: boolean;
  /** Provenance de la chaîne courante, conservée pendant tout le tour. */
  source?: EffectSource | null;
};

export type EffectSource = {
  playerId: number | null;
  cardId?: string | number;
  deckId?: string;
  tileId?: string | number;
};
