import type {
  GameActionCandidatePage,
  GameActionCandidateQuery,
  GameRuntimeDescriptor,
} from '../../../core/application/ports/game-runtime.port';
import type { GameExecutionContext } from '../../../core/application/models/game-execution-context.model';
import type {
  GameSingleActionDto,
  GameStateWithActions,
} from '../../../core/application/models/game-action.model';
import type {
  GameState,
  PendingState,
  PlayerState,
} from '../../../core/application/models/game-state.model';
import { DeclarativeChoiceRuntime } from '../choices/declarative-choice-runtime';
import type { CompiledGameDefinition } from '../contracts/compiled-game-definition';
import type { DeclarativeState } from '../state/declarative-state';
import type {
  GameActionMap,
  GameActionShape,
} from '../contracts/author-rule-contracts';
import type { GameContext } from '../definitions/game-author-context';
import { projectGameSystemView } from './game-system-view';
import { asRecord } from '../actions/runtime-game-action';
import {
  deriveGameShortcuts,
  describeGameDefinition,
} from '../definitions/runtime-descriptor';
import { randomLegalAction } from '../automation/bot-kit';
import {
  canConfigureGame,
  GAME_CONFIGURE_ACTION,
} from '../configuration/configuration-kit';
import {
  nextScheduledAction,
  projectScheduler,
} from '../automation/scheduler-kit';

export abstract class DeclarativeGameQueries<
  TState extends object,
  TActions extends GameActionMap<TState>,
> {
  protected abstract readonly definition: CompiledGameDefinition<
    TState,
    TActions
  >;
  protected abstract readonly choices: DeclarativeChoiceRuntime<
    TState,
    TActions
  >;
  protected abstract runtimeState(state: GameState): DeclarativeState<TState>;
  protected abstract context(
    state: DeclarativeState<TState>,
    actorId: number | null,
    execution?: GameExecutionContext,
  ): GameContext<TState>;
  protected abstract actionDefinition(type: string): GameActionShape<TState>;
  protected abstract requireActor(
    runtime: DeclarativeState<TState>,
    playerId: number | null,
  ): PlayerState;
  protected abstract isActionAvailable(
    runtime: DeclarativeState<TState>,
    actor: PlayerState,
    type: string,
    context: GameContext<TState>,
  ): boolean;
  abstract validateAction(
    state: GameState,
    action: GameSingleActionDto,
    playerId?: number | null,
    execution?: GameExecutionContext,
  ): GameSingleActionDto;

  getAvailableActions(
    state: GameState,
    playerId: number,
    execution?: GameExecutionContext,
  ): GameSingleActionDto[] {
    const runtime = this.runtimeState(state);
    const actor = (runtime.players ?? []).find(
      (player) => player.id === playerId,
    );
    if (!actor || String(runtime.status).toLowerCase() === 'finished')
      return [];
    if (runtime.pending) return this.choices.actions(runtime, actor);
    const context = this.context(runtime, actor.id, execution);
    if (this.definition.config && !runtime.engine.configuration.complete) {
      return canConfigureGame(
        this.definition.config,
        runtime.engine.configuration,
        actor,
        context,
      )
        ? [{ type: GAME_CONFIGURE_ACTION, payload: {} }]
        : [];
    }
    return Object.entries(this.definition.actions).flatMap(
      ([type, definition]) => {
        if (!this.isActionAvailable(runtime, actor, type, context)) return [];
        const inputs = definition.enumerateCandidateInputs
          ? definition.enumerateCandidateInputs({
              state: runtime.game,
              actor,
              ctx: context,
              query: {},
              offset: 0,
              limit: 50,
            })
          : definition.enumerateInputs?.({
              state: runtime.game,
              actor,
              ctx: context,
            });
        return (inputs ?? [{}]).map((payload) => ({
          type,
          payload: toActionPayload(payload),
        }));
      },
    );
  }

  getActionCandidates(
    state: GameState,
    playerId: number,
    actionType: string,
    options: GameActionCandidateQuery = {},
    execution?: GameExecutionContext,
  ): GameActionCandidatePage {
    const runtime = this.runtimeState(state);
    const actor = this.requireActor(runtime, playerId);
    const context = this.context(runtime, actor.id, execution);
    const definition = this.actionDefinition(actionType);
    const offset = Math.max(0, Math.trunc(options.offset ?? 0));
    const limit = Math.max(1, Math.min(200, Math.trunc(options.limit ?? 50)));
    if (!this.isActionAvailable(runtime, actor, actionType, context)) {
      return { actionType, items: [], offset, limit, nextOffset: null };
    }
    const requested = limit + 1;
    const candidates = definition.enumerateCandidateInputs
      ? definition.enumerateCandidateInputs({
          state: runtime.game,
          actor,
          ctx: context,
          query: options.query ?? {},
          offset,
          limit: requested,
        })
      : (
          definition.enumerateInputs?.({
            state: runtime.game,
            actor,
            ctx: context,
          }) ?? [{}]
        ).slice(offset, offset + requested);
    const hasMore = candidates.length > limit;
    return {
      actionType,
      items: candidates.slice(0, limit).map((payload) => ({
        type: actionType,
        payload: toActionPayload(payload),
      })),
      offset,
      limit,
      nextOffset: hasMore ? offset + limit : null,
    };
  }

  exposeStateForUser(
    state: GameState,
    userId: number | null,
    execution?: GameExecutionContext,
  ): GameStateWithActions {
    const runtime = this.runtimeState(state);
    const actor =
      (runtime.players ?? []).find((player) => player.id === userId) ?? null;
    const context = this.context(runtime, actor?.id ?? null, execution);
    const gameView = this.definition.viewExtension
      ? this.definition.viewExtension({
          state: runtime.game,
          actor,
          ctx: context,
        })
      : {};
    const pending = projectPending(runtime.pending, actor?.id ?? null);
    const system = projectGameSystemView({
      runtime,
      viewerPlayerId: actor?.id ?? null,
      components: this.definition.components,
      hasConfiguration: this.definition.config != null,
      playerValuesVisibility: this.definition.playerValuesVisibility,
    });
    return {
      ...system,
      game: gameView,
      gameContract: {
        stateVersion: this.definition.stateVersion,
        rulesVersion: this.definition.rulesVersion,
        contentVersion: this.definition.contentVersion,
      },
      actionCatalog: describeGameDefinition(this.definition).actions,
      timers: projectScheduler(
        runtime.engine.scheduler,
        actor?.id ?? null,
        context.clock.nowMs(),
      ),
      actions:
        userId == null
          ? []
          : this.getAvailableActions(runtime, userId, execution),
      pending,
    };
  }

  getBotActions(
    state: GameState,
    botPlayerId: number,
    execution?: GameExecutionContext,
  ): GameSingleActionDto[] | null {
    const runtime = this.runtimeState(state);
    const actor = (runtime.players ?? []).find(
      (player) => player.id === botPlayerId && player.isBot,
    );
    if (!actor) return null;
    const decisionRuntime = structuredClone(runtime);
    const decisionActor = this.requireActor(decisionRuntime, botPlayerId);
    const context = this.context(decisionRuntime, botPlayerId, execution);
    const pending = this.choices.actions(decisionRuntime, decisionActor);
    if (pending.length > 0) {
      const selected = randomLegalAction(pending, context.random);
      return selected ? [selected] : null;
    }
    const available = this.getAvailableActions(runtime, botPlayerId, execution);
    if (available.length === 0) return null;
    if (
      available.length === 1 &&
      available[0]?.type === GAME_CONFIGURE_ACTION
    ) {
      return [
        this.validateAction(
          runtime,
          { type: GAME_CONFIGURE_ACTION, payload: {} },
          botPlayerId,
          execution,
        ),
      ];
    }
    if (!this.definition.bot) {
      const selected = randomLegalAction(available, context.random);
      return selected
        ? [
            this.validateAction(
              runtime,
              { ...selected, meta: { actorId: botPlayerId } },
              botPlayerId,
              execution,
            ),
          ]
        : null;
    }
    const selected = this.definition.bot.choose({
      state: decisionRuntime.game,
      actor: decisionActor,
      availableActions: available.map(
        (action) => action.type as keyof TActions & string,
      ),
      legalActions: structuredClone(available),
      ctx: context,
    });
    if (!selected) return null;
    const selectedAction: GameSingleActionDto = {
      type: selected.type,
      ...(selected.payload === undefined
        ? {}
        : { payload: toActionPayload(selected.payload) }),
      meta: { actorId: botPlayerId },
    };
    return [
      this.validateAction(runtime, selectedAction, botPlayerId, execution),
    ];
  }

  getAutomaticActions(state: GameState) {
    const runtime = this.runtimeState(state);
    const data = asRecord(runtime.pending?.data);
    const rawChoiceDeadline = data.deadlineMs;
    const choiceDeadline =
      typeof rawChoiceDeadline === 'number' &&
      Number.isFinite(rawChoiceDeadline)
        ? rawChoiceDeadline
        : null;
    const unresolvedChoicePlayerId = runtime.pending?.playerIds?.find(
      (playerId) =>
        !(runtime.pending?.resolvedPlayerIds ?? []).includes(playerId),
    );
    const rawChoiceId = data.choiceId;
    const choiceId =
      typeof rawChoiceId === 'string' || typeof rawChoiceId === 'number'
        ? String(rawChoiceId)
        : '';
    const choicePlan =
      runtime.pending && choiceDeadline != null
        ? {
            key: `choice-timeout:${choiceId}:${choiceDeadline}`,
            executeAtMs: choiceDeadline,
            actions: [
              {
                type: 'choice.timeout',
                payload: {},
                meta: {
                  actorId:
                    unresolvedChoicePlayerId ??
                    runtime.pending.playerId ??
                    null,
                },
              },
            ],
          }
        : null;
    const scheduled = nextScheduledAction(runtime.engine.scheduler);
    const scheduledPlan = scheduled?.action
      ? {
          key: `scheduler:${scheduled.id}:${scheduled.dueAtMs}`,
          executeAtMs: scheduled.dueAtMs,
          actions: [
            {
              ...scheduled.action,
              meta: {
                ...(scheduled.action.meta ?? {}),
                actorId:
                  scheduled.action.meta?.actorId ??
                  runtime.turn?.currentPlayerId ??
                  null,
                schedulerId: scheduled.id,
              },
            },
          ],
        }
      : null;
    if (!choicePlan) return scheduledPlan;
    if (!scheduledPlan) return choicePlan;
    return choicePlan.executeAtMs <= scheduledPlan.executeAtMs
      ? choicePlan
      : scheduledPlan;
  }

  getShortcuts() {
    return deriveGameShortcuts(this.definition);
  }

  getDescriptor(): GameRuntimeDescriptor {
    return describeGameDefinition(this.definition);
  }
}

/** Converts a schema-typed action object only at the transport DTO boundary. */
function toActionPayload(payload: object): Record<string, unknown> {
  return Object.fromEntries(Object.entries(payload));
}

function projectPending(
  pending: PendingState | null | undefined,
  viewerPlayerId: number | null,
): PendingState | null {
  if (!pending) return null;
  const expected =
    viewerPlayerId != null &&
    (pending.playerIds?.length
      ? pending.playerIds.includes(viewerPlayerId) &&
        !(pending.resolvedPlayerIds ?? []).includes(viewerPlayerId)
      : pending.playerId == null || pending.playerId === viewerPlayerId);
  const common: PendingState = {
    type: pending.type,
    choiceId:
      typeof pending.data?.choiceId === 'string'
        ? pending.data.choiceId
        : undefined,
    workflowKind:
      typeof pending.data?.kind === 'string' ? pending.data.kind : undefined,
    label: pending.label,
    playerId: pending.playerId,
    playerIds: pending.playerIds ? [...pending.playerIds] : undefined,
    resolvedPlayerIds: pending.resolvedPlayerIds
      ? [...pending.resolvedPlayerIds]
      : undefined,
    targetPlayerId: pending.targetPlayerId,
    blocking: pending.blocking,
  };
  if (!expected) return common;
  const data = projectChoiceData(pending.data);
  const kind = typeof data?.kind === 'string' ? data.kind : '';
  const options = Array.isArray(data?.options) ? data.options : [];
  if (
    data &&
    options.length > 0 &&
    !['many', 'players', 'ordering'].includes(kind)
  ) {
    data.choiceActionsByIndex = options.map((value) => ({
      type: 'choice.resolve',
      payload: { value: structuredClone(value) },
    }));
  }
  return {
    ...common,
    question: pending.question,
    choices: pending.choices ? [...pending.choices] : undefined,
    data,
  };
}

function projectChoiceData(source: PendingState['data']): PendingState['data'] {
  if (!source) return undefined;
  const fields = [
    'kind',
    'choiceId',
    'options',
    'min',
    'max',
    'timeoutStrategy',
    'timeoutValue',
    'deadlineMs',
  ] as const;
  return Object.fromEntries(
    fields
      .filter((field) => Object.hasOwn(source, field))
      .map((field) => [field, structuredClone(source[field])]),
  );
}
