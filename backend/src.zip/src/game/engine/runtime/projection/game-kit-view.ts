import { copyState } from '../contracts/state-copy';
import type { ReadonlyState } from '../contracts/state-copy';
import {
  projectCardsKitState,
  type CardsPlayerView,
  type CardSetsDefinition,
  type CardZoneDefinition,
  type HandsDefinition,
} from '../cards/cards-kit';
import type { GameComponentDefinition } from '../definitions/component-kit';
import type { EngineKitsState } from '../state/declarative-state';
import {
  projectInventoryKitState,
  type InventoryDefinition,
} from '../kits/inventory-kit';
import {
  projectEconomyKitState,
  type MarketDefinition,
} from '../kits/economy-kit';
import {
  projectOwnershipKitState,
  type OwnershipDefinition,
} from '../kits/ownership-kit';
import {
  quizSessionChoices,
  type QuizDefinition,
  type QuizSessionState,
} from '../kits/quiz-kit';
import type { TrackDefinition } from '../kits/movement-kit';
import type { DiceDefinition } from '../kits/dice-kit';
import type { GridDefinition } from '../kits/grid-kit';
import type { PawnSetDefinition } from '../kits/pawn-kit';

export type DiceSetPlayerView = {
  id: string;
  label: string;
  sides: number;
  dice: Array<{
    id: string;
    label: string;
    sides: number;
    value?: number;
  }>;
  total?: number;
  rollKey?: string;
};

export type DicePlayerView = DiceSetPlayerView & {
  activeSetId: string;
  sets: Record<string, DiceSetPlayerView>;
  byPlayer: Record<string, Record<string, { values: number[]; total: number }>>;
};

export type MovementPlayerView = {
  tracks: Record<
    string,
    {
      spaces: number;
      overshoot: NonNullable<TrackDefinition['overshoot']>;
      positions: Record<string, number>;
    }
  >;
};

export type PawnSetsPlayerView = {
  sets: Record<
    string,
    {
      definitions: PawnSetDefinition['pawns'];
      owners: Record<string, number>;
      assignments: Record<string, string[]>;
      byPlayer: Record<string, string[]>;
      positions?: Record<string, number>;
    }
  >;
};

export type GameKitsPlayerView = {
  cards?: CardsPlayerView;
  inventory?: ReturnType<typeof projectInventoryKitState>;
  economy?: ReturnType<typeof projectEconomyKitState>;
  ownership?: ReturnType<typeof projectOwnershipKitState>;
  dice?: DicePlayerView;
  movement?: MovementPlayerView;
  pawns?: PawnSetsPlayerView;
  grid?: {
    boards: Record<
      string,
      Partial<GridDefinition> & {
        cells: Record<string, unknown>;
        overlays: Record<string, unknown[]>;
      }
    >;
  };
  quiz?: {
    banks: Record<string, { count: number; cursor: number; remaining: number }>;
    sessions: Record<string, Record<string, unknown>>;
  };
};

export function projectGameKits(
  kits: EngineKitsState,
  viewerPlayerId: number | null,
  turnNumber: number,
  components: readonly GameComponentDefinition[] = [],
  roundInactivePlayerIds: readonly number[] = [],
): GameKitsPlayerView {
  const extras: GameKitsPlayerView = {};
  if (kits.cards && Object.keys(kits.cards.decks).length > 0) {
    extras.cards = projectCardsKitState(
      kits.cards,
      viewerPlayerId,
      cardProjectionDefinitions(components),
      roundInactivePlayerIds,
    );
  }
  if (kits.inventory && Object.keys(kits.inventory.byPlayer).length > 0) {
    extras.inventory = projectInventoryKitState(
      kits.inventory,
      viewerPlayerId,
      components.filter(
        (component): component is InventoryDefinition =>
          component.component === 'inventory.set',
      ),
    );
  }
  if (kits.economy && Object.keys(kits.economy.prices).length > 0) {
    extras.economy = projectEconomyKitState(
      kits.economy,
      components.filter(
        (component): component is MarketDefinition =>
          component.component === 'economy.market',
      ),
    );
  }
  if (kits.ownership && Object.keys(kits.ownership.owners).length > 0) {
    extras.ownership = projectOwnershipKitState(
      kits.ownership,
      viewerPlayerId,
      components.filter(
        (component): component is OwnershipDefinition =>
          component.component === 'ownership.registry',
      ),
    );
  }
  projectDiceKit(extras, kits, components, turnNumber);
  projectMovementKit(extras, kits, components);
  projectPawnKit(extras, kits, components);
  projectGridKit(extras, kits, components);
  projectQuizKit(extras, kits, components, viewerPlayerId);
  return extras;
}

function projectDiceKit(
  extras: GameKitsPlayerView,
  kits: EngineKitsState,
  components: readonly GameComponentDefinition[],
  turnNumber: number,
): void {
  const dice = kits.dice;
  const diceDefinitions = components.filter(
    (component): component is DiceDefinition =>
      component.component === 'dice.set',
  );
  const activeSetId = dice?.lastRollId ?? diceDefinitions[0]?.id;
  if (dice && activeSetId) {
    const sets = Object.fromEntries(
      diceDefinitions.map((definition) => [
        definition.id,
        projectDiceSet(
          definition,
          dice.rolls[definition.id],
          turnNumber,
          dice.sequence,
        ),
      ]),
    );
    const active =
      sets[activeSetId] ??
      projectDiceSet(
        { component: 'dice.set', id: activeSetId, count: 1, sides: 6 },
        dice.rolls[activeSetId],
        turnNumber,
        dice.sequence,
      );
    extras.dice = {
      ...active,
      activeSetId,
      sets,
      byPlayer: copyState(dice.rollsByPlayer ?? {}),
    };
  }
}

function projectMovementKit(
  extras: GameKitsPlayerView,
  kits: EngineKitsState,
  components: readonly GameComponentDefinition[],
): void {
  const movement = kits.movement;
  const trackDefinitions = components.filter(
    (component): component is TrackDefinition =>
      component.component === 'movement.track',
  );
  if (movement && Object.keys(movement.positions).length > 0) {
    extras.movement = {
      tracks: Object.fromEntries(
        Object.entries(movement.positions).map(([trackId, positions]) => {
          const track = trackDefinitions.find(
            (definition) => definition.id === trackId,
          );
          return [
            trackId,
            {
              spaces: track?.spaces ?? 0,
              overshoot: track?.overshoot ?? 'clamp',
              positions: copyState(positions),
            },
          ];
        }),
      ),
    };
  }
}

function projectPawnKit(
  extras: GameKitsPlayerView,
  kits: EngineKitsState,
  components: readonly GameComponentDefinition[],
): void {
  const pawns = kits.pawns;
  const pawnDefinitions = components.filter(
    (component): component is PawnSetDefinition =>
      component.component === 'pawn.set',
  );
  if (pawns && Object.keys(pawns.positions).length > 0) {
    extras.pawns = {
      sets: Object.fromEntries(
        Object.entries(pawns.positions).map(([setId, positions]) => {
          const definition = pawnDefinitions.find(
            (candidate) => candidate.id === setId,
          );
          const projectedPositions = Object.fromEntries(
            Object.entries(positions).filter(([, position]) => position !== 0),
          );
          return [
            setId,
            {
              definitions: copyState(definition?.pawns ?? []),
              owners: copyState(pawns.owners[setId] ?? {}),
              assignments: copyState(pawns.assignments[setId] ?? {}),
              byPlayer: copyState(pawns.assignments[setId] ?? {}),
              ...(Object.keys(projectedPositions).length > 0
                ? { positions: projectedPositions }
                : {}),
            },
          ];
        }),
      ),
    };
  }
}

function projectGridKit(
  extras: GameKitsPlayerView,
  kits: EngineKitsState,
  components: readonly GameComponentDefinition[],
): void {
  if (kits.grid && Object.keys(kits.grid.cells).length > 0) {
    const gridDefinitions = components.filter(
      (component): component is GridDefinition =>
        component.component === 'grid.board',
    );
    extras.grid = {
      boards: Object.fromEntries(
        Object.entries(kits.grid.cells).map(([boardId, cells]) => [
          boardId,
          {
            ...copyState(
              gridDefinitions.find((definition) => definition.id === boardId),
            ),
            cells: copyState(cells),
            overlays: copyState(kits.grid?.overlays?.[boardId] ?? {}),
          },
        ]),
      ),
    };
  }
}

function projectQuizKit(
  extras: GameKitsPlayerView,
  kits: EngineKitsState,
  components: readonly GameComponentDefinition[],
  viewerPlayerId: number | null,
): void {
  const quiz = kits.quiz;
  const quizDefinitions = new Map(
    components
      .filter(
        (component): component is QuizDefinition =>
          component.component === 'quiz.bank',
      )
      .map((definition) => [definition.id, definition]),
  );
  if (quiz && Object.keys(quiz.orders).length > 0) {
    extras.quiz = {
      banks: Object.fromEntries(
        Object.entries(quiz.orders).map(([bankId, order]) => {
          const cursor = quiz.cursors[bankId] ?? 0;
          return [
            bankId,
            {
              count: order.length,
              cursor,
              remaining: Math.max(0, order.length - cursor),
            },
          ];
        }),
      ),
      sessions: Object.fromEntries(
        Object.entries(quiz.sessions).map(([sessionId, session]) => [
          sessionId,
          {
            id: session.id,
            bankId: session.bankId,
            question: publicQuizQuestion(
              quizDefinitions.get(session.bankId),
              session,
            ),
            participantPlayerIds: [...session.participantPlayerIds],
            answeredPlayerIds: Object.keys(session.answers).map(Number),
            phase: session.phase,
            scored: session.scored,
            ...(session.phase === 'revealed' || session.phase === 'closed'
              ? {
                  answers: copyState(session.answers),
                  correctAnswerIndex: session.correctAnswerIndex,
                }
              : viewerPlayerId != null &&
                  session.answers[String(viewerPlayerId)] != null
                ? { myAnswer: session.answers[String(viewerPlayerId)] }
                : {}),
          },
        ]),
      ),
    };
  }
}

function cardProjectionDefinitions(
  components: readonly GameComponentDefinition[],
): Array<HandsDefinition | CardSetsDefinition | CardZoneDefinition> {
  return components.filter(
    (
      component,
    ): component is HandsDefinition | CardSetsDefinition | CardZoneDefinition =>
      component.component === 'cards.hands' ||
      component.component === 'cards.sets' ||
      component.component === 'cards.zone',
  );
}

function projectDiceSet(
  definition: DiceDefinition,
  roll: { values: readonly number[]; total: number } | undefined,
  turnNumber: number,
  sequence: number,
): DiceSetPlayerView {
  return {
    id: definition.id,
    label: definition.count > 1 ? 'Dés' : 'Dé',
    sides: definition.sides,
    dice: Array.from({ length: definition.count }, (_, index) => ({
      id: `${definition.id}-${index + 1}`,
      label: `Dé ${index + 1}`,
      sides: definition.sides,
      ...(roll?.values[index] == null ? {} : { value: roll.values[index] }),
    })),
    ...(roll
      ? {
          total: roll.total,
          rollKey: `${turnNumber}:${sequence}:${definition.id}`,
        }
      : {}),
  };
}

function publicQuizQuestion(
  definition: QuizDefinition | undefined,
  session: ReadonlyState<QuizSessionState>,
): { id: string; prompt: string; choices: readonly string[] } {
  const question = definition?.questions.find(
    (candidate) => candidate.id === session.questionId,
  );
  if (!question) return { id: session.questionId, prompt: '', choices: [] };
  return {
    id: question.id,
    prompt: question.prompt,
    choices: quizSessionChoices(question, session),
  };
}
