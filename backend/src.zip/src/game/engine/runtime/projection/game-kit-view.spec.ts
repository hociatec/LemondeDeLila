import {
  createCardsKitState,
  type CardZoneDefinition,
  type HandsDefinition,
} from '../cards/cards-kit';
import { createDiceKitState, type DiceDefinition } from '../kits/dice-kit';
import type { EngineKitsState } from '../state/declarative-state';
import { projectGameKits } from './game-kit-view';
import { createGridKitState } from '../kits/grid-kit';
import { createMovementKitState } from '../kits/movement-kit';
import {
  createQuizKitState,
  GameQuizController,
  type QuizSessionState,
} from '../kits/quiz-kit';
import { createPawnKitState, type PawnSetDefinition } from '../kits/pawn-kit';

describe('projectGameKits', () => {
  it('uses the same question whitelist in quiz controller results without retaining choices', () => {
    const state = createQuizKitState();
    const quiz = new GameQuizController(state, {} as never);
    const question = {
      id: 'q',
      prompt: 'Question',
      choices: ['A', 'B'],
      answerIndex: 1,
      explanation: 'Secret answer B',
    };
    const definition = {
      component: 'quiz.bank' as const,
      id: 'bank',
      questions: [question],
    };
    quiz.create(definition);
    const next = quiz.next('bank');
    expect(next).toEqual({ id: 'q', prompt: 'Question', choices: ['A', 'B'] });
    expect(next?.choices).not.toBe(question.choices);
    quiz.create(definition);
    expect(quiz.ask('bank', [1])?.question).toEqual({
      id: 'q',
      prompt: 'Question',
      choices: ['A', 'B'],
    });
    expect(question.explanation).toBe('Secret answer B');
  });
  it('starts a new question pass when a repeatable bank is exhausted', () => {
    const state = createQuizKitState();
    const quiz = new GameQuizController(state, {} as never);
    quiz.create({
      component: 'quiz.bank',
      id: 'repeatable',
      repeat: true,
      questions: [
        { id: 'q', prompt: 'Question', choices: ['A', 'B'], answerIndex: 0 },
      ],
    });

    expect(quiz.next('repeatable')?.id).toBe('q');
    expect(quiz.next('repeatable')?.id).toBe('q');
  });
  it('publishes only declared quiz question fields before and after revelation', () => {
    const kits = createKits();
    const question = {
      id: 'q',
      prompt: 'Question',
      choices: ['A', 'B'],
      answerIndex: 1,
      explanation: 'Secret answer B',
    };
    kits.quiz.orders.bank = ['q'];
    kits.quiz.cursors.bank = 1;
    const session: QuizSessionState = (kits.quiz.sessions.round = {
      id: 'round',
      bankId: 'bank',
      questionId: 'q',
      participantPlayerIds: [1, -2],
      answers: { '1': 0, '-2': 1 },
      phase: 'answering',
      scored: false,
    });
    const definition = {
      component: 'quiz.bank' as const,
      id: 'bank',
      questions: [question],
    };
    for (const viewer of [null, 1, -2]) {
      const view = projectGameKits(kits, viewer, 0, [definition]);
      expect(view.quiz).toMatchObject({
        sessions: {
          round: {
            question: { id: 'q', prompt: 'Question', choices: ['A', 'B'] },
          },
        },
      });
      expect(JSON.stringify(view)).not.toContain('explanation');
      expect(JSON.stringify(view)).not.toContain('answerIndex');
      expect(JSON.stringify(view)).not.toContain('correctAnswerIndex');
    }
    session.phase = 'revealed';
    session.correctAnswerIndex = 1;
    const view = projectGameKits(kits, null, 0, [definition]);
    expect(view.quiz).toMatchObject({
      sessions: {
        round: { answers: { '1': 0, '-2': 1 }, correctAnswerIndex: 1 },
      },
    });
    expect(JSON.stringify(view)).not.toContain('explanation');
  });
  it('reveals owner hands and redacts every other private hand', () => {
    const kits = createKits();
    const handDefinition = {
      component: 'cards.hands',
      id: 'main',
      deck: 'main',
      initial: 1,
      visibility: 'owner',
    } satisfies HandsDefinition;
    kits.cards.decks.main = ['hidden'];
    kits.cards.discards.main = ['played'];
    kits.cards.hands.main = { '1': ['mine'], '2': ['theirs'] };

    expect(projectGameKits(kits, 1, 3, [handDefinition])).toMatchObject({
      cards: {
        decks: { main: { count: 1 } },
        discards: { main: { count: 1, cards: ['played'] } },
        hands: {
          main: {
            visibility: 'owner',
            byPlayer: { '1': ['mine'], '2': { count: 1 } },
          },
        },
      },
    });
    expect(projectGameKits(kits, null, 3, [handDefinition])).toMatchObject({
      cards: {
        decks: { main: { count: 1 } },
        discards: { main: { count: 1, cards: ['played'] } },
        hands: {
          main: {
            visibility: 'owner',
            byPlayer: { '1': { count: 1 }, '2': { count: 1 } },
          },
        },
      },
    });
  });

  it('reveals public hands to every viewer', () => {
    const kits = createKits();
    const handDefinition = {
      component: 'cards.hands',
      id: 'table',
      deck: 'main',
      initial: 0,
      visibility: 'public',
    } satisfies HandsDefinition;
    kits.cards.decks.main = [];
    kits.cards.hands.table = { '1': ['visible'] };

    expect(projectGameKits(kits, null, 0, [handDefinition])).toMatchObject({
      cards: {
        hands: {
          table: {
            visibility: 'public',
            byPlayer: { '1': ['visible'] },
          },
        },
      },
    });
  });

  it('redacts an owner hand after the owner leaves an active round', () => {
    const kits = createKits();
    const handDefinition = {
      component: 'cards.hands',
      id: 'main',
      deck: 'main',
      initial: 1,
      visibility: 'owner',
      ownerVisibility: 'active-round',
    } satisfies HandsDefinition;
    kits.cards.decks.main = ['remaining'];
    kits.cards.hands.main = { '1': ['hidden-after-leaving'] };

    expect(projectGameKits(kits, 1, 3, [handDefinition], [1])).toMatchObject({
      cards: {
        hands: {
          main: {
            byPlayer: { '1': { count: 1 } },
          },
        },
      },
    });
  });

  it('projects public zones and redacts hidden zones', () => {
    const kits = createKits();
    const publicZone = {
      component: 'cards.zone',
      id: 'table',
      deck: 'main',
      visibility: 'public',
    } satisfies CardZoneDefinition;
    const hiddenZone = {
      component: 'cards.zone',
      id: 'removed',
      deck: 'main',
      visibility: 'hidden',
    } satisfies CardZoneDefinition;
    kits.cards.decks.main = [];
    kits.cards.zones.table = ['visible'];
    kits.cards.zones.removed = ['secret'];

    expect(
      projectGameKits(kits, null, 0, [publicZone, hiddenZone]),
    ).toMatchObject({
      cards: {
        zones: {
          table: { visibility: 'public', cards: ['visible'] },
          removed: { visibility: 'hidden', cards: { count: 1 } },
        },
      },
    });
  });

  it('projects deterministic dice results without exposing kit internals', () => {
    const kits = createKits();
    const diceDefinition = {
      component: 'dice.set',
      id: 'main',
      count: 2,
      sides: 6,
    } satisfies DiceDefinition;
    kits.dice.rolls.main = { values: [2, 5], total: 7 };

    expect(projectGameKits(kits, 1, 4, [diceDefinition])).toMatchObject({
      dice: {
        id: 'main',
        label: 'Dés',
        sides: 6,
        dice: [
          { id: 'main-1', label: 'Dé 1', sides: 6, value: 2 },
          { id: 'main-2', label: 'Dé 2', sides: 6, value: 5 },
        ],
        total: 7,
        rollKey: '4:0:main',
      },
    });
  });

  it('omits initial pawn positions from the player projection', () => {
    const pawns = createPawnKitState();
    pawns.positions.racers = { waiting: 0, running: 4 };
    pawns.owners.racers = {};
    pawns.assignments.racers = {};
    const kits: EngineKitsState = { ...createKits(), pawns };
    const definition = {
      component: 'pawn.set',
      id: 'racers',
      perPlayer: 1,
      pawns: [
        { id: 'waiting', label: 'En attente' },
        { id: 'running', label: 'En course' },
      ],
    } satisfies PawnSetDefinition;

    expect(projectGameKits(kits, null, 0, [definition])).toMatchObject({
      pawns: { sets: { racers: { positions: { running: 4 } } } },
    });
    expect(
      projectGameKits(kits, null, 0, [definition]).pawns?.sets.racers.positions,
    ).not.toHaveProperty('waiting');
  });
});

function createKits() {
  return {
    cards: createCardsKitState(),
    movement: createMovementKitState(),
    dice: createDiceKitState(),
    grid: createGridKitState(),
    quiz: createQuizKitState(),
  } satisfies EngineKitsState;
}
