import {
  atAuthoringPath,
  withAuthoringPath,
} from '../contracts/authoring-origin';
import { GameConfigurationError } from '../contracts/game-domain.errors';
import { cardContent } from '../content/game-content';

export type CardId = string | number;
export type CardValue = CardId | object;
export type CardDefinition<
  TCard extends CardId | { id: CardId } = { id: CardId },
> = Readonly<TCard>;

/**
 * Runtime card representation. Stateless games keep their lightweight card
 * value; games with mutable per-copy state opt into an explicit instance.
 */
export type CardInstance<
  TDefinition extends CardValue,
  TInstanceState extends object | undefined = undefined,
> = TInstanceState extends object
  ? Readonly<{
      instanceId: string;
      definition: CardDefinition<Extract<TDefinition, CardId | { id: CardId }>>;
      state: TInstanceState;
    }>
  : TDefinition;

export type CardZone<
  TDefinition extends CardValue,
  TInstanceState extends object | undefined = undefined,
> = ReadonlyArray<CardInstance<TDefinition, TInstanceState>>;

export type DeckDefinition<TCard extends CardValue> = {
  readonly component: 'cards.deck';
  id: string;
  cards: readonly TCard[];
  /** Accepted content universe, when setup or exchanges add cards outside the initial pile. */
  catalog?: readonly TCard[];
  shuffle?: boolean;
  empty?: 'exhaust' | 'recycle';
};

export type DeckLifecycleState = {
  empty: 'exhaust' | 'recycle';
  exhausted: boolean;
};

export type HandsDefinition<TDeckId extends string = string> = {
  readonly component: 'cards.hands';
  id: string;
  deck: TDeckId;
  /** Additional source/discard decks covered by the primary deck's catalog. */
  acceptedDecks?: readonly TDeckId[];
  initial: number;
  /** Skip these cards during initial dealing, then restore them on top in draw order. */
  initialDeferredCardIds?: readonly CardId[];
  visibility: 'owner' | 'public';
  ownerVisibility?: 'always' | 'active-round';
};

export type CardZoneDefinition<TDeckId extends string = string> = {
  readonly component: 'cards.zone';
  id: string;
  deck: TDeckId;
  visibility: 'public' | 'hidden';
};

export type CardSetsDefinition<TCardId extends string = string> = {
  readonly component: 'cards.sets';
  id: string;
  hand: string;
  deck: string;
  sets: Readonly<Record<string, readonly TCardId[]>>;
  visibility?: 'owner' | 'public';
};

export type CardsKitState = {
  decks: Record<string, CardValue[]>;
  discards: Record<string, CardValue[]>;
  deckLifecycles: Record<string, DeckLifecycleState>;
  hands: Record<string, Record<string, CardValue[]>>;
  zones: Record<string, CardValue[]>;
  completedSets: Record<string, Record<string, string[]>>;
};

export type CardsPlayerView = {
  decks: Record<string, { count: number }>;
  discards: Record<string, { count: number; cards: CardValue[] }>;
  hands: Record<
    string,
    {
      visibility: HandsDefinition['visibility'];
      byPlayer: Record<string, CardValue[] | { count: number }>;
    }
  >;
  zones: Record<
    string,
    {
      visibility: CardZoneDefinition['visibility'];
      cards: CardValue[] | { count: number };
    }
  >;
  collections: Record<
    string,
    {
      visibility: 'owner' | 'public';
      byPlayer: Record<string, string[] | { count: number }>;
    }
  >;
};

export type CardContentId = CardId;

export type CardCatalog = {
  readonly cardsById: ReadonlyMap<string, CardValue>;
};

export const cards = {
  deck<TCard extends CardValue>(
    definition: Omit<DeckDefinition<TCard>, 'component'>,
  ): DeckDefinition<TCard> {
    assertDeckCatalog(definition);
    const identifiedCards = definition.cards.filter(isIdentifiedCard);
    if (
      identifiedCards.length > 0 &&
      identifiedCards.length !== definition.cards.length
    ) {
      throw withAuthoringPath(
        new GameConfigurationError(
          `La pioche ${definition.id} mélange références de contenu et valeurs libres`,
        ),
        `cards[${definition.cards.findIndex((card) => isIdentifiedCard(card) !== isIdentifiedCard(definition.cards[0]))}]`,
      );
    }
    const catalog =
      identifiedCards.length === definition.cards.length
        ? atAuthoringPath('cards', () => cardContent(identifiedCards))
        : deepFreeze(structuredClone(definition.cards));
    return deepFreeze({
      ...definition,
      component: 'cards.deck',
      cards: catalog,
    });
  },

  hands<const TDeckId extends string>(
    definition: Omit<HandsDefinition<TDeckId>, 'component'>,
  ): HandsDefinition<TDeckId> {
    return deepFreeze({
      ...definition,
      component: 'cards.hands',
      ...(definition.acceptedDecks
        ? { acceptedDecks: [...definition.acceptedDecks] }
        : {}),
      ...(definition.initialDeferredCardIds
        ? { initialDeferredCardIds: [...definition.initialDeferredCardIds] }
        : {}),
    });
  },

  zone<const TDeckId extends string>(
    definition: Omit<CardZoneDefinition<TDeckId>, 'component'>,
  ): CardZoneDefinition<TDeckId> {
    return Object.freeze({ ...definition, component: 'cards.zone' });
  },

  sets<TCardId extends string>(
    definition: Omit<CardSetsDefinition<TCardId>, 'component'>,
  ): CardSetsDefinition<TCardId> {
    return Object.freeze({
      ...definition,
      component: 'cards.sets',
      sets: Object.freeze(
        Object.fromEntries(
          Object.entries(definition.sets).map(([setId, cardIds]) => [
            setId,
            Object.freeze([...cardIds]),
          ]),
        ),
      ),
    });
  },
};

export function isIdentifiedCard<TValue>(
  value: TValue,
): value is TValue & { readonly id: CardContentId } {
  if (value == null || typeof value !== 'object' || !('id' in value)) {
    return false;
  }
  const id = value.id;
  return typeof id === 'string' || typeof id === 'number';
}

export function contentIdKey(id: CardContentId): string {
  return `${typeof id}:${String(id)}`;
}

function assertDeckCatalog(
  definition: Omit<DeckDefinition<CardValue>, 'component'>,
): void {
  if (!definition.catalog) return;
  const identified = definition.catalog.filter(isIdentifiedCard);
  if (identified.length > 0 && identified.length !== definition.catalog.length)
    throw withAuthoringPath(
      new GameConfigurationError(
        'A card catalog cannot mix objects and free identifiers',
      ),
      `catalog[${definition.catalog.findIndex((card) => isIdentifiedCard(card) !== isIdentifiedCard(definition.catalog?.[0]))}]`,
    );
  if (identified.length > 0)
    atAuthoringPath('catalog', () => cardContent(identified));
  const identity = (card: CardValue): string => {
    if (isIdentifiedCard(card)) return contentIdKey(card.id);
    if (typeof card === 'string' || typeof card === 'number')
      return contentIdKey(card);
    throw new GameConfigurationError(
      'An explicit card catalog requires persistent identifiers',
    );
  };
  const accepted = new Set(
    definition.catalog.map((card, index) =>
      atAuthoringPath(`catalog[${index}]`, () => identity(card)),
    ),
  );
  for (const [index, card] of definition.cards.entries()) {
    const path = `cards[${index}]`;
    if (!accepted.has(atAuthoringPath(path, () => identity(card))))
      throw withAuthoringPath(
        new GameConfigurationError(
          `Initial card absent from catalog: ${definition.id}`,
        ),
        path,
      );
  }
}

function deepFreeze<TValue>(value: TValue): TValue {
  if (value == null || typeof value !== 'object' || Object.isFrozen(value)) {
    return value;
  }
  for (const nested of Object.values(value)) deepFreeze(nested);
  return Object.freeze(value);
}
