import { cloneStaticContent } from '../content/content-immutability';
import {
  assertGameCount,
  assertGamePlayerId,
} from '../kits/numeric-invariants';
import { assertCardStateShape } from './card-state-invariants';
import { assertHandDeckDefinitions } from './hand-deck-definitions';
import {
  assertCardHandDestination,
  assertCardRecipients,
} from './card-hand-invariants';
import {
  GameConfigurationError,
  GameNotFoundError,
  GameRuleViolationError,
  GameStateViolationError,
} from '../contracts/game-domain.errors';
import type { GameRng } from '../../../core/application/models/game-execution-context.model';
import type { EventVisibility } from '../../../core/application/models/game-event.model';
import {
  contentIdKey,
  isIdentifiedCard,
  type CardCatalog,
  type CardId,
  type CardSetsDefinition,
  type CardZoneDefinition,
  type CardValue,
  type CardsKitState,
  type DeckDefinition,
  type DeckLifecycleState,
  type HandsDefinition,
} from './cards-contracts';

export abstract class GameCardsStateController {
  abstract give<TCard extends CardValue>(
    handId: string,
    playerId: number,
    card: TCard,
  ): void;
  abstract deal(
    deckId: string,
    handId: string,
    playerIds: readonly number[],
    count: number,
    deferredCardIds?: readonly CardId[],
  ): void;

  constructor(
    protected readonly state: CardsKitState,
    protected readonly random: Pick<GameRng, 'pick' | 'shuffle'>,
    protected readonly emit: (
      type: string,
      data: Record<string, unknown>,
      visibility?: EventVisibility,
    ) => void = () => {},
    definitions: readonly (
      | DeckDefinition<CardValue>
      | HandsDefinition
      | CardSetsDefinition
      | CardZoneDefinition
    )[] = [],
  ) {
    assertCardStateShape(state);
    for (const definition of definitions) this.registerDefinition(definition);
    for (const hand of this.handDefinitions.values())
      assertHandDeckDefinitions(hand, this.deckDefinitions);
    for (const [deckId, deck] of Object.entries(this.state.decks)) {
      this.state.decks[deckId] = deck.map((card) =>
        this.toPersistentCard(deckId, card),
      );
      this.state.discards[deckId] = (this.state.discards[deckId] ?? []).map(
        (card) => this.toPersistentCard(deckId, card),
      );
    }
    for (const [handId, byPlayer] of Object.entries(this.state.hands)) {
      const deckId = this.handDefinitions.get(handId)?.deck;
      if (!deckId) continue;
      for (const [playerId, hand] of Object.entries(byPlayer)) {
        byPlayer[playerId] = hand.map((card) =>
          this.toPersistentCard(deckId, card),
        );
      }
    }
    for (const [zoneId, zone] of Object.entries(this.state.zones)) {
      const deckId = this.zoneDefinitions.get(zoneId)?.deck;
      if (!deckId) continue;
      this.state.zones[zoneId] = zone.map((card) =>
        this.toPersistentCard(deckId, card),
      );
    }
  }

  protected readonly catalogs = new Map<string, CardCatalog>();
  private readonly deckIds = new Set<string>();
  private readonly deckDefinitions = new Map<
    string,
    DeckDefinition<CardValue>
  >();
  private readonly cardIdentifiers = new Map<string, ReadonlySet<string>>();
  protected readonly handDefinitions = new Map<string, HandsDefinition>();
  protected readonly setDefinitions = new Map<string, CardSetsDefinition>();
  protected readonly zoneDefinitions = new Map<string, CardZoneDefinition>();

  createDeck<TCard extends CardValue>(definition: DeckDefinition<TCard>): void {
    this.registerCatalog(definition);
    const values = definition.cards.map((card) =>
      this.toPersistentCard(definition.id, card),
    );
    this.state.decks[definition.id] = definition.shuffle
      ? this.random.shuffle(values)
      : values;
    this.state.discards[definition.id] = [];
    this.state.deckLifecycles[definition.id] = {
      empty: definition.empty ?? 'exhaust',
      exhausted: false,
    };
  }

  createHands(definition: HandsDefinition, playerIds: readonly number[]): void {
    assertHandDeckDefinitions(definition, this.deckDefinitions);
    assertCardRecipients(playerIds);
    assertGameCount(definition.initial, 100_000);
    this.lifecycle(definition.deck);
    this.handDefinitions.set(definition.id, definition);
    this.state.hands[definition.id] = Object.fromEntries(
      playerIds.map((playerId) => [String(playerId), []]),
    );
    this.deal(
      definition.deck,
      definition.id,
      playerIds,
      definition.initial,
      definition.initialDeferredCardIds,
    );
  }

  createSets(
    definition: CardSetsDefinition,
    playerIds: readonly number[],
  ): void {
    assertCardRecipients(playerIds);
    this.lifecycle(definition.deck);
    if (playerIds.length > 0)
      assertCardHandDestination(
        this.handDefinitions,
        definition.hand,
        definition.deck,
        playerIds[0],
      );
    this.setDefinitions.set(definition.id, definition);
    this.state.completedSets[definition.id] = Object.fromEntries(
      playerIds.map((playerId) => [String(playerId), []]),
    );
  }

  readonly createZone = (definition: CardZoneDefinition): void => {
    this.lifecycle(definition.deck);
    this.zoneDefinitions.set(definition.id, definition);
    this.state.zones[definition.id] = [];
  };

  removeDeck(deckId: string): void {
    this.deckDefinitions.delete(deckId);
    delete this.state.decks[deckId];
    delete this.state.discards[deckId];
    delete this.state.deckLifecycles[deckId];
    this.catalogs.delete(deckId);
    this.deckIds.delete(deckId);
  }

  resetHands(handId: string): void {
    delete this.state.hands[handId];
    this.handDefinitions.delete(handId);
  }

  resetSets(collectionId: string): void {
    delete this.state.completedSets[collectionId];
    this.setDefinitions.delete(collectionId);
  }

  readonly resetZone = (zoneId: string): void => {
    delete this.state.zones[zoneId];
    this.zoneDefinitions.delete(zoneId);
  };

  assertValid(): void {
    assertCardStateShape(this.state);
    for (const deckId of Object.keys(this.state.decks)) {
      if (!this.deckIds.has(deckId))
        throw new GameStateViolationError('Pioche non définie', { deckId });
    }
    for (const handId of Object.keys(this.state.hands)) {
      if (!this.handDefinitions.has(handId))
        throw new GameStateViolationError('Main non définie', { handId });
    }
    for (const zoneId of Object.keys(this.state.zones)) {
      if (!this.zoneDefinitions.has(zoneId))
        throw new GameStateViolationError('Zone non définie', { zoneId });
    }
    for (const [collectionId, players] of Object.entries(
      this.state.completedSets,
    )) {
      const definition = this.setDefinitions.get(collectionId);
      if (
        !definition ||
        Object.values(players).some((sets) =>
          sets.some((setId) => !Object.hasOwn(definition.sets, setId)),
        )
      )
        throw new GameStateViolationError('Famille non définie', {
          collectionId,
        });
    }
    for (const [handId, definition] of Object.entries(
      Object.fromEntries(this.handDefinitions),
    )) {
      const hands = this.state.hands[handId];
      if (!hands || !this.state.decks[definition.deck]) {
        throw new GameStateViolationError('État de main invalide', {
          handId,
          deckId: definition.deck,
        });
      }
    }
    for (const [collectionId, definition] of Object.entries(
      Object.fromEntries(this.setDefinitions),
    )) {
      if (
        !this.state.completedSets[collectionId] ||
        !this.state.hands[definition.hand] ||
        !this.state.decks[definition.deck]
      ) {
        throw new GameStateViolationError('Collection de cartes invalide', {
          collectionId,
        });
      }
    }
    for (const [zoneId, definition] of this.zoneDefinitions) {
      if (!Array.isArray(this.state.zones[zoneId])) {
        throw new GameStateViolationError('Zone de cartes invalide', {
          zoneId,
        });
      }
      if (!this.state.decks[definition.deck]) {
        throw new GameStateViolationError('Pioche de zone absente', {
          zoneId,
          deckId: definition.deck,
        });
      }
    }
  }

  shuffle(deckId: string): void {
    const deck = this.state.decks[deckId];
    if (!deck) throw new GameNotFoundError(`Pioche inconnue: ${deckId}`);
    this.state.decks[deckId] = this.random.shuffle(deck);
  }

  resetDeck<TCard extends CardValue>(
    deckId: string,
    cards: readonly TCard[],
    options: { shuffle?: boolean } = {},
  ): void {
    this.registerCatalog({
      component: 'cards.deck',
      id: deckId,
      cards,
    });
    const persistentCards = cards.map((card) =>
      this.toPersistentCard(deckId, card),
    );
    this.state.decks[deckId] = options.shuffle
      ? this.random.shuffle(persistentCards)
      : persistentCards;
    this.state.discards[deckId] = [];
    const lifecycle = this.lifecycle(deckId);
    lifecycle.exhausted = false;
  }

  clearHands(handId: string, playerIds: readonly number[]): void {
    assertCardRecipients(playerIds);
    if (!this.handDefinitions.has(handId))
      throw new GameNotFoundError(`Main inconnue: ${handId}`);
    this.state.hands[handId] = Object.fromEntries(
      playerIds.map((playerId) => [String(playerId), []]),
    );
  }

  protected lifecycle(deckId: string): DeckLifecycleState {
    if (!Object.hasOwn(this.state.decks, deckId))
      throw new GameNotFoundError(`Pioche inconnue: ${deckId}`);
    return (this.state.deckLifecycles[deckId] ??= {
      empty: 'exhaust',
      exhausted: false,
    });
  }

  protected requireSets(collectionId: string): CardSetsDefinition {
    const definition = this.setDefinitions.get(collectionId);
    if (!definition) {
      throw new GameNotFoundError(
        `Collection de cartes inconnue: ${collectionId}`,
      );
    }
    return definition;
  }

  protected persistentHand(handId: string, playerId: number): CardValue[] {
    assertGamePlayerId(playerId);
    if (!this.handDefinitions.has(handId))
      throw new GameNotFoundError(`Main inconnue: ${handId}`);
    return this.state.hands[handId]?.[String(playerId)] ?? [];
  }

  private registerCatalog<TCard extends CardValue>(
    definition: DeckDefinition<TCard>,
  ): void {
    this.deckIds.add(definition.id);
    this.deckDefinitions.set(definition.id, definition);
    const content = definition.catalog ?? definition.cards;
    const identifiers = content.map((card) =>
      isIdentifiedCard(card)
        ? contentIdKey(card.id)
        : typeof card === 'string' || typeof card === 'number'
          ? contentIdKey(card)
          : null,
    );
    if (identifiers.every((id) => id !== null))
      this.cardIdentifiers.set(definition.id, new Set(identifiers));
    else this.cardIdentifiers.delete(definition.id);
    const identifiedCards = content.filter(isIdentifiedCard);
    if (content.length === 0 || identifiedCards.length !== content.length) {
      this.catalogs.delete(definition.id);
      return;
    }
    const cardsById = new Map<string, CardValue>();
    for (const card of identifiedCards) {
      const key = contentIdKey(card.id);
      if (cardsById.has(key)) {
        throw new GameConfigurationError(
          `Identifiant de carte dupliqué dans ${definition.id}: ${String(card.id)}`,
        );
      }
      cardsById.set(key, card);
    }
    this.catalogs.set(definition.id, { cardsById });
  }

  private registerDefinition(
    definition:
      | DeckDefinition<CardValue>
      | HandsDefinition
      | CardSetsDefinition
      | CardZoneDefinition,
  ): void {
    if (definition.component === 'cards.deck') {
      this.registerCatalog(definition);
    } else if (definition.component === 'cards.hands') {
      this.handDefinitions.set(definition.id, definition);
    } else if (definition.component === 'cards.sets') {
      this.setDefinitions.set(definition.id, definition);
    } else {
      this.zoneDefinitions.set(definition.id, definition);
    }
  }

  protected toPersistentCard<TCard extends CardValue>(
    deckId: string,
    card: TCard,
  ): CardValue {
    const identifier = isIdentifiedCard(card)
      ? contentIdKey(card.id)
      : typeof card === 'string' || typeof card === 'number'
        ? contentIdKey(card)
        : null;
    const known = this.cardIdentifiers.get(deckId);
    if (known && (identifier === null || !known.has(identifier)))
      throw new GameRuleViolationError('UNKNOWN_CARD_CONTENT', { deckId });
    const catalog = this.catalogs.get(deckId);
    if (!catalog || !isIdentifiedCard(card)) {
      return structuredClone(card);
    }
    const key = contentIdKey(card.id);
    if (!catalog.cardsById.has(key)) {
      throw new GameRuleViolationError(
        'UNKNOWN_CARD_CONTENT',
        { deckId, cardId: card.id },
        'Carte absente du catalogue statique',
      );
    }
    return card.id;
  }

  protected fromPersistentCard<TCard extends CardValue>(
    deckId: string,
    card: CardValue,
  ): TCard {
    const content =
      typeof card === 'string' || typeof card === 'number'
        ? this.catalogs.get(deckId)?.cardsById.get(contentIdKey(card))
        : undefined;
    return cloneStaticContent((content ?? card) as TCard);
  }
}
