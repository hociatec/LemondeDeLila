import type { PlayerState } from '../../../core/application/models/game-state.model';
import type { GameContext } from '../definitions/game-author-context';
import { typedRuntimeHandler } from './typed-runtime-handler';
import {
  type ChoiceResolver,
  type DefinedChoiceResolver,
  type DefinedGameAction,
  type GameActionDefinition,
  type GameActionExecution,
  type RawChoiceResolution,
} from '../contracts/author-rule-contracts';

export function defineAction<TState extends object, TInput extends object>(
  action: GameActionDefinition<TState, TInput>,
): DefinedGameAction<TState, TInput> {
  action = { ...action };
  const runtimeHandler = typedRuntimeHandler<
    TInput,
    Omit<GameActionExecution<TState, object>, 'input'>
  >({
    schema: action.input,
    path: 'action.payload',
    handle: (execution, input) => action.execute({ ...execution, input }),
  });
  return Object.freeze({
    ...action,
    input: runtimeHandler.input,
    parseInput: (payload: Record<string, unknown>) =>
      runtimeHandler.parse(payload),
    ...(action.validate
      ? {
          validateInput: (input: GameActionExecution<TState, object>) =>
            action.validate?.({ ...input, input: input.input as TInput }) ??
            true,
        }
      : {}),
    ...(action.enumerate
      ? {
          enumerateInputs: (input: {
            state: TState;
            actor: PlayerState;
            ctx: GameContext<TState>;
          }) => action.enumerate?.(input) ?? [],
        }
      : {}),
    ...(action.candidates
      ? {
          enumerateCandidateInputs: (input: {
            state: TState;
            actor: PlayerState;
            ctx: GameContext<TState>;
            query: Readonly<Record<string, unknown>>;
            offset: number;
            limit: number;
          }) => action.candidates?.(input) ?? [],
        }
      : {}),
    executeInput: ({
      input,
      ...execution
    }: GameActionExecution<TState, object>) =>
      runtimeHandler.handle(execution, input),
  });
}

export function overrideAction<TState extends object, TInput extends object>(
  actionId: string,
  action: GameActionDefinition<TState, TInput>,
): DefinedGameAction<TState, TInput> {
  return defineAction({
    ...action,
    overrides: actionId,
  });
}

export function defineChoice<TState extends object, TValue>(
  choice: ChoiceResolver<TState, TValue>,
): DefinedChoiceResolver<TState, TValue> {
  choice = { ...choice };
  const runtimeHandler = typedRuntimeHandler<
    TValue,
    Omit<RawChoiceResolution<TState>, 'rawValue'>
  >({
    schema: choice.input,
    path: 'choice.value',
    handle: (resolution, value) => choice.resolve({ ...resolution, value }),
  });
  return Object.freeze({
    ...choice,
    input: runtimeHandler.input,
    resolveRaw: ({ rawValue, ...resolution }: RawChoiceResolution<TState>) =>
      runtimeHandler.handle(resolution, rawValue),
  });
}
