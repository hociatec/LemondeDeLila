import { GameRankingController } from './ranking-kit';
import {
  assertGameCount,
  assertGameValue,
  assertPlayerValueId,
  assertGamePlayerId,
  assertStatusMetadata,
} from './numeric-invariants';
import type {
  PlayerStatus,
  PlayerValuesKitState,
  StatusScope,
} from './player-values-contracts';
export type {
  CommonStatusId,
  PlayerStatus,
  PlayerValuesKitState,
  PlayerValuesPlayerView,
  PlayerValuesVisibility,
  ScorePlayerView,
  StatusScope,
} from './player-values-contracts';
export { commonStatuses } from './player-values-contracts';

export function createPlayerValuesKitState<
  TResourceId extends string = string,
  TCounterId extends string = string,
  TStatusData extends object = Record<string, unknown>,
  TTurnFlags extends Record<string, unknown> = Record<string, unknown>,
>(): PlayerValuesKitState<TResourceId, TCounterId, TStatusData, TTurnFlags> {
  return {
    scores: {},
    resources: {},
    counters: {},
    statuses: {},
    turnFlags: {},
    scheduledSkips: {},
    scheduledExtraTurns: {},
  } as PlayerValuesKitState<TResourceId, TCounterId, TStatusData, TTurnFlags>;
}

export class GameScoreController {
  constructor(
    private readonly state: PlayerValuesKitState,
    private readonly emit: (
      type: string,
      data: Record<string, unknown>,
    ) => void,
  ) {}

  get(playerId: number): number {
    assertGamePlayerId(playerId);
    return this.state.scores[String(playerId)] ?? 0;
  }

  set(
    playerId: number,
    value: number,
    options: { announce?: boolean } = {},
  ): number {
    const previous = this.get(playerId);
    assertGameValue(value);
    assertGameValue(previous);
    assertGameValue(value - previous);
    this.state.scores[String(playerId)] = value;
    this.emit('score.changed', {
      playerId,
      previous,
      value,
      delta: value - previous,
      ...(options.announce === false ? { announce: false } : {}),
    });
    return value;
  }

  add(
    playerId: number,
    amount: number,
    options: { announce?: boolean } = {},
  ): number {
    return this.set(playerId, this.get(playerId) + amount, options);
  }

  subtract(
    playerId: number,
    amount: number,
    options: { announce?: boolean } = {},
  ): number {
    return this.add(playerId, -amount, options);
  }

  ranking(direction: 'asc' | 'desc' = 'desc'): number[][] {
    return new GameRankingController().tiers(
      Object.keys(this.state.scores).map(Number),
      { value: (playerId) => this.get(playerId), direction },
    );
  }

  leaders(): number[] {
    return this.ranking()[0] ?? [];
  }
}

export { GameResourcesController } from './resource-controller';

export class GameCountersController<TCounterId extends string = string> {
  constructor(
    private readonly state: PlayerValuesKitState<string, TCounterId>,
    private readonly emit: (
      type: string,
      data: Record<string, unknown>,
    ) => void,
  ) {}

  get(counter: TCounterId): number {
    assertPlayerValueId(counter);
    return this.state.counters?.[counter] ?? 0;
  }

  set(counter: TCounterId, value: number): number {
    const previous = this.get(counter);
    assertGameValue(value);
    assertGameValue(previous);
    assertGameValue(value - previous);
    const counters = (this.state.counters ??= {} as Record<TCounterId, number>);
    counters[counter] = value;
    this.emit('counter.changed', {
      counter,
      previous,
      value,
      delta: value - previous,
    });
    return value;
  }

  add(counter: TCounterId, amount: number): number {
    return this.set(counter, this.get(counter) + amount);
  }

  subtract(counter: TCounterId, amount: number): number {
    return this.add(counter, -amount);
  }

  /** Atomically reads and clears a transient aggregate counter. */
  drain(counter: TCounterId): number {
    const value = this.get(counter);
    if (value !== 0) this.set(counter, 0);
    return value;
  }
}

export class GameStatusController<
  TStatusData extends object = Record<string, unknown>,
> {
  constructor(
    private readonly state: PlayerValuesKitState<string, string, TStatusData>,
  ) {}

  add(
    playerId: number,
    id: string,
    options: {
      turns?: number;
      scope?: StatusScope;
      data?: TStatusData;
      source?: PlayerStatus['source'];
      stacks?: number;
      stacking?: 'replace' | 'add';
      categories?: readonly string[];
    } = {},
  ): void {
    if (options.turns != null) assertGameCount(options.turns);
    assertGamePlayerId(playerId);
    assertPlayerValueId(id);
    assertStatusMetadata(options);
    const statuses = (this.state.statuses[String(playerId)] ??= []);
    const previous = statuses.find((status) => status.id === id);
    const stacks =
      (options.stacking === 'add' && previous ? (previous.stacks ?? 1) : 0) +
      (options.stacks ?? 1);
    assertStatusMetadata({ stacks });
    const status: PlayerStatus<TStatusData> = {
      id,
      remaining: options.turns == null ? null : Math.max(0, options.turns),
      scope: options.scope ?? 'turn',
      data: structuredClone(options.data ?? ({} as TStatusData)),
      ...(options.source ? { source: structuredClone(options.source) } : {}),
      ...(options.stacks !== undefined || options.stacking === 'add'
        ? { stacks }
        : {}),
      ...(options.categories ? { categories: [...options.categories] } : {}),
    };
    const existing = statuses.findIndex((candidate) => candidate.id === id);
    if (existing < 0) statuses.push(status);
    else statuses[existing] = status;
  }

  has(playerId: number, id: string): boolean {
    return (this.state.statuses[String(playerId)] ?? []).some(
      (status) => status.id === id,
    );
  }

  get(playerId: number, id: string): PlayerStatus<TStatusData> | null {
    const status = (this.state.statuses[String(playerId)] ?? []).find(
      (candidate) => candidate.id === id,
    );
    return status ? structuredClone(status) : null;
  }

  list(playerId: number): PlayerStatus<TStatusData>[] {
    return structuredClone(this.state.statuses[String(playerId)] ?? []);
  }

  remove(playerId: number, id: string): void {
    const statuses = this.state.statuses[String(playerId)] ?? [];
    this.state.statuses[String(playerId)] = statuses.filter(
      (status) => status.id !== id,
    );
  }

  consume(playerId: number, id: string): boolean {
    if (!this.has(playerId, id)) return false;
    const status = this.state.statuses[String(playerId)].find(
      (candidate) => candidate.id === id,
    );
    if (status && (status.stacks ?? 1) > 1)
      status.stacks = (status.stacks ?? 1) - 1;
    else this.remove(playerId, id);
    return true;
  }

  intercept(playerId: number, category: string): boolean {
    const status = this.state.statuses[String(playerId)]?.find((candidate) =>
      candidate.categories?.includes(category),
    );
    return status ? this.consume(playerId, status.id) : false;
  }

  tick(scope: StatusScope, playerId?: number): void {
    if (scope === 'until-used') return;
    const keys =
      playerId == null ? Object.keys(this.state.statuses) : [String(playerId)];
    for (const key of keys) {
      const statuses = this.state.statuses[key] ?? [];
      for (const status of statuses) {
        if (status.scope === scope && status.remaining != null)
          status.remaining -= 1;
      }
      this.state.statuses[key] = statuses.filter(
        (status) =>
          status.scope !== scope ||
          (status.remaining != null && status.remaining > 0),
      );
    }
  }
}
