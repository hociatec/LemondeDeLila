import {
  GameConfigurationError,
  GameNotFoundError,
  GameRuleViolationError,
  GameStateViolationError,
} from '../../../core/domain/errors/game-domain.errors';

export type GridDefinition = {
  readonly component: 'grid.board';
  readonly id: string;
  readonly width: number;
  readonly height: number;
  readonly diagonals?: boolean;
};

export type GridPosition = { x: number; y: number };
export type GridKitState<TCellState = unknown, TOverlayState = unknown> = {
  cells: Record<string, Record<string, TCellState>>;
  /** Typed-by-caller board layers for edges, walls and other grid overlays. */
  overlays: Record<string, Record<string, TOverlayState[]>>;
};

export const grid = {
  board(options: Omit<GridDefinition, 'component'>): GridDefinition {
    if (
      !Number.isInteger(options.width) ||
      !Number.isInteger(options.height) ||
      options.width < 1 ||
      options.height < 1
    ) {
      throw new GameConfigurationError('Dimensions de grille invalides');
    }
    return Object.freeze({ ...options, component: 'grid.board' });
  },
};

export class GameGridController<TCellState = unknown, TOverlayState = unknown> {
  constructor(
    private readonly state: GridKitState<TCellState, TOverlayState>,
    definitions: readonly GridDefinition[] = [],
  ) {
    this.state.overlays ??= {};
    for (const definition of definitions) {
      this.definitions.set(definition.id, definition);
    }
  }

  private readonly definitions = new Map<string, GridDefinition>();

  create(definition: GridDefinition): void {
    this.definitions.set(definition.id, definition);
    this.state.cells[definition.id] ??= {};
  }

  reset(boardId: string): void {
    this.definitions.delete(boardId);
    delete this.state.cells[boardId];
    delete this.state.overlays[boardId];
  }

  assertValid(): void {
    assertGridRecord(this.state.cells);
    assertGridRecord(this.state.overlays);
    for (const [boardId, cells] of Object.entries(this.state.cells)) {
      const board = this.definitions.get(boardId);
      if (!board) {
        throw new GameStateViolationError('Grille absente', { boardId });
      }
      assertGridRecord(cells);
      for (const key of Object.keys(cells)) {
        const [x, y] = key.split(',').map(Number);
        if (
          !Number.isInteger(x) ||
          !Number.isInteger(y) ||
          key !== cellKey({ x, y }) ||
          x < 0 ||
          y < 0 ||
          x >= board.width ||
          y >= board.height
        ) {
          throw new GameStateViolationError('Case de grille invalide', {
            boardId,
            key,
          });
        }
      }
    }
    for (const [boardId, layers] of Object.entries(this.state.overlays)) {
      if (!this.definitions.has(boardId)) {
        throw new GameStateViolationError('Grille absente', { boardId });
      }
      assertGridRecord(layers);
      for (const values of Object.values(layers)) {
        if (!Array.isArray(values)) {
          throw new GameStateViolationError('Couche de grille invalide', {
            boardId,
          });
        }
      }
    }
  }

  inside(boardId: string, position: GridPosition): boolean {
    const board = this.requireBoard(boardId);
    return (
      Number.isInteger(position.x) &&
      Number.isInteger(position.y) &&
      position.x >= 0 &&
      position.y >= 0 &&
      position.x < board.width &&
      position.y < board.height
    );
  }

  get<TValue extends TCellState = TCellState>(
    boardId: string,
    position: GridPosition,
  ): TValue | null {
    if (!this.inside(boardId, position)) return null;
    return (
      (this.state.cells[boardId]?.[cellKey(position)] as TValue | undefined) ??
      null
    );
  }

  set<TValue extends TCellState>(
    boardId: string,
    position: GridPosition,
    value: TValue,
  ): void {
    if (!this.inside(boardId, position)) {
      throw new GameRuleViolationError(
        'GRID_POSITION_OUT_OF_BOUNDS',
        { boardId, position },
        'Case hors grille',
      );
    }
    (this.state.cells[boardId] ??= {})[cellKey(position)] = value;
  }

  clear(boardId: string, position: GridPosition): void {
    this.requireBoard(boardId);
    delete this.state.cells[boardId]?.[cellKey(position)];
  }

  entries<TValue extends TCellState = TCellState>(
    boardId: string,
  ): Array<{ position: GridPosition; value: TValue }> {
    this.requireBoard(boardId);
    return Object.entries(this.state.cells[boardId] ?? {})
      .map(([key, value]) => {
        const [x, y] = key.split(',').map(Number);
        return { position: { x, y }, value: value as TValue };
      })
      .sort(
        (left, right) =>
          left.position.y - right.position.y ||
          left.position.x - right.position.x,
      );
  }

  overlays<TValue extends TOverlayState = TOverlayState>(
    boardId: string,
    layerId: string,
  ): readonly TValue[] {
    this.requireBoard(boardId);
    return (this.state.overlays[boardId]?.[layerId] ?? []) as TValue[];
  }

  setOverlays<TValue extends TOverlayState>(
    boardId: string,
    layerId: string,
    values: readonly TValue[],
  ): void {
    this.requireBoard(boardId);
    (this.state.overlays[boardId] ??= {})[layerId] = [
      ...structuredClone(values),
    ];
  }

  appendOverlay<TValue extends TOverlayState>(
    boardId: string,
    layerId: string,
    value: TValue,
  ): void {
    this.requireBoard(boardId);
    ((this.state.overlays[boardId] ??= {})[layerId] ??= []).push(
      structuredClone(value),
    );
  }

  full(boardId: string): boolean {
    const board = this.requireBoard(boardId);
    return (
      Object.keys(this.state.cells[boardId] ?? {}).length >=
      board.width * board.height
    );
  }

  emptyCells(boardId: string): GridPosition[] {
    const board = this.requireBoard(boardId);
    const empty: GridPosition[] = [];
    for (let y = 0; y < board.height; y += 1) {
      for (let x = 0; x < board.width; x += 1) {
        if (this.get(boardId, { x, y }) == null) empty.push({ x, y });
      }
    }
    return empty;
  }

  lineWinner<TValue extends TCellState = TCellState>(
    boardId: string,
    length: number,
  ): TValue | null {
    const board = this.requireBoard(boardId);
    const cells = Array.from(
      { length: board.width * board.height },
      (_, index) =>
        this.get<TValue>(boardId, {
          x: index % board.width,
          y: Math.floor(index / board.width),
        }),
    );
    return scanGridWinner(cells, board.width, board.height, length);
  }

  neighbors(boardId: string, position: GridPosition): GridPosition[] {
    const board = this.requireBoard(boardId);
    const offsets = [
      [-1, 0],
      [1, 0],
      [0, -1],
      [0, 1],
      ...(board.diagonals
        ? [
            [-1, -1],
            [1, -1],
            [-1, 1],
            [1, 1],
          ]
        : []),
    ];
    return offsets
      .map(([x, y]) => ({ x: position.x + x, y: position.y + y }))
      .filter((candidate) => this.inside(boardId, candidate));
  }

  private requireBoard(boardId: string): Omit<GridDefinition, 'component'> {
    const board = this.definitions.get(boardId);
    if (!board) throw new GameNotFoundError(`Grille inconnue: ${boardId}`);
    return board;
  }
}

export function createGridKitState<
  TCellState = unknown,
  TOverlayState = unknown,
>(): GridKitState<TCellState, TOverlayState> {
  return { cells: {}, overlays: {} };
}

function cellKey(position: GridPosition): string {
  return `${position.x},${position.y}`;
}

function assertGridRecord(value: unknown): void {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) {
    throw new GameStateViolationError('Table de grille invalide');
  }
}

export function scanGridWinner<TValue>(
  cells: readonly (TValue | null)[],
  width: number,
  height: number,
  length: number,
): TValue | null {
  const directions = [
    { x: 1, y: 0 },
    { x: 0, y: 1 },
    { x: 1, y: 1 },
    { x: 1, y: -1 },
  ];
  for (let y = 0; y < height; y += 1) {
    for (let x = 0; x < width; x += 1) {
      const owner = cells[y * width + x];
      if (owner == null) continue;
      for (const direction of directions) {
        let complete = true;
        for (let offset = 1; offset < length; offset += 1) {
          const nextX = x + direction.x * offset;
          const nextY = y + direction.y * offset;
          if (
            nextX < 0 ||
            nextY < 0 ||
            nextX >= width ||
            nextY >= height ||
            cells[nextY * width + nextX] !== owner
          ) {
            complete = false;
            break;
          }
        }
        if (complete) return owner;
      }
    }
  }
  return null;
}
