import {
  GameConfigurationError,
  GameNotFoundError,
  GameRuleViolationError,
  GameStateViolationError,
} from '../../../core/domain/errors/game-domain.errors';
import type { EventVisibility } from '../../../core/application/models/game-event.model';
import {
  assertGameCount,
  assertGamePlayerId,
  assertPlayerValueId,
} from './numeric-invariants';

const MAX_INVENTORY_ITEMS = 100_000;

export type InventoryDefinition = {
  readonly component: 'inventory.set';
  id: string;
  items?: readonly string[];
  visibility?: 'owner' | 'public';
};

export type InventoryKitState = {
  byPlayer: Record<string, Record<string, string[]>>;
};

export function createInventoryKitState(): InventoryKitState {
  return { byPlayer: {} };
}

export const inventory = {
  set(definition: Omit<InventoryDefinition, 'component'>): InventoryDefinition {
    for (const itemId of definition.items ?? []) assertPlayerValueId(itemId);
    if (
      definition.items?.some((itemId) => !itemId.trim()) ||
      new Set(definition.items ?? []).size !== (definition.items?.length ?? 0)
    ) {
      throw new GameConfigurationError(
        `Catalogue d’inventaire invalide: ${definition.id}`,
      );
    }
    return Object.freeze({
      ...definition,
      component: 'inventory.set',
      items: definition.items
        ? Object.freeze([...definition.items])
        : undefined,
    });
  },
};

export class GameInventoryController {
  constructor(
    private readonly state: InventoryKitState,
    private readonly random: { shuffle<T>(values: readonly T[]): T[] },
    private readonly emit: (
      type: string,
      data: Record<string, unknown>,
      visibility?: EventVisibility,
    ) => void = () => {},
    definitions: readonly InventoryDefinition[] = [],
  ) {
    for (const definition of definitions) {
      this.definitions.set(definition.id, definition);
    }
  }

  private readonly definitions = new Map<string, InventoryDefinition>();

  create(definition: InventoryDefinition, playerIds: readonly number[]): void {
    this.definitions.set(definition.id, definition);
    this.state.byPlayer[definition.id] = Object.fromEntries(
      playerIds.map((playerId) => [String(playerId), []]),
    );
  }

  reset(inventoryId: string): void {
    this.definitions.delete(inventoryId);
    delete this.state.byPlayer[inventoryId];
  }

  assertValid(): void {
    for (const id of Object.keys(this.state.byPlayer))
      this.requireDefinition(id);
    for (const [inventoryId, definition] of this.definitions) {
      const inventories = this.state.byPlayer[inventoryId];
      if (
        !inventories ||
        typeof inventories !== 'object' ||
        Array.isArray(inventories)
      ) {
        throw new GameStateViolationError('Inventaire absent', { inventoryId });
      }
      const allowed = definition.items ? new Set(definition.items) : null;
      for (const [playerId, items] of Object.entries(inventories)) {
        assertGamePlayerId(Number(playerId));
        if (
          !Array.isArray(items) ||
          String(Number(playerId)) !== playerId ||
          items.length > MAX_INVENTORY_ITEMS ||
          (allowed && items.some((itemId) => !allowed.has(itemId)))
        ) {
          throw new GameStateViolationError('Contenu d’inventaire invalide', {
            inventoryId,
          });
        }
        for (const itemId of items) assertPlayerValueId(itemId);
      }
    }
  }

  items(inventoryId: string, playerId: number): string[] {
    assertGamePlayerId(playerId);
    this.requireDefinition(inventoryId);
    return [...(this.state.byPlayer[inventoryId]?.[String(playerId)] ?? [])];
  }

  add(inventoryId: string, playerId: number, itemId: string, count = 1): void {
    this.assertCanAdd(inventoryId, playerId, itemId, count);
    const byPlayer = (this.state.byPlayer[inventoryId] ??= {});
    const items = (byPlayer[String(playerId)] ??= []);
    for (let index = 0; index < count; index += 1) {
      items.push(itemId);
    }
    if (count > 0) {
      this.emit(
        'inventory.item-added',
        { inventoryId, playerId, itemId, count },
        inventoryEventVisibility(this.requireDefinition(inventoryId), [
          playerId,
        ]),
      );
    }
  }

  assertCanAdd(
    inventoryId: string,
    playerId: number,
    itemId: string,
    count = 1,
  ): void {
    assertGameCount(count, MAX_INVENTORY_ITEMS);
    assertGamePlayerId(playerId);
    this.requireItem(inventoryId, itemId);
    const items = this.state.byPlayer[inventoryId]?.[String(playerId)] ?? [];
    assertGameCount(items.length + count, MAX_INVENTORY_ITEMS);
  }

  remove(
    inventoryId: string,
    playerId: number,
    itemId: string,
    count = 1,
  ): void {
    assertGameCount(count, MAX_INVENTORY_ITEMS);
    this.requireItem(inventoryId, itemId);
    assertGamePlayerId(playerId);
    const items = this.state.byPlayer[inventoryId]?.[String(playerId)] ?? [];
    if (this.quantity(inventoryId, playerId, itemId) < count) {
      throw new GameRuleViolationError('INSUFFICIENT_INVENTORY', {
        inventoryId,
        playerId,
        itemId,
        count,
      });
    }
    for (let removed = 0; removed < Math.max(0, count); removed += 1) {
      items.splice(items.indexOf(itemId), 1);
    }
    if (count > 0) {
      this.emit(
        'inventory.item-removed',
        { inventoryId, playerId, itemId, count },
        inventoryEventVisibility(this.requireDefinition(inventoryId), [
          playerId,
        ]),
      );
    }
  }

  has(inventoryId: string, playerId: number, itemId: string): boolean {
    return this.items(inventoryId, playerId).includes(itemId);
  }

  quantity(inventoryId: string, playerId: number, itemId: string): number {
    return this.items(inventoryId, playerId).filter(
      (candidate) => candidate === itemId,
    ).length;
  }

  count(inventoryId: string, playerId: number): number {
    return this.items(inventoryId, playerId).length;
  }

  counts(inventoryId: string): Record<number, number> {
    const byPlayer = this.state.byPlayer[inventoryId] ?? {};
    return Object.fromEntries(
      Object.entries(byPlayer).map(([playerId, items]) => [
        Number(playerId),
        items.length,
      ]),
    );
  }

  quantities(inventoryId: string, playerId: number): Record<string, number> {
    return this.items(inventoryId, playerId).reduce<Record<string, number>>(
      (quantities, itemId) => {
        quantities[itemId] = (quantities[itemId] ?? 0) + 1;
        return quantities;
      },
      {},
    );
  }

  transfer(
    inventoryId: string,
    fromPlayerId: number,
    toPlayerId: number,
    itemId: string,
    count = 1,
  ): void {
    assertGameCount(count, MAX_INVENTORY_ITEMS);
    this.requireItem(inventoryId, itemId);
    if (fromPlayerId !== toPlayerId)
      assertGameCount(
        this.count(inventoryId, toPlayerId) + count,
        MAX_INVENTORY_ITEMS,
      );
    this.remove(inventoryId, fromPlayerId, itemId, count);
    this.add(inventoryId, toPlayerId, itemId, count);
    this.emit(
      'inventory.transferred',
      { inventoryId, fromPlayerId, toPlayerId, itemId, count },
      inventoryEventVisibility(this.requireDefinition(inventoryId), [
        fromPlayerId,
        toPlayerId,
      ]),
    );
  }

  exchange(
    inventoryId: string,
    leftPlayerId: number,
    leftItemId: string,
    rightPlayerId: number,
    rightItemId: string,
  ): void {
    this.requireItem(inventoryId, leftItemId);
    this.requireItem(inventoryId, rightItemId);
    if (!this.has(inventoryId, leftPlayerId, leftItemId)) {
      throw new GameRuleViolationError('INSUFFICIENT_INVENTORY', {
        inventoryId,
        playerId: leftPlayerId,
        itemId: leftItemId,
      });
    }
    if (!this.has(inventoryId, rightPlayerId, rightItemId)) {
      throw new GameRuleViolationError('INSUFFICIENT_INVENTORY', {
        inventoryId,
        playerId: rightPlayerId,
        itemId: rightItemId,
      });
    }
    if (leftPlayerId === rightPlayerId && leftItemId === rightItemId) return;
    this.remove(inventoryId, leftPlayerId, leftItemId);
    this.remove(inventoryId, rightPlayerId, rightItemId);
    this.add(inventoryId, leftPlayerId, rightItemId);
    this.add(inventoryId, rightPlayerId, leftItemId);
    this.emit(
      'inventory.exchanged',
      { inventoryId, leftPlayerId, rightPlayerId },
      inventoryEventVisibility(this.requireDefinition(inventoryId), [
        leftPlayerId,
        rightPlayerId,
      ]),
    );
  }

  swap(inventoryId: string, leftPlayerId: number, rightPlayerId: number): void {
    assertGamePlayerId(leftPlayerId);
    assertGamePlayerId(rightPlayerId);
    const definition = this.requireDefinition(inventoryId);
    const byPlayer = (this.state.byPlayer[inventoryId] ??= {});
    const left = byPlayer[String(leftPlayerId)] ?? [];
    const right = byPlayer[String(rightPlayerId)] ?? [];
    byPlayer[String(leftPlayerId)] = right;
    byPlayer[String(rightPlayerId)] = left;
    this.emit(
      'inventory.swapped',
      { inventoryId, leftPlayerId, rightPlayerId },
      inventoryEventVisibility(definition, [leftPlayerId, rightPlayerId]),
    );
  }

  stealRandom(
    inventoryId: string,
    fromPlayerId: number,
    toPlayerId: number,
  ): string | null {
    const itemId = this.random.shuffle(
      this.items(inventoryId, fromPlayerId),
    )[0];
    if (!itemId) return null;
    this.transfer(inventoryId, fromPlayerId, toPlayerId, itemId);
    return itemId;
  }

  exchangeRandom(
    inventoryId: string,
    leftPlayerId: number,
    rightPlayerId: number,
  ): void {
    const leftItemId = this.random.shuffle(
      this.items(inventoryId, leftPlayerId),
    )[0];
    const rightItemId = this.random.shuffle(
      this.items(inventoryId, rightPlayerId),
    )[0];
    if (leftItemId && rightItemId) {
      this.exchange(
        inventoryId,
        leftPlayerId,
        leftItemId,
        rightPlayerId,
        rightItemId,
      );
    } else if (leftItemId) {
      this.transfer(inventoryId, leftPlayerId, rightPlayerId, leftItemId);
    } else if (rightItemId) {
      this.transfer(inventoryId, rightPlayerId, leftPlayerId, rightItemId);
    }
  }

  removeRandom(inventoryId: string, playerId: number): string | null {
    const itemId = this.random.shuffle(this.items(inventoryId, playerId))[0];
    if (!itemId) return null;
    this.remove(inventoryId, playerId, itemId);
    return itemId;
  }

  private requireDefinition(inventoryId: string): InventoryDefinition {
    const definition = this.definitions.get(inventoryId);
    if (!definition) {
      throw new GameNotFoundError(`Inventaire inconnu: ${inventoryId}`);
    }
    return definition;
  }

  private requireItem(inventoryId: string, itemId: string): void {
    assertPlayerValueId(itemId);
    const definition = this.requireDefinition(inventoryId);
    if (definition.items && !definition.items.includes(itemId)) {
      throw new GameNotFoundError(`Objet d’inventaire inconnu: ${itemId}`);
    }
  }
}

function inventoryEventVisibility(
  definition: InventoryDefinition,
  playerIds: readonly number[],
): EventVisibility {
  return definition.visibility === 'owner'
    ? { kind: 'private', playerIds: [...new Set(playerIds)] }
    : { kind: 'public' };
}

export function projectInventoryKitState(
  state: InventoryKitState,
  viewerPlayerId: number | null,
  definitions: readonly InventoryDefinition[] = [],
): Record<
  string,
  {
    visibility: 'owner' | 'public';
    byPlayer: Record<string, string[] | { count: number }>;
  }
> {
  return Object.fromEntries(
    Object.entries(state.byPlayer).map(([inventoryId, byPlayer]) => {
      const visibility =
        definitions.find((definition) => definition.id === inventoryId)
          ?.visibility ?? 'public';
      return [
        inventoryId,
        {
          visibility,
          byPlayer: Object.fromEntries(
            Object.entries(byPlayer).map(([playerId, items]) => [
              playerId,
              visibility === 'public' || Number(playerId) === viewerPlayerId
                ? [...items]
                : { count: items.length },
            ]),
          ),
        },
      ];
    }),
  );
}
