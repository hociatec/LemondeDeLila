import {
  atAuthoringPath,
  withAuthoringPath,
} from '../contracts/authoring-origin';
import type { ReadonlyState } from '../contracts/state-copy';
import type { GameRng } from '../../../core/application/models/game-execution-context.model';
import {
  GameNotFoundError,
  GameRuleViolationError,
  GameStateViolationError,
} from '../contracts/game-domain.errors';
import type { EventVisibility } from '../../../core/application/models/game-event.model';
import type { QuizQuestion } from '../content/quiz-content-contract';
import { GameContentValidationError } from '../contracts/game-domain.errors';

export type { QuizQuestion } from '../content/quiz-content-contract';

export type QuizDefinition = {
  readonly component: 'quiz.bank';
  readonly id: string;
  readonly questions: readonly QuizQuestion[];
  readonly shuffle?: boolean;
  /** Shuffle answer positions separately for every question session. */
  readonly shuffleChoices?: boolean;
  /** Start a new shuffled pass when every question has been used. */
  readonly repeat?: boolean;
  readonly autoReveal?: 'all-answered' | 'manual';
  readonly scoring?: { correct: number; incorrect?: number };
};

export type QuizSessionState = {
  id: string;
  bankId: string;
  questionId: string;
  participantPlayerIds: number[];
  answers: Record<string, number>;
  phase: 'answering' | 'revealed' | 'closed';
  correctAnswerIndex?: number;
  scored: boolean;
  /** Private mapping from displayed positions to catalogue positions. */
  choiceOrder?: number[];
};

export type QuizSession = Omit<QuizSessionState, 'choiceOrder'> & {
  question: Omit<QuizQuestion, 'answerIndex'>;
};

export type QuizKitState = {
  orders: Record<string, string[]>;
  cursors: Record<string, number>;
  sessions: Record<string, QuizSessionState>;
  sequence: number;
};

export const quiz = {
  bank(definition: Omit<QuizDefinition, 'component'>): QuizDefinition {
    const questions = atAuthoringPath('questions', () =>
      validateQuizQuestions(definition.questions),
    );
    return deepFreeze({
      ...definition,
      component: 'quiz.bank',
      questions,
    });
  },
};

function validateQuizQuestions<TQuestion extends QuizQuestion>(
  questions: readonly TQuestion[],
): readonly Readonly<TQuestion>[] {
  if (questions.length > 10_000) {
    throw new GameContentValidationError('Trop de questions dans le contenu');
  }
  const ids = new Set<string>();
  for (const [index, question] of questions.entries()) {
    if (ids.has(question.id)) {
      throw withAuthoringPath(
        new GameContentValidationError(
          `Identifiant de question dupliqué: ${question.id}`,
          { questionId: question.id },
        ),
        `[${index}].id`,
      );
    }
    ids.add(question.id);
    if (
      question.choices.length < 2 ||
      !Number.isInteger(question.answerIndex) ||
      question.answerIndex < 0 ||
      question.answerIndex >= question.choices.length
    ) {
      throw withAuthoringPath(
        new GameContentValidationError(
          `Réponse invalide pour la question ${question.id}`,
          { questionId: question.id },
        ),
        `[${index}].${question.choices.length < 2 ? 'choices' : 'answerIndex'}`,
      );
    }
  }
  return Object.freeze(
    questions.map((question) => Object.freeze(structuredClone(question))),
  );
}

export class GameQuizController {
  constructor(
    private readonly state: QuizKitState,
    private readonly random: GameRng,
    definitions: readonly QuizDefinition[] = [],
    private readonly emit: (
      type: string,
      data: Record<string, unknown>,
      visibility?: EventVisibility,
    ) => void = () => {},
    private readonly addScore: (
      playerId: number,
      amount: number,
    ) => void = () => {},
  ) {
    for (const definition of definitions) {
      this.definitions.set(definition.id, definition);
    }
  }

  private readonly definitions = new Map<string, QuizDefinition>();

  create(definition: QuizDefinition): void {
    this.definitions.set(definition.id, definition);
    const questionIds = definition.questions.map((question) => question.id);
    this.state.orders[definition.id] = definition.shuffle
      ? this.random.shuffle(questionIds)
      : questionIds;
    this.state.cursors[definition.id] = 0;
  }

  reset(bankId: string): void {
    this.definitions.delete(bankId);
    delete this.state.orders[bankId];
    delete this.state.cursors[bankId];
    for (const [sessionId, session] of Object.entries(this.state.sessions)) {
      if (session.bankId === bankId) delete this.state.sessions[sessionId];
    }
  }

  assertValid(): void {
    for (const [bankId, order] of Object.entries(this.state.orders)) {
      const definition = this.definitions.get(bankId);
      const known = new Set(
        definition?.questions.map((question) => question.id),
      );
      if (
        !definition ||
        new Set(order).size !== order.length ||
        order.some((questionId) => !known.has(questionId)) ||
        (this.state.cursors[bankId] ?? 0) < 0 ||
        (this.state.cursors[bankId] ?? 0) > order.length
      ) {
        throw new GameStateViolationError('Ordre de quiz invalide', { bankId });
      }
    }
    for (const [sessionId, session] of Object.entries(this.state.sessions)) {
      const definition = this.definitions.get(session.bankId);
      const question = definition?.questions.find(
        (candidate) => candidate.id === session.questionId,
      );
      if (
        !question ||
        (session.choiceOrder != null &&
          (session.choiceOrder.length !== question.choices.length ||
            new Set(session.choiceOrder).size !== question.choices.length ||
            session.choiceOrder.some(
              (index) =>
                !Number.isInteger(index) ||
                index < 0 ||
                index >= question.choices.length,
            ))) ||
        Object.values(session.answers).some(
          (answer) =>
            !Number.isInteger(answer) ||
            answer < 0 ||
            answer >= question.choices.length,
        )
      ) {
        throw new GameStateViolationError('Session de quiz invalide', {
          sessionId,
          bankId: session.bankId,
        });
      }
    }
  }

  next(bankId: string): Omit<QuizQuestion, 'answerIndex'> | null {
    const definition = this.definition(bankId);
    let order = this.state.orders[bankId] ?? [];
    let cursor = this.state.cursors[bankId] ?? 0;
    if (cursor >= order.length && definition.repeat && order.length > 0) {
      const questionIds = definition.questions.map((question) => question.id);
      order = definition.shuffle
        ? this.random.shuffle(questionIds)
        : questionIds;
      cursor = 0;
      this.state.orders[bankId] = order;
      this.state.cursors[bankId] = cursor;
    }
    const questionId = order[cursor];
    const question = definition.questions.find(
      (candidate) => candidate.id === questionId,
    );
    if (!question) return null;
    this.state.cursors[bankId] = cursor + 1;
    return {
      id: question.id,
      prompt: question.prompt,
      choices: [...question.choices],
    };
  }

  check(bankId: string, questionId: string, answerIndex: number): boolean {
    const question = this.definition(bankId).questions.find(
      (candidate) => candidate.id === questionId,
    );
    if (!question) {
      throw new GameNotFoundError(`Question inconnue: ${questionId}`);
    }
    return question.answerIndex === answerIndex;
  }

  ask(
    bankId: string,
    participantPlayerIds: readonly number[],
    options: { sessionId?: string } = {},
  ): QuizSession | null {
    const question = this.next(bankId);
    if (!question) return null;
    this.state.sequence += 1;
    const session: QuizSessionState = {
      id: options.sessionId ?? `${bankId}:${this.state.sequence}`,
      bankId,
      questionId: question.id,
      participantPlayerIds: [...new Set(participantPlayerIds)],
      answers: {},
      phase: 'answering',
      scored: false,
      ...(this.definition(bankId).shuffleChoices
        ? {
            choiceOrder: this.random.shuffle(
              question.choices.map((_, index) => index),
            ),
          }
        : {}),
    };
    this.state.sessions[session.id] = session;
    this.emit('quiz.asked', {
      sessionId: session.id,
      bankId,
      questionId: question.id,
      participantPlayerIds: [...session.participantPlayerIds],
    });
    return this.publicSession(session);
  }

  answer(
    sessionId: string,
    playerId: number,
    answerIndex: number,
  ): { correct: boolean; revealed: boolean; allAnswered: boolean } {
    const session = this.requireSession(sessionId);
    if (session.phase !== 'answering') {
      throw new GameRuleViolationError('QUIZ_NOT_ANSWERING', { sessionId });
    }
    if (!session.participantPlayerIds.includes(playerId)) {
      throw new GameRuleViolationError('QUIZ_PLAYER_NOT_EXPECTED', {
        sessionId,
        playerId,
      });
    }
    if (session.answers[String(playerId)] != null) {
      throw new GameRuleViolationError('QUIZ_ALREADY_ANSWERED', {
        sessionId,
        playerId,
      });
    }
    const question = this.question(session.bankId, session.questionId);
    if (
      !Number.isInteger(answerIndex) ||
      answerIndex < 0 ||
      answerIndex >= question.choices.length
    ) {
      throw new GameRuleViolationError('QUIZ_ANSWER_INVALID', {
        sessionId,
        answerIndex,
      });
    }
    session.answers[String(playerId)] = answerIndex;
    const correct = this.correctIndex(session) === answerIndex;
    this.emit(
      'quiz.answered',
      { sessionId, playerId },
      {
        kind: 'split',
        privateDataByPlayer: { [String(playerId)]: { answerIndex } },
      },
    );
    const allAnswered = session.participantPlayerIds.every(
      (participantId) => session.answers[String(participantId)] != null,
    );
    const autoReveal =
      this.definition(session.bankId).autoReveal ?? 'all-answered';
    if (allAnswered && autoReveal === 'all-answered') this.reveal(sessionId);
    return {
      correct,
      revealed: this.requireSession(sessionId).phase === 'revealed',
      allAnswered,
    };
  }

  reveal(sessionId: string): QuizSession {
    const session = this.requireSession(sessionId);
    if (session.phase === 'closed') {
      throw new GameRuleViolationError('QUIZ_SESSION_CLOSED', { sessionId });
    }
    if (session.phase !== 'revealed') {
      const question = this.question(session.bankId, session.questionId);
      session.phase = 'revealed';
      session.correctAnswerIndex = this.correctIndex(session);
      this.score(session);
      this.emit('quiz.revealed', {
        sessionId,
        questionId: question.id,
        correctAnswerIndex: session.correctAnswerIndex,
        answers: structuredClone(session.answers),
      });
    }
    return this.publicSession(session);
  }

  advance(sessionId: string): QuizSession | null {
    const session = this.requireSession(sessionId);
    this.close(sessionId);
    return this.ask(session.bankId, session.participantPlayerIds);
  }

  close(sessionId: string): void {
    const session = this.requireSession(sessionId);
    if (session.phase === 'answering') this.reveal(sessionId);
    if (session.phase === 'closed') return;
    session.phase = 'closed';
    this.emit('quiz.closed', { sessionId });
  }

  session(sessionId: string): QuizSession | null {
    const session = this.state.sessions[sessionId];
    return session ? this.publicSession(session) : null;
  }

  private definition(bankId: string): QuizDefinition {
    const definition = this.definitions.get(bankId);
    if (!definition) throw new GameNotFoundError(`Quiz inconnu: ${bankId}`);
    return definition;
  }

  private question(bankId: string, questionId: string): QuizQuestion {
    const question = this.definition(bankId).questions.find(
      (candidate) => candidate.id === questionId,
    );
    if (!question)
      throw new GameNotFoundError(`Question inconnue: ${questionId}`);
    return question;
  }

  private requireSession(sessionId: string): QuizSessionState {
    const session = this.state.sessions[sessionId];
    if (!session)
      throw new GameNotFoundError(`Session quiz inconnue: ${sessionId}`);
    return session;
  }

  private score(session: QuizSessionState): void {
    const scoring = this.definition(session.bankId).scoring;
    if (!scoring || session.scored) return;
    const deltas: Record<string, number> = {};
    for (const playerId of session.participantPlayerIds) {
      const delta =
        session.answers[String(playerId)] === this.correctIndex(session)
          ? scoring.correct
          : (scoring.incorrect ?? 0);
      if (delta !== 0) this.addScore(playerId, delta);
      deltas[String(playerId)] = delta;
    }
    session.scored = true;
    this.emit('quiz.scored', { sessionId: session.id, deltas });
  }

  private publicSession(session: QuizSessionState): QuizSession {
    const question = this.question(session.bankId, session.questionId);
    const publicState = structuredClone(session);
    delete publicState.choiceOrder;
    return {
      ...publicState,
      question: {
        id: question.id,
        prompt: question.prompt,
        choices: quizSessionChoices(question, session),
      },
    };
  }

  private correctIndex(session: QuizSessionState): number {
    const question = this.question(session.bankId, session.questionId);
    return (
      session.choiceOrder?.indexOf(question.answerIndex) ?? question.answerIndex
    );
  }
}

export function quizSessionChoices(
  question: QuizQuestion,
  session: ReadonlyState<QuizSessionState>,
): string[] {
  return session.choiceOrder
    ? session.choiceOrder.map((index) => question.choices[index])
    : [...question.choices];
}

function deepFreeze<TValue>(value: TValue): TValue {
  if (value == null || typeof value !== 'object' || Object.isFrozen(value)) {
    return value;
  }
  for (const nested of Object.values(value)) deepFreeze(nested);
  return Object.freeze(value);
}

export function createQuizKitState(): QuizKitState {
  return { orders: {}, cursors: {}, sessions: {}, sequence: 0 };
}
