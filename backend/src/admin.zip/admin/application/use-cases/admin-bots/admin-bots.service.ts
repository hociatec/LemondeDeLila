import { Injectable } from '@nestjs/common';
import { BotService } from '../../../../bot/services/bot.service';
import { BotSettingsService } from '../../../../game/modules/bot/services/bot-settings.service';

@Injectable()
export class AdminBotsService {
  constructor(
    private readonly bots: BotService,
    private readonly botSettings: BotSettingsService,
  ) {}

  async listNames() {
    const names = await this.bots.listBotNames();
    return {
      names: names.map((name) => ({
        id: name.id,
        name: name.name,
        enabled: name.enabled,
        createdAt: name.createdAt,
      })),
    };
  }

  getSettings() {
    return this.botSettings.getSettings();
  }

  async updateSettings(update: {
    botTurnDelayMs?: number;
    botStartDelayMs?: number;
    botDrawDelayMs?: number;
  }) {
    return this.botSettings.updateSettings(update);
  }

  async createName(name: string, enabled = true) {
    await this.bots.createBotName(name, enabled);
    return this.listNames();
  }

  async updateName(
    id: number,
    update: { name?: string; enabled?: boolean },
  ) {
    await this.bots.updateBotName(id, update);
    return this.listNames();
  }

  async deleteName(id: number) {
    await this.bots.deleteBotName(id);
    return this.listNames();
  }
}
