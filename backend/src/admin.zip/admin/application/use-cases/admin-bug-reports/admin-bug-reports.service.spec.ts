import { BadRequestException } from '@nestjs/common';
import { AdminBugReportsService } from './admin-bug-reports.service';

describe('AdminBugReportsService', () => {
  function createDeps() {
    return {
      reports: {
        create: jest.fn(),
        list: jest.fn(),
        get: jest.fn(),
        update: jest.fn(),
        updateStatus: jest.fn(),
        delete: jest.fn(),
      },
      comments: {
        countByReportIds: jest.fn(),
      },
    };
  }

  it('enriches list items with commentsCount', async () => {
    const deps = createDeps();
    deps.reports.list.mockResolvedValue([
      { id: 'r1', subject: 'A' },
      { id: 'r2', subject: 'B' },
    ]);
    deps.comments.countByReportIds.mockResolvedValue({ r1: 3 });
    const service = new AdminBugReportsService(
      deps.reports as any,
      deps.comments as any,
    );

    const result = await service.list();

    expect(result).toEqual([
      { id: 'r1', subject: 'A', commentsCount: 3 },
      { id: 'r2', subject: 'B', commentsCount: 0 },
    ]);
  });

  it('fails on get when the report does not exist', async () => {
    const deps = createDeps();
    deps.reports.get.mockResolvedValue(null);
    const service = new AdminBugReportsService(
      deps.reports as any,
      deps.comments as any,
    );

    await expect(service.get('missing')).rejects.toBeInstanceOf(
      BadRequestException,
    );
  });
});
