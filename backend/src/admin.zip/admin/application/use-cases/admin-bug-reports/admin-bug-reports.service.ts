import { BadRequestException, Inject, Injectable } from '@nestjs/common';
import {
  ADMIN_BUG_REPORT_COMMENTS_PORT,
  ADMIN_BUG_REPORTS_PORT,
  type AdminBugReportCommentsPort,
  type AdminBugReportsPort,
} from '../../ports/admin-bug-reports.port';

export interface CreateAdminBugReportCommand {
  subject: string;
  content: string;
  createdByUserId: number;
  createdByUsername: string;
}

export interface UpdateAdminBugReportCommand {
  id: string;
  subject?: string;
  content?: string;
}

export interface UpdateAdminBugReportStatusCommand {
  id: string;
  status:
    | 'pending'
    | 'in_progress'
    | 'to_test'
    | 'done'
    | 'refused'
    | 'rejected';
}

@Injectable()
export class AdminBugReportsService {
  constructor(
    @Inject(ADMIN_BUG_REPORTS_PORT)
    private readonly reports: AdminBugReportsPort,
    @Inject(ADMIN_BUG_REPORT_COMMENTS_PORT)
    private readonly comments: AdminBugReportCommentsPort,
  ) {}

  async create(command: CreateAdminBugReportCommand) {
    return this.reports.create({
      subject: command.subject,
      content: command.content,
      createdByUserId: command.createdByUserId,
      createdByUsername: command.createdByUsername,
    });
  }

  async list() {
    const items = await this.reports.list();
    const counts = await this.comments.countByReportIds(items.map((item) => item.id));
    return items.map((item) => ({
      ...item,
      commentsCount: counts[item.id] ?? 0,
    }));
  }

  async get(id: string) {
    const report = await this.reports.get(id);
    if (!report) {
      throw new BadRequestException('Rapport introuvable');
    }
    const counts = await this.comments.countByReportIds([report.id]);
    return {
      ...report,
      commentsCount: counts[report.id] ?? 0,
    };
  }

  async update(command: UpdateAdminBugReportCommand) {
    const report = await this.reports.update(command.id, {
      subject: command.subject,
      content: command.content,
    });
    if (!report) {
      throw new BadRequestException('Rapport introuvable');
    }
    return report;
  }

  async updateStatus(command: UpdateAdminBugReportStatusCommand) {
    const report = await this.reports.updateStatus(command.id, command.status);
    if (!report) {
      throw new BadRequestException('Rapport introuvable');
    }
    return report;
  }

  async delete(id: string) {
    const ok = await this.reports.delete(id);
    if (!ok) {
      throw new BadRequestException('Rapport introuvable');
    }
    return { removed: true };
  }
}
