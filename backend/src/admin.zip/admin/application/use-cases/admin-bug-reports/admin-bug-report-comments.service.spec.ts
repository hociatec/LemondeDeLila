import { BadRequestException } from '@nestjs/common';
import { AdminBugReportCommentsService } from './admin-bug-report-comments.service';

describe('AdminBugReportCommentsService', () => {
  it('lists comments for a report', async () => {
    const listByReportId = jest.fn().mockResolvedValue([{ id: 'c1' }]);
    const service = new AdminBugReportCommentsService({
      listByReportId,
      add: jest.fn(),
      countByReportIds: jest.fn(),
    } as any);

    await expect(service.list('r1')).resolves.toEqual([{ id: 'c1' }]);
    expect(listByReportId).toHaveBeenCalledWith('r1');
  });

  it('throws when target report is missing', async () => {
    const service = new AdminBugReportCommentsService({
      listByReportId: jest.fn(),
      add: jest.fn().mockResolvedValue(null),
      countByReportIds: jest.fn(),
    } as any);

    await expect(
      service.add({
        reportId: 'r1',
        content: 'note',
        createdByUserId: 1,
        createdByUsername: 'admin',
      }),
    ).rejects.toBeInstanceOf(BadRequestException);
  });

  it('returns the created comment with updated count', async () => {
    const add = jest.fn().mockResolvedValue({ id: 'c1' });
    const countByReportIds = jest.fn().mockResolvedValue({ r1: 4 });
    const service = new AdminBugReportCommentsService({
      listByReportId: jest.fn(),
      add,
      countByReportIds,
    } as any);

    await expect(
      service.add({
        reportId: ' r1 ',
        content: 'note',
        createdByUserId: 1,
        createdByUsername: 'admin',
      }),
    ).resolves.toEqual({
      comment: { id: 'c1' },
      reportId: 'r1',
      commentsCount: 4,
    });

    expect(add).toHaveBeenCalledWith({
      reportId: 'r1',
      content: 'note',
      createdByUserId: 1,
      createdByUsername: 'admin',
    });
    expect(countByReportIds).toHaveBeenCalledWith(['r1']);
  });
});
