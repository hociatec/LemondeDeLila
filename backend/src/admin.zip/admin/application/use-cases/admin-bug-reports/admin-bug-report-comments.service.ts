import { BadRequestException, Inject, Injectable } from '@nestjs/common';
import {
  ADMIN_BUG_REPORT_COMMENTS_PORT,
  type AdminBugReportCommentsPort,
} from '../../ports/admin-bug-reports.port';

@Injectable()
export class AdminBugReportCommentsService {
  constructor(
    @Inject(ADMIN_BUG_REPORT_COMMENTS_PORT)
    private readonly comments: AdminBugReportCommentsPort,
  ) {}

  list(reportId: string) {
    return this.comments.listByReportId(reportId);
  }

  async add(input: {
    reportId: string;
    content: string;
    createdByUserId: number;
    createdByUsername: string;
  }) {
    const reportId = input.reportId.trim();
    const comment = await this.comments.add({
      reportId,
      content: input.content,
      createdByUserId: input.createdByUserId,
      createdByUsername: input.createdByUsername,
    });

    if (!comment) {
      throw new BadRequestException('Rapport introuvable');
    }

    const counts = await this.comments.countByReportIds([reportId]);
    return {
      comment,
      reportId,
      commentsCount: counts[reportId] ?? 0,
    };
  }
}
