export interface AdminBugReportRecord {
  id: string;
  subject?: string;
  content?: string;
  status?:
    | 'pending'
    | 'in_progress'
    | 'to_test'
    | 'done'
    | 'refused'
    | 'rejected';
  createdByUserId?: number;
  createdByUsername?: string;
}

export interface AdminBugReportsPort {
  create(input: {
    subject: string;
    content: string;
    createdByUserId: number;
    createdByUsername: string;
  }): Promise<AdminBugReportRecord>;
  list(): Promise<AdminBugReportRecord[]>;
  get(id: string): Promise<AdminBugReportRecord | null>;
  update(
    id: string,
    update: { subject?: string; content?: string },
  ): Promise<AdminBugReportRecord | null>;
  updateStatus(
    id: string,
    status:
      | 'pending'
      | 'in_progress'
      | 'to_test'
      | 'done'
      | 'refused'
      | 'rejected',
  ): Promise<AdminBugReportRecord | null>;
  delete(id: string): Promise<boolean>;
}

export interface AdminBugReportCommentsPort {
  countByReportIds(reportIds: string[]): Promise<Record<string, number>>;
  listByReportId(reportId: string): Promise<unknown[]>;
  add(input: {
    reportId: string;
    content: string;
    createdByUserId: number;
    createdByUsername: string;
  }): Promise<unknown | null>;
}

export const ADMIN_BUG_REPORTS_PORT = Symbol('ADMIN_BUG_REPORTS_PORT');
export const ADMIN_BUG_REPORT_COMMENTS_PORT = Symbol(
  'ADMIN_BUG_REPORT_COMMENTS_PORT',
);
