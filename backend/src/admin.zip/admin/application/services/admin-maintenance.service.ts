import {
  Inject,
  Injectable,
  InternalServerErrorException,
} from '@nestjs/common';
import {
  ADMIN_MAINTENANCE_RUNTIME_PORT,
  type AdminMaintenanceRuntimePort,
} from '../ports/admin-maintenance-runtime.port';

const DEPLOY_UNIT =
  process.env.ADMIN_MAINTENANCE_DEPLOY_UNIT || 'lila-backend-deploy.service';
const BACKEND_SERVICE =
  process.env.ADMIN_MAINTENANCE_BACKEND_SERVICE || 'lila-backend.service';
const SERVICE_RE = /^[a-zA-Z0-9@._-]+$/;

@Injectable()
export class AdminMaintenanceService {
  private readonly backendCwd = process.cwd();

  constructor(
    @Inject(ADMIN_MAINTENANCE_RUNTIME_PORT)
    private readonly runtime: AdminMaintenanceRuntimePort,
  ) {}

  startBuildAndRestartBackend() {
    if (!SERVICE_RE.test(BACKEND_SERVICE)) {
      throw new InternalServerErrorException({
        message: `Service backend invalide: ${BACKEND_SERVICE}`,
      });
    }

    const chain = [
      `cd ${this.runtime.shQuote(this.backendCwd)}`,
      'npm run build',
      `sudo -n systemctl restart ${this.runtime.shQuote(BACKEND_SERVICE)}`,
    ].join(' && ');

    this.runtime.spawnDetached(['bash', '-lc', chain], { delayMs: 350 });
    return { ok: true, service: BACKEND_SERVICE, scheduled: true };
  }

  startDeploy() {
    const res = this.runtime.runCommand([
      'sudo',
      '-n',
      'systemctl',
      'start',
      '--no-block',
      DEPLOY_UNIT,
    ]);
    if (res.status !== 0) {
      throw new InternalServerErrorException({
        message: 'Echec du declenchement du deploiement',
        details: res,
      });
    }
    return { ok: true, unit: DEPLOY_UNIT };
  }

  startRestartBackend() {
    this.runtime.spawnDetached(
      ['sudo', '-n', 'systemctl', 'restart', BACKEND_SERVICE],
      { delayMs: 350 },
    );
    return { ok: true, service: BACKEND_SERVICE, scheduled: true };
  }

  daemonReload() {
    const res = this.runtime.runCommand([
      'sudo',
      '-n',
      'systemctl',
      'daemon-reload',
    ]);
    if (res.status !== 0) {
      throw new InternalServerErrorException({
        message: 'Echec systemd daemon-reload',
        details: res,
      });
    }
    return { ok: true, command: 'systemctl daemon-reload', ...res };
  }

  dryRunBuild() {
    const res = this.runtime.runCommand(['npm', 'run', 'build'], {
      cwd: this.backendCwd,
      timeoutMs: 10 * 60 * 1000,
    });
    if (res.status !== 0) {
      throw new InternalServerErrorException({
        message: 'Build echoue (dry-run)',
        details: res,
      });
    }
    return { ok: true, command: 'npm run build', ...res };
  }

  runMigrations() {
    const res = this.runtime.runCommand(['npm', 'run', 'migration:run'], {
      cwd: this.backendCwd,
      timeoutMs: 10 * 60 * 1000,
    });
    if (res.status !== 0) {
      throw new InternalServerErrorException({
        message: 'Migrations echouees',
        details: res,
      });
    }
    return { ok: true, command: 'npm run migration:run', ...res };
  }

  async getHealth(): Promise<{
    ok: true;
    url: string;
    statusCode: number;
    body: string;
  }> {
    const port = Number(process.env.PORT || 3000);
    const url = `http://127.0.0.1:${port}/health`;
    const res = await this.runtime.httpGet(url, 3500);
    return { ok: true, url, statusCode: res.statusCode, body: res.body };
  }

  getDeployStatus() {
    return this.getUnitStatus(DEPLOY_UNIT);
  }

  getBackendServiceStatus() {
    return this.getUnitStatus(BACKEND_SERVICE);
  }

  getDeployLogs(input: { tail?: string }) {
    const tail = this.runtime.parseTail(input.tail);
    const res = this.runtime.runCommand([
      'sudo',
      '-n',
      'journalctl',
      '-u',
      DEPLOY_UNIT,
      '--no-pager',
      '-o',
      'short-iso',
      '-n',
      String(tail),
    ]);
    if (res.status !== 0) {
      throw new InternalServerErrorException({
        message: 'Impossible de lire les logs du deploiement',
        details: res,
      });
    }
    return { ok: true, unit: DEPLOY_UNIT, tail, logs: res.stdout };
  }

  private getUnitStatus(unit: string) {
    const res = this.runtime.runCommand([
      'sudo',
      '-n',
      'systemctl',
      'show',
      unit,
      '--no-pager',
      '--property=Id,ActiveState,SubState,Result,ExecMainStatus,ExecMainCode,ExecMainStartTimestamp,ExecMainExitTimestamp',
    ]);
    if (res.status !== 0) {
      throw new InternalServerErrorException({
        message: `Impossible de lire le status systemd: ${unit}`,
        details: res,
      });
    }
    const props = this.runtime.parseSystemctlShow(res.stdout);
    return { ok: true, unit, ...props };
  }
}
