import { InternalServerErrorException } from '@nestjs/common';
import { AdminMaintenanceService } from './admin-maintenance.service';

describe('AdminMaintenanceService', () => {
  it('uses runtime port to start deploy', () => {
    const runtime = createRuntime();
    runtime.runCommand.mockReturnValue({
      status: 0,
      stdout: '',
      stderr: '',
      error: null,
    });

    const service = new AdminMaintenanceService(runtime as any);

    expect(service.startDeploy()).toEqual({
      ok: true,
      unit:
        process.env.ADMIN_MAINTENANCE_DEPLOY_UNIT ||
        'lila-backend-deploy.service',
    });
    expect(runtime.runCommand).toHaveBeenCalledWith([
      'sudo',
      '-n',
      'systemctl',
      'start',
      '--no-block',
      process.env.ADMIN_MAINTENANCE_DEPLOY_UNIT ||
        'lila-backend-deploy.service',
    ]);
  });

  it('parses status through the runtime port', () => {
    const runtime = createRuntime();
    runtime.runCommand.mockReturnValue({
      status: 0,
      stdout: 'Id=svc\nActiveState=active',
      stderr: '',
      error: null,
    });
    runtime.parseSystemctlShow.mockReturnValue({
      Id: 'svc',
      ActiveState: 'active',
    });

    const service = new AdminMaintenanceService(runtime as any);

    expect(service.getBackendServiceStatus()).toEqual({
      ok: true,
      unit:
        process.env.ADMIN_MAINTENANCE_BACKEND_SERVICE ||
        'lila-backend.service',
      Id: 'svc',
      ActiveState: 'active',
    });
    expect(runtime.parseSystemctlShow).toHaveBeenCalledWith(
      'Id=svc\nActiveState=active',
    );
  });

  it('throws when runtime command fails', () => {
    const runtime = createRuntime();
    runtime.runCommand.mockReturnValue({
      status: 1,
      stdout: '',
      stderr: 'boom',
      error: null,
    });

    const service = new AdminMaintenanceService(runtime as any);

    expect(() => service.daemonReload()).toThrow(InternalServerErrorException);
  });
});

function createRuntime() {
  return {
    runCommand: jest.fn(),
    spawnDetached: jest.fn(),
    httpGet: jest.fn(),
    parseSystemctlShow: jest.fn(),
    parseTail: jest.fn(),
    shQuote: jest.fn(),
  };
}
