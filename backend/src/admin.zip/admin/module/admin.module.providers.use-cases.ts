import { AdminBroadcastService } from '../application/use-cases/admin-broadcast/admin-broadcast.service';
import { AdminBotsService } from '../application/use-cases/admin-bots/admin-bots.service';
import { AdminBugReportCommentsService } from '../application/use-cases/admin-bug-reports/admin-bug-report-comments.service';
import { AdminBugReportsService } from '../application/use-cases/admin-bug-reports/admin-bug-reports.service';
import { AdminChatModerationService } from '../application/use-cases/admin-chat/admin-chat-moderation.service';
import { AdminChatService } from '../application/use-cases/admin-chat/admin-chat.service';
import { AdminClientUpdateAnnounceService } from '../application/use-cases/admin-client-updates/admin-client-update-announce.service';
import { AdminClientUpdateForceLatestService } from '../application/use-cases/admin-client-updates/admin-client-update-force-latest.service';
import { AdminClientUpdateSchedulePlannerService } from '../application/use-cases/admin-client-updates/admin-client-update-schedule-planner.service';
import { AdminClientUpdateSchedulerDispatchService } from '../application/use-cases/admin-client-updates/admin-client-update-scheduler-dispatch.service';
import { AdminClientUpdateSchedulerService } from '../application/use-cases/admin-client-updates/admin-client-update-scheduler.service';
import { AdminClientUpdatesDispatchService } from '../application/use-cases/admin-client-updates/admin-client-updates-dispatch.service';
import { AdminClientUpdatesSharedService } from '../application/use-cases/admin-client-updates/admin-client-updates-shared.service';
import { AdminGameCategoriesService } from '../application/use-cases/admin-games/admin-game-categories.service';
import { AdminGameOverridesService } from '../application/use-cases/admin-games/admin-game-overrides.service';
import { AdminGamesManagementService } from '../application/use-cases/admin-games/admin-games-management.service';
import { AdminGamesPresenterService } from '../application/use-cases/admin-games/admin-games-presenter.service';
import { AdminLogsService } from '../application/use-cases/admin-logs/admin-logs.service';
import { AdminMnemoQuizCategoriesService } from '../application/use-cases/admin-mnemo-quiz/admin-mnemo-quiz-categories.service';
import { AdminMnemoQuizPresenterService } from '../application/use-cases/admin-mnemo-quiz/admin-mnemo-quiz-presenter.service';
import { AdminMnemoQuizQuestionsService } from '../application/use-cases/admin-mnemo-quiz/admin-mnemo-quiz-questions.service';
import { AdminPerfService } from '../application/use-cases/admin-perf/admin-perf.service';
import { AdminProfileService } from '../application/use-cases/admin-profile/admin-profile.service';
import { AdminRolesService } from '../application/use-cases/admin-roles/admin-roles.service';
import { AdminRoomsService } from '../application/use-cases/admin-rooms/admin-rooms.service';
import { AdminStatsService } from '../application/use-cases/admin-stats/admin-stats.service';
import { AdminUserBanPolicyService } from '../application/use-cases/admin-users/admin-user-ban-policy.service';
import { AdminUserPasswordService } from '../application/use-cases/admin-users/admin-user-password.service';
import { AdminUsersCommandService } from '../application/use-cases/admin-users/admin-users-command.service';
import { AdminUsersQueryService } from '../application/use-cases/admin-users/admin-users-query.service';

export const ADMIN_USE_CASE_PROVIDERS = [
  AdminUsersQueryService,
  AdminUserPasswordService,
  AdminUserBanPolicyService,
  AdminUsersCommandService,
  AdminClientUpdatesSharedService,
  AdminClientUpdateAnnounceService,
  AdminClientUpdateForceLatestService,
  AdminClientUpdateSchedulePlannerService,
  AdminClientUpdateSchedulerDispatchService,
  AdminClientUpdateSchedulerService,
  AdminClientUpdatesDispatchService,
  AdminGameCategoriesService,
  AdminGamesManagementService,
  AdminGameOverridesService,
  AdminGamesPresenterService,
  AdminMnemoQuizCategoriesService,
  AdminMnemoQuizPresenterService,
  AdminMnemoQuizQuestionsService,
  AdminBroadcastService,
  AdminBugReportsService,
  AdminBugReportCommentsService,
  AdminBotsService,
  AdminChatService,
  AdminChatModerationService,
  AdminLogsService,
  AdminPerfService,
  AdminProfileService,
  AdminRolesService,
  AdminRoomsService,
  AdminStatsService,
];
